-- phpMyAdmin SQL Dump
-- version 3.4.10.1deb1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 05-12-2013 a las 23:54:41
-- Versión del servidor: 5.5.34
-- Versión de PHP: 5.3.10-1ubuntu3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `london`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `addresses`
--

CREATE TABLE IF NOT EXISTS `addresses` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `country_id` int(11) unsigned NOT NULL,
  `state_id` int(11) unsigned NOT NULL,
  `city_id` int(11) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address` text COLLATE utf8_unicode_ci NOT NULL,
  `phones` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `additional_information` text COLLATE utf8_unicode_ci NOT NULL,
  `deleted` int(1) unsigned NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- Volcado de datos para la tabla `addresses`
--

INSERT INTO `addresses` (`id`, `user_id`, `country_id`, `state_id`, `city_id`, `name`, `address`, `phones`, `additional_information`, `deleted`, `created`, `modified`) VALUES
(2, 4, 1, 16, 21, 'MRW  MATURIN', 'Dirección: AV. LIBERTADOR, SECTOR 23 DE ENERO, RES. CANAIMA P.B., LOCAL NO. 1', '20202020', 'Código Agencia: 1600000', 1, '2012-02-06 18:22:29', '2012-02-06 19:52:57'),
(3, 4, 1, 16, 21, 'as', 'as', 'as', '', 1, '2012-02-06 18:22:45', '2012-02-06 18:22:45'),
(4, 4, 1, 16, 21, 'as', 'as', 'as', 'as', 1, '2012-02-06 18:23:38', '2012-02-06 18:23:38'),
(5, 4, 1, 16, 7, 'MRW  MATURIN AV. RAUL LEONI', 'AV. RAUL LEONI C.C LOS VIERA DIAGONAL AL POLIDEPORTIVO', '02913150755', 'Código Agencia: 1600000', 0, '2012-02-06 19:52:49', '2012-04-05 17:44:54'),
(12, 4, 1, 16, 21, 'MRW  LOS COCOS', 'AV. LOS COCOS CALIENTES DE ROSITA', '055000550', 'MOTHER OF ROSITA', 1, '2012-02-16 17:52:20', '2012-02-16 17:52:20');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `answers`
--

CREATE TABLE IF NOT EXISTS `answers` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `question_id` int(10) unsigned NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=81 ;

--
-- Volcado de datos para la tabla `answers`
--

INSERT INTO `answers` (`id`, `user_id`, `question_id`, `body`, `created`, `modified`) VALUES
(1, 0, 1, 'claro vale.', '2012-01-05 10:28:02', '2012-01-05 10:28:04'),
(17, 0, 7, 'a locha', '2012-01-25 17:14:56', '2012-01-25 17:14:56'),
(21, 0, 5, 'todo fino', '2012-01-25 18:30:45', '2012-01-25 18:30:45'),
(73, 0, 6, '1', '2012-01-27 12:09:42', '2012-01-27 12:09:42'),
(74, 0, 3, '3', '2012-08-19 07:35:26', '2012-08-19 07:35:26'),
(75, 4, 8, 'ok', '2012-08-19 19:18:16', '2012-08-19 19:18:16'),
(76, 5, 36, 'claro vale', '2012-08-19 19:41:54', '2012-08-19 19:41:54'),
(77, 5, 2, 'hola', '2012-08-19 21:13:23', '2012-08-19 21:13:23'),
(78, 5, 35, 'mañana ok', '2012-08-19 21:14:01', '2012-08-19 21:14:01'),
(79, 5, 34, 'yo opino lo mismo', '2012-08-19 21:16:02', '2012-08-19 21:16:02'),
(80, 5, 33, '3', '2012-08-19 21:16:33', '2012-08-19 21:16:33');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `banks`
--

CREATE TABLE IF NOT EXISTS `banks` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `logo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `banks`
--

INSERT INTO `banks` (`id`, `name`, `logo`, `created`, `modified`) VALUES
(1, 'Banesco Banco Universal C.A', 'logo', '2012-02-17 00:00:00', '2012-02-17 00:00:00'),
(2, 'Mercantil C.A', 'logo', '2012-02-17 00:00:00', '2012-02-17 00:00:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `bank_accounts`
--

CREATE TABLE IF NOT EXISTS `bank_accounts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `company_id` int(11) unsigned NOT NULL,
  `bank_id` int(11) unsigned NOT NULL,
  `number` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Volcado de datos para la tabla `bank_accounts`
--

INSERT INTO `bank_accounts` (`id`, `user_id`, `company_id`, `bank_id`, `number`, `created`, `modified`) VALUES
(1, 4, 1, 1, '10101010101010101010', '2012-02-17 20:33:00', '2012-02-18 13:07:41'),
(2, 4, 1, 1, '20202020202020202020', '2012-02-17 21:11:30', '2012-02-18 12:52:14'),
(3, 4, 1, 2, '30303030303030303030', '2012-02-18 00:58:04', '2012-02-18 12:52:22');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `billings`
--

CREATE TABLE IF NOT EXISTS `billings` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `purchase_id` int(11) unsigned NOT NULL,
  `billing_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `identity_card` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fiscal_address` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Volcado de datos para la tabla `billings`
--

INSERT INTO `billings` (`id`, `user_id`, `purchase_id`, `billing_name`, `identity_card`, `fiscal_address`, `phone`, `created`, `modified`) VALUES
(1, 4, 9, 'romel', '16711885', 'Urb. Las trinitarias calle 10 casa 561', '020913150755', '2012-02-21 11:47:18', '2012-02-21 12:25:03'),
(3, 4, 7, 'romel', '16711885', 'Urb. Las trinitarias calle 10 casa 561', '582913150755', '2012-02-21 13:39:51', '2012-08-11 22:00:10'),
(4, 4, 5, 'rudy', '16711885', 'Urb. Las trinitarias calle 10 casa 561', '582913150755', '2012-02-21 13:43:58', '2012-02-21 13:44:13'),
(5, 4, 10, 'romel', '16711885', 'urb ', '655525', '2012-08-11 12:19:57', '2012-08-11 14:46:51'),
(6, 4, 17, '321', '32', '132', '1', '2013-03-05 00:04:35', '2013-03-05 00:04:35'),
(7, 4, 16, '213', '21', '32', '132', '2013-03-05 00:05:36', '2013-03-05 00:05:36'),
(8, 4, 2, 'romel', '16711885', 'urb. las trinitarias calle 10', '3213213213', '2013-03-05 00:57:32', '2013-03-05 00:57:32'),
(9, 4, 4, '13', '213', '21', '321', '2013-03-07 16:21:58', '2013-03-07 16:21:58');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cake_sessions`
--

CREATE TABLE IF NOT EXISTS `cake_sessions` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `expires` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `cake_sessions`
--

INSERT INTO `cake_sessions` (`id`, `data`, `expires`) VALUES
('nsklqb4h7c04u32c8lbb6ir772', 'Config|a:3:{s:9:"userAgent";s:32:"9815f78dbc46ba62bfc00ce0bf5c31b0";s:4:"time";i:1329684847;s:7:"timeout";i:10;}Message|a:1:{s:4:"auth";a:3:{s:7:"message";s:2:"ok";s:7:"element";s:7:"default";s:6:"params";a:0:{}}}Auth|a:1:{s:4:"User";a:15:{s:2:"id";s:1:"4";s:9:"parent_id";s:1:"0";s:7:"role_id";s:1:"2";s:10:"company_id";s:1:"1";s:8:"store_id";s:1:"0";s:4:"name";s:5:"romel";s:11:"family_name";s:5:"gomez";s:5:"alias";s:6:"razden";s:5:"email";s:16:"romel2@gmail.com";s:5:"phone";s:11:"02913150755";s:14:"activation_key";s:14:"activation_key";s:6:"status";s:1:"1";s:7:"deleted";s:1:"0";s:7:"created";s:19:"0000-00-00 00:00:00";s:8:"modified";s:19:"2012-02-05 10:07:54";}}', 1329684847);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `carts`
--

CREATE TABLE IF NOT EXISTS `carts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `cake_session_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) unsigned DEFAULT NULL,
  `product_id` int(11) unsigned NOT NULL,
  `quantity` int(3) unsigned NOT NULL DEFAULT '1',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=31 ;

--
-- Volcado de datos para la tabla `carts`
--

INSERT INTO `carts` (`id`, `cake_session_id`, `user_id`, `product_id`, `quantity`, `created`, `modified`) VALUES
(2, 'mbmjeqb0194hpv8n45bgiagpe5', NULL, 2, 1, '2012-01-01 21:21:07', '2012-01-01 21:21:07'),
(9, 'o1gurhuv4svv2p9ip0fd4pso65', 3, 14, 1, '2012-01-10 14:52:14', '2012-01-10 14:52:14'),
(15, '269hlai5ll01r6bv8v25o6c105', NULL, 2, 1, '2012-01-23 13:10:54', '2012-01-23 13:10:54'),
(16, 'nsklqb4h7c04u32c8lbb6ir772', NULL, 21, 1, '2012-02-19 16:27:01', '2012-02-19 16:27:01'),
(17, 'njg5clrbqpjg9bfv6h6e536gh0', NULL, 21, 1, '2012-03-14 18:12:34', '2012-03-14 18:12:34'),
(19, 'hvvb6h6u77d6qh3clc8q4obcc0', NULL, 21, 1, '2012-05-08 10:02:03', '2012-05-08 10:02:03'),
(20, 'br3m7cmb4965gmiloni69esrl2', NULL, 21, 1, '2012-09-19 08:47:08', '2012-09-19 08:47:08'),
(30, 's8rrp85hc8giqh0sjdvojlllm0', NULL, 12, 1, '2013-03-07 14:45:30', '2013-03-07 14:45:30');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) DEFAULT NULL,
  `lft` int(10) DEFAULT NULL,
  `rght` int(10) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `is` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=21 ;

--
-- Volcado de datos para la tabla `categories`
--

INSERT INTO `categories` (`id`, `parent_id`, `lft`, `rght`, `name`, `is`, `created`, `modified`) VALUES
(1, NULL, 1, 16, 'Tarjetas Madre', '1', '2012-04-05 22:11:20', '2012-04-05 22:11:20'),
(2, 1, 2, 15, 'element 1 ', '1', '2012-04-05 22:37:26', '2012-04-05 22:37:26'),
(3, 2, 3, 14, 'element 2', '1', '2012-04-05 22:37:32', '2012-04-05 22:37:32'),
(4, 3, 4, 13, 'element 3', '1', '2012-04-05 22:37:37', '2012-04-05 22:37:37'),
(5, 4, 5, 12, 'element 4', '1', '2012-04-05 22:37:42', '2012-04-05 22:37:42'),
(6, 5, 10, 11, 'element 5', '1', '2012-04-05 22:37:48', '2012-04-05 22:37:48'),
(7, NULL, 17, 18, 'element ', '1', '2012-04-05 22:37:51', '2012-04-05 22:37:51'),
(8, 5, 8, 9, 'element 6', '1', '2012-04-05 22:37:59', '2012-04-05 22:37:59'),
(9, 5, 6, 7, 'element 7', '1', '2012-04-05 22:38:08', '2012-04-05 22:38:08'),
(10, NULL, 19, 20, 'sub element 1', '1', '2012-04-05 22:46:38', '2012-04-05 22:46:38'),
(11, NULL, 21, 30, 'sub element 2', '1', '2012-04-05 22:46:45', '2012-04-05 22:46:45'),
(12, 11, 24, 25, 'sub element 3', '1', '2012-04-05 22:46:50', '2012-04-05 22:46:50'),
(13, 11, 22, 23, 'sub element 4', '1', '2012-04-05 22:46:55', '2012-04-05 22:46:55'),
(14, 11, 26, 29, 'sub element 5', '1', '2012-04-05 22:46:59', '2012-04-05 22:46:59'),
(15, 14, 27, 28, 'sub element 6', '1', '2012-04-05 22:47:04', '2012-04-05 22:47:04'),
(16, NULL, 31, 32, 'sub element 7', '1', '2012-04-05 22:47:10', '2012-04-05 22:47:10'),
(17, NULL, 33, 34, 'sub element 8', '1', '2012-04-05 22:47:16', '2012-04-05 22:47:16'),
(18, NULL, 35, 36, 'sub element 9', '1', '2012-04-05 22:47:21', '2012-04-05 22:47:21'),
(19, NULL, 37, 38, 'sub element 10', '1', '2012-04-05 22:47:25', '2012-04-05 22:47:25'),
(20, NULL, 39, 40, 'sub element 11', '1', '2012-04-05 22:47:32', '2012-04-05 22:47:32');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cities`
--

CREATE TABLE IF NOT EXISTS `cities` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `state_id` int(11) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=37 ;

--
-- Volcado de datos para la tabla `cities`
--

INSERT INTO `cities` (`id`, `state_id`, `name`, `created`, `modified`) VALUES
(1, 18, 'Acarigua', NULL, NULL),
(2, 3, 'Barcelona', NULL, NULL),
(3, 6, 'Barinas', NULL, NULL),
(4, 13, 'Barquisimeto', NULL, NULL),
(5, 23, 'Cabimas', NULL, NULL),
(6, 1, 'Caracas', NULL, NULL),
(7, 16, 'Caripito', NULL, NULL),
(8, 13, 'Carora', NULL, NULL),
(9, 19, 'Carúpano', NULL, NULL),
(10, 7, 'Ciudad Bolívar', NULL, NULL),
(11, 7, 'Ciudad Guayana', NULL, NULL),
(12, 11, 'Coro', NULL, NULL),
(13, 19, 'Cumaná', NULL, NULL),
(14, 3, 'El Tigre', NULL, NULL),
(15, 18, 'Guanare', NULL, NULL),
(16, 4, 'Guasdualito', NULL, NULL),
(17, 24, 'La Guaira', NULL, NULL),
(18, 15, 'Los Teques', NULL, NULL),
(19, 23, 'Maracaibo', NULL, NULL),
(20, 5, 'Maracay', NULL, NULL),
(21, 16, 'Maturín', NULL, NULL),
(22, 14, 'Mérida', NULL, NULL),
(23, 8, 'Puerto Cabello', NULL, NULL),
(24, 3, 'Puerto La Cruz', NULL, NULL),
(25, 11, 'Punto Fijo', NULL, NULL),
(26, 20, 'San Antonio', NULL, NULL),
(27, 9, 'San Carlos', NULL, NULL),
(28, 20, 'San Cristóbal', NULL, NULL),
(29, 22, 'San Felipe', NULL, NULL),
(30, 4, 'San Fernando de Apure', NULL, NULL),
(31, 12, 'San Juan de los Morros', NULL, NULL),
(32, 21, 'Trujillo', NULL, NULL),
(33, 10, 'Tucupita', NULL, NULL),
(34, 8, 'Valencia', NULL, NULL),
(35, 21, 'Valera', NULL, NULL),
(36, 12, 'Valle de La Pascua', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comments_of_reviews`
--

CREATE TABLE IF NOT EXISTS `comments_of_reviews` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `review_id` int(11) unsigned NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `comments_of_reviews`
--

INSERT INTO `comments_of_reviews` (`id`, `user_id`, `review_id`, `body`, `created`, `modified`) VALUES
(1, 5, 1, 'ok me gusta,  pero creo que con el ferrari se puede recorrer grandes distancias.', '2012-01-09 07:07:58', '2012-01-09 07:08:01'),
(2, 5, 1, 'pero yo para recorrer grandes distancias prefiero un falcon 7', '2012-01-10 14:00:39', '2012-01-10 14:00:41');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `companies`
--

CREATE TABLE IF NOT EXISTS `companies` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `rif` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `policies` text COLLATE utf8_unicode_ci,
  `policies_status` int(1) unsigned NOT NULL DEFAULT '0',
  `warranties` text COLLATE utf8_unicode_ci,
  `warranties_status` int(1) unsigned NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `companies`
--

INSERT INTO `companies` (`id`, `name`, `type`, `rif`, `policies`, `policies_status`, `warranties`, `warranties_status`, `status`, `created`, `modified`) VALUES
(1, 'Santo Mercado Venezuela', 'C.A', 'J-77777777-G', 'si compras 2 te llevas 33 gratis', 1, 'todas las grarantias posibles', 1, 1, '2012-01-18 00:00:00', '2012-02-05 22:27:34'),
(2, 'Ciaela', 'S.A', 'J-77777771-G', '', 0, '', 0, 1, '2012-01-18 00:00:00', '2012-01-18 00:00:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `countries`
--

CREATE TABLE IF NOT EXISTS `countries` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `countries`
--

INSERT INTO `countries` (`id`, `name`, `created`, `modified`) VALUES
(1, 'Venezuela', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `departments`
--

CREATE TABLE IF NOT EXISTS `departments` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `manufacturer_id` int(11) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `departments`
--

INSERT INTO `departments` (`id`, `manufacturer_id`, `name`, `created`, `modified`) VALUES
(1, 1, 'computacion', '2012-01-18 18:43:58', '2012-01-18 18:44:01');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `features`
--

CREATE TABLE IF NOT EXISTS `features` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `feature_name_id` int(11) unsigned NOT NULL,
  `part_id` int(11) unsigned NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `feature_names`
--

CREATE TABLE IF NOT EXISTS `feature_names` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(11) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `feature_names`
--

INSERT INTO `feature_names` (`id`, `category_id`, `name`, `created`, `modified`) VALUES
(1, 1, 'PCI 3.0', '2012-01-21 16:00:02', '2012-01-21 16:00:05'),
(2, 1, 'Server', '2012-01-21 16:00:08', '2012-01-21 16:00:10');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `helpful_comments_of_reviews`
--

CREATE TABLE IF NOT EXISTS `helpful_comments_of_reviews` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `comments_of_review_id` int(11) unsigned NOT NULL,
  `yes_or_no` int(1) unsigned NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `helpful_comments_of_reviews`
--

INSERT INTO `helpful_comments_of_reviews` (`id`, `user_id`, `comments_of_review_id`, `yes_or_no`, `created`, `modified`) VALUES
(1, 4, 2, 1, '2012-01-10 13:55:34', '2012-01-10 14:04:59'),
(2, 4, 1, 1, '2012-01-10 14:05:10', '2012-01-10 14:05:40');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `helpful_reviews`
--

CREATE TABLE IF NOT EXISTS `helpful_reviews` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `review_id` int(11) unsigned NOT NULL,
  `yes_or_no` int(1) DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `helpful_reviews`
--

INSERT INTO `helpful_reviews` (`id`, `user_id`, `review_id`, `yes_or_no`, `created`, `modified`) VALUES
(2, 4, 1, 0, '2012-01-08 18:20:58', '2012-01-10 14:09:12');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `images`
--

CREATE TABLE IF NOT EXISTS `images` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `deleted` int(1) unsigned NOT NULL DEFAULT '0' COMMENT '1 es eliminadado',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1062 ;

--
-- Volcado de datos para la tabla `images`
--

INSERT INTO `images` (`id`, `product_id`, `name`, `deleted`, `created`, `modified`) VALUES
(1, 1, 'corsair_800d_1734.jpg', 0, '2011-12-28 18:42:31', '2011-12-28 18:42:31'),
(2, 1, 'corsair_800d_1730.jpg', 0, '2011-12-28 18:42:31', '2011-12-28 18:42:31'),
(3, 1, 'corsair_800d_1731.jpg', 0, '2011-12-28 18:42:31', '2011-12-28 18:42:31'),
(4, 1, 'corsair_800d_1732.jpg', 0, '2011-12-28 18:42:31', '2011-12-28 18:42:31'),
(5, 1, 'corsair_800d_1733.jpg', 0, '2011-12-28 18:42:31', '2011-12-28 18:42:31'),
(6, 2, '132-LF-E655-KR_XL_14.jpg', 0, '2011-12-28 18:43:07', '2011-12-28 18:43:07'),
(7, 2, '132-LF-E655-KR_XL_10.jpg', 0, '2011-12-28 18:43:07', '2011-12-28 18:43:07'),
(8, 2, '132-LF-E655-KR_XL_11.jpg', 0, '2011-12-28 18:43:07', '2011-12-28 18:43:07'),
(9, 2, '132-LF-E655-KR_XL_12.jpg', 0, '2011-12-28 18:43:07', '2011-12-28 18:43:07'),
(10, 2, '132-LF-E655-KR_XL_13.jpg', 0, '2011-12-28 18:43:07', '2011-12-28 18:43:07'),
(11, 2, '285x5820classifedme39.jpg', 0, '2011-12-28 18:43:16', '2011-12-28 18:43:16'),
(12, 2, '285x5820classifedme35.jpg', 0, '2011-12-28 18:43:16', '2011-12-28 18:43:16'),
(13, 2, '285x5820classifedme36.jpg', 0, '2011-12-28 18:43:16', '2011-12-28 18:43:16'),
(14, 2, '285x5820classifedme37.jpg', 0, '2011-12-28 18:43:16', '2011-12-28 18:43:16'),
(15, 2, '285x5820classifedme38.jpg', 0, '2011-12-28 18:43:16', '2011-12-28 18:43:16'),
(16, 3, '790iUltra_top4.jpg', 0, '2011-12-28 18:43:47', '2011-12-28 18:43:47'),
(17, 3, '790iUltra_top0.jpg', 0, '2011-12-28 18:43:47', '2011-12-28 18:43:47'),
(18, 3, '790iUltra_top1.jpg', 0, '2011-12-28 18:43:47', '2011-12-28 18:43:47'),
(19, 3, '790iUltra_top2.jpg', 0, '2011-12-28 18:43:47', '2011-12-28 18:43:47'),
(20, 3, '790iUltra_top3.jpg', 0, '2011-12-28 18:43:47', '2011-12-28 18:43:47'),
(21, 3, 'evga_x584.jpg', 0, '2011-12-28 18:43:47', '2011-12-28 18:43:47'),
(22, 3, 'evga_x580.jpg', 0, '2011-12-28 18:43:47', '2011-12-28 18:43:47'),
(23, 3, 'evga_x581.jpg', 0, '2011-12-28 18:43:47', '2011-12-28 18:43:47'),
(24, 3, 'evga_x582.jpg', 0, '2011-12-28 18:43:47', '2011-12-28 18:43:47'),
(25, 3, 'evga_x583.jpg', 0, '2011-12-28 18:43:47', '2011-12-28 18:43:47'),
(26, 4, 'EVGA-SR2-324.jpg', 0, '2011-12-28 18:44:25', '2011-12-28 18:44:25'),
(27, 4, 'EVGA-SR2-320.jpg', 0, '2011-12-28 18:44:25', '2011-12-28 18:44:25'),
(28, 4, 'EVGA-SR2-321.jpg', 0, '2011-12-28 18:44:25', '2011-12-28 18:44:25'),
(29, 4, 'EVGA-SR2-322.jpg', 0, '2011-12-28 18:44:25', '2011-12-28 18:44:25'),
(30, 4, 'EVGA-SR2-323.jpg', 0, '2011-12-28 18:44:25', '2011-12-28 18:44:25'),
(31, 4, '93925-evga-gtx-580-superclocked-14.png', 0, '2011-12-28 18:44:25', '2011-12-28 18:44:25'),
(32, 4, '93925-evga-gtx-580-superclocked-10.png', 0, '2011-12-28 18:44:25', '2011-12-28 18:44:25'),
(33, 4, '93925-evga-gtx-580-superclocked-11.png', 0, '2011-12-28 18:44:25', '2011-12-28 18:44:25'),
(34, 4, '93925-evga-gtx-580-superclocked-12.png', 0, '2011-12-28 18:44:25', '2011-12-28 18:44:25'),
(35, 4, '93925-evga-gtx-580-superclocked-13.png', 0, '2011-12-28 18:44:25', '2011-12-28 18:44:25'),
(36, 5, 'p021209141000019.jpg', 1, '2011-12-28 18:45:06', '2011-12-28 18:45:06'),
(37, 5, 'p021209141000015.jpg', 1, '2011-12-28 18:45:06', '2011-12-28 18:45:06'),
(38, 5, 'p021209141000016.jpg', 1, '2011-12-28 18:45:06', '2011-12-28 18:45:06'),
(39, 5, 'p021209141000017.jpg', 1, '2011-12-28 18:45:06', '2011-12-28 18:45:06'),
(40, 5, 'p021209141000018.jpg', 1, '2011-12-28 18:45:06', '2011-12-28 18:45:06'),
(41, 6, 'WTP_Arcade_219.jpg', 0, '2011-12-28 18:45:37', '2011-12-28 18:45:37'),
(42, 6, 'WTP_Arcade_215.jpg', 0, '2011-12-28 18:45:37', '2011-12-28 18:45:37'),
(43, 6, 'WTP_Arcade_216.jpg', 0, '2011-12-28 18:45:37', '2011-12-28 18:45:37'),
(44, 6, 'WTP_Arcade_217.jpg', 0, '2011-12-28 18:45:37', '2011-12-28 18:45:37'),
(45, 6, 'WTP_Arcade_218.jpg', 0, '2011-12-28 18:45:37', '2011-12-28 18:45:37'),
(46, 7, 'WTP_Arcade_224.jpg', 0, '2011-12-28 18:46:05', '2011-12-28 18:46:05'),
(47, 7, 'WTP_Arcade_220.jpg', 0, '2011-12-28 18:46:05', '2011-12-28 18:46:05'),
(48, 7, 'WTP_Arcade_221.jpg', 0, '2011-12-28 18:46:05', '2011-12-28 18:46:05'),
(49, 7, 'WTP_Arcade_222.jpg', 0, '2011-12-28 18:46:05', '2011-12-28 18:46:05'),
(50, 7, 'WTP_Arcade_223.jpg', 0, '2011-12-28 18:46:05', '2011-12-28 18:46:05'),
(51, 8, 's_MLC_v_F_f_38357334_728716.jpg', 0, '2011-12-28 18:46:29', '2011-12-28 18:46:29'),
(52, 8, 's_MLC_v_F_f_38357334_728712.jpg', 0, '2011-12-28 18:46:29', '2011-12-28 18:46:29'),
(53, 8, 's_MLC_v_F_f_38357334_728713.jpg', 0, '2011-12-28 18:46:29', '2011-12-28 18:46:29'),
(54, 8, 's_MLC_v_F_f_38357334_728714.jpg', 0, '2011-12-28 18:46:29', '2011-12-28 18:46:29'),
(55, 8, 's_MLC_v_F_f_38357334_728715.jpg', 0, '2011-12-28 18:46:29', '2011-12-28 18:46:29'),
(56, 9, 'WTP_Trust9.jpg', 0, '2011-12-28 18:46:51', '2011-12-28 18:46:51'),
(57, 9, 'WTP_Trust5.jpg', 0, '2011-12-28 18:46:51', '2011-12-28 18:46:51'),
(58, 9, 'WTP_Trust6.jpg', 0, '2011-12-28 18:46:51', '2011-12-28 18:46:51'),
(59, 9, 'WTP_Trust7.jpg', 0, '2011-12-28 18:46:51', '2011-12-28 18:46:51'),
(60, 9, 'WTP_Trust8.jpg', 0, '2011-12-28 18:46:51', '2011-12-28 18:46:51'),
(61, 11, '2005-Ferrari-F430-FA-Top-1280x9604.jpg', 0, '2011-12-30 16:31:11', '2011-12-30 16:31:11'),
(62, 11, '2005-Ferrari-F430-FA-Top-1280x9600.jpg', 0, '2011-12-30 16:31:11', '2011-12-30 16:31:11'),
(63, 11, '2005-Ferrari-F430-FA-Top-1280x9601.jpg', 0, '2011-12-30 16:31:11', '2011-12-30 16:31:11'),
(64, 11, '2005-Ferrari-F430-FA-Top-1280x9602.jpg', 0, '2011-12-30 16:31:12', '2011-12-30 16:31:12'),
(65, 11, '2005-Ferrari-F430-FA-Top-1280x9603.jpg', 0, '2011-12-30 16:31:12', '2011-12-30 16:31:12'),
(66, 12, 'All_PhotoGallery_L322_10MY_man_and_woman_near_building_Front3qtr-850x42534.jpg', 0, '2011-12-30 16:31:32', '2011-12-30 16:31:32'),
(67, 12, 'All_PhotoGallery_L322_10MY_man_and_woman_near_building_Front3qtr-850x42530.jpg', 0, '2011-12-30 16:31:33', '2011-12-30 16:31:33'),
(68, 12, 'All_PhotoGallery_L322_10MY_man_and_woman_near_building_Front3qtr-850x42531.jpg', 0, '2011-12-30 16:31:33', '2011-12-30 16:31:33'),
(69, 12, 'All_PhotoGallery_L322_10MY_man_and_woman_near_building_Front3qtr-850x42532.jpg', 0, '2011-12-30 16:31:33', '2011-12-30 16:31:33'),
(70, 12, 'All_PhotoGallery_L322_10MY_man_and_woman_near_building_Front3qtr-850x42533.jpg', 0, '2011-12-30 16:31:33', '2011-12-30 16:31:33'),
(71, 13, 'camioneta34.jpg', 0, '2011-12-30 16:31:49', '2011-12-30 16:31:49'),
(72, 13, 'camioneta30.jpg', 0, '2011-12-30 16:31:49', '2011-12-30 16:31:49'),
(73, 13, 'camioneta31.jpg', 0, '2011-12-30 16:31:49', '2011-12-30 16:31:49'),
(74, 13, 'camioneta32.jpg', 0, '2011-12-30 16:31:49', '2011-12-30 16:31:49'),
(75, 13, 'camioneta33.jpg', 0, '2011-12-30 16:31:49', '2011-12-30 16:31:49'),
(76, 14, 'ducati_monster74.jpg', 0, '2011-12-30 16:32:05', '2011-12-30 16:32:05'),
(77, 14, 'ducati_monster70.jpg', 0, '2011-12-30 16:32:05', '2011-12-30 16:32:05'),
(78, 14, 'ducati_monster71.jpg', 0, '2011-12-30 16:32:05', '2011-12-30 16:32:05'),
(79, 14, 'ducati_monster72.jpg', 0, '2011-12-30 16:32:05', '2011-12-30 16:32:05'),
(80, 14, 'ducati_monster73.jpg', 0, '2011-12-30 16:32:05', '2011-12-30 16:32:05'),
(81, 15, 'ferrari-458-italia_24.jpg', 0, '2011-12-30 16:32:25', '2011-12-30 16:32:25'),
(82, 15, 'ferrari-458-italia_20.jpg', 0, '2011-12-30 16:32:25', '2011-12-30 16:32:25'),
(83, 15, 'ferrari-458-italia_21.jpg', 0, '2011-12-30 16:32:25', '2011-12-30 16:32:25'),
(84, 15, 'ferrari-458-italia_22.jpg', 0, '2011-12-30 16:32:25', '2011-12-30 16:32:25'),
(85, 15, 'ferrari-458-italia_23.jpg', 0, '2011-12-30 16:32:25', '2011-12-30 16:32:25'),
(86, 16, 'ferraris-599-successor-could-get-700-hp-v12-but-no-awd-33558_14.jpg', 0, '2011-12-30 16:32:45', '2011-12-30 16:32:45'),
(87, 16, 'ferraris-599-successor-could-get-700-hp-v12-but-no-awd-33558_10.jpg', 0, '2011-12-30 16:32:45', '2011-12-30 16:32:45'),
(88, 16, 'ferraris-599-successor-could-get-700-hp-v12-but-no-awd-33558_11.jpg', 0, '2011-12-30 16:32:45', '2011-12-30 16:32:45'),
(89, 16, 'ferraris-599-successor-could-get-700-hp-v12-but-no-awd-33558_12.jpg', 0, '2011-12-30 16:32:45', '2011-12-30 16:32:45'),
(90, 16, 'ferraris-599-successor-could-get-700-hp-v12-but-no-awd-33558_13.jpg', 0, '2011-12-30 16:32:45', '2011-12-30 16:32:45'),
(91, 17, 'ferrari-scuderia-spider-16m4.jpg', 0, '2011-12-30 16:33:02', '2011-12-30 16:33:02'),
(92, 17, 'ferrari-scuderia-spider-16m0.jpg', 0, '2011-12-30 16:33:02', '2011-12-30 16:33:02'),
(93, 17, 'ferrari-scuderia-spider-16m1.jpg', 0, '2011-12-30 16:33:02', '2011-12-30 16:33:02'),
(94, 17, 'ferrari-scuderia-spider-16m2.jpg', 0, '2011-12-30 16:33:02', '2011-12-30 16:33:02'),
(95, 17, 'ferrari-scuderia-spider-16m3.jpg', 0, '2011-12-30 16:33:02', '2011-12-30 16:33:02'),
(96, 18, 'Lamborghini-Gallardo_LP560-4_Bicolore_2011_1280x960_wallpaper_054.jpg', 0, '2011-12-30 16:33:28', '2011-12-30 16:33:28'),
(97, 18, 'Lamborghini-Gallardo_LP560-4_Bicolore_2011_1280x960_wallpaper_050.jpg', 0, '2011-12-30 16:33:28', '2011-12-30 16:33:28'),
(98, 18, 'Lamborghini-Gallardo_LP560-4_Bicolore_2011_1280x960_wallpaper_051.jpg', 0, '2011-12-30 16:33:28', '2011-12-30 16:33:28'),
(99, 18, 'Lamborghini-Gallardo_LP560-4_Bicolore_2011_1280x960_wallpaper_052.jpg', 0, '2011-12-30 16:33:28', '2011-12-30 16:33:28'),
(100, 18, 'Lamborghini-Gallardo_LP560-4_Bicolore_2011_1280x960_wallpaper_053.jpg', 0, '2011-12-30 16:33:28', '2011-12-30 16:33:28'),
(101, 19, 'Lamborghini-Gallardo-LP-570-4-Superleggera114.jpg', 0, '2011-12-30 16:33:47', '2011-12-30 16:33:47'),
(102, 19, 'Lamborghini-Gallardo-LP-570-4-Superleggera110.jpg', 0, '2011-12-30 16:33:47', '2011-12-30 16:33:47'),
(103, 19, 'Lamborghini-Gallardo-LP-570-4-Superleggera111.jpg', 0, '2011-12-30 16:33:47', '2011-12-30 16:33:47'),
(104, 19, 'Lamborghini-Gallardo-LP-570-4-Superleggera112.jpg', 0, '2011-12-30 16:33:47', '2011-12-30 16:33:47'),
(105, 19, 'Lamborghini-Gallardo-LP-570-4-Superleggera113.jpg', 0, '2011-12-30 16:33:47', '2011-12-30 16:33:47'),
(106, 20, 'lamborghini-gallardo-superleggera-c4.jpg', 0, '2011-12-30 16:35:26', '2011-12-30 16:35:26'),
(107, 20, 'lamborghini-gallardo-superleggera-c0.jpg', 0, '2011-12-30 16:35:26', '2011-12-30 16:35:26'),
(108, 20, 'lamborghini-gallardo-superleggera-c1.jpg', 0, '2011-12-30 16:35:26', '2011-12-30 16:35:26'),
(109, 20, 'lamborghini-gallardo-superleggera-c2.jpg', 0, '2011-12-30 16:35:26', '2011-12-30 16:35:26'),
(110, 20, 'lamborghini-gallardo-superleggera-c3.jpg', 0, '2011-12-30 16:35:26', '2011-12-30 16:35:26'),
(111, 15, 'ferrari-458-italia-0609-14.jpg', 1, '2012-01-10 16:13:06', '2012-01-10 16:13:06'),
(112, 15, 'ferrari-458-italia-0609-10.jpg', 1, '2012-01-10 16:13:06', '2012-01-10 16:13:06'),
(113, 15, 'ferrari-458-italia-0609-11.jpg', 1, '2012-01-10 16:13:06', '2012-01-10 16:13:06'),
(114, 15, 'ferrari-458-italia-0609-12.jpg', 1, '2012-01-10 16:13:06', '2012-01-10 16:13:06'),
(115, 15, 'ferrari-458-italia-0609-13.jpg', 1, '2012-01-10 16:13:06', '2012-01-10 16:13:06'),
(116, 15, 'salvapantallas-ferrari-458-italia-94.jpg', 0, '2012-01-10 16:13:06', '2012-01-10 16:13:06'),
(117, 15, 'salvapantallas-ferrari-458-italia-90.jpg', 0, '2012-01-10 16:13:06', '2012-01-10 16:13:06'),
(118, 15, 'salvapantallas-ferrari-458-italia-91.jpg', 0, '2012-01-10 16:13:06', '2012-01-10 16:13:06'),
(119, 15, 'salvapantallas-ferrari-458-italia-92.jpg', 0, '2012-01-10 16:13:06', '2012-01-10 16:13:06'),
(120, 15, 'salvapantallas-ferrari-458-italia-93.jpg', 0, '2012-01-10 16:13:06', '2012-01-10 16:13:06'),
(191, NULL, NULL, 0, '2012-02-03 11:04:33', '2012-02-03 11:04:33'),
(192, NULL, NULL, 0, '2012-02-03 11:04:33', '2012-02-03 11:04:33'),
(193, NULL, NULL, 0, '2012-02-03 11:04:33', '2012-02-03 11:04:33'),
(194, NULL, NULL, 0, '2012-02-03 11:04:33', '2012-02-03 11:04:33'),
(195, NULL, NULL, 0, '2012-02-03 11:04:33', '2012-02-03 11:04:33'),
(196, NULL, NULL, 0, '2012-02-03 11:04:33', '2012-02-03 11:04:33'),
(197, NULL, NULL, 0, '2012-02-03 11:04:33', '2012-02-03 11:04:33'),
(198, NULL, NULL, 0, '2012-02-03 11:04:33', '2012-02-03 11:04:33'),
(199, NULL, NULL, 0, '2012-02-03 11:36:38', '2012-02-03 11:36:38'),
(200, NULL, NULL, 0, '2012-02-03 11:36:38', '2012-02-03 11:36:38'),
(201, NULL, NULL, 0, '2012-02-03 11:36:38', '2012-02-03 11:36:38'),
(202, 160, '462434_207281306038950_159625967471151_272230_935329762_o_34.jpg', 0, '2025-04-20 12:25:27', '2025-04-20 12:25:27'),
(203, 161, '462434_207281306038950_159625967471151_272230_935329762_o_35.jpg', 0, '2025-04-20 12:26:44', '2025-04-20 12:26:44'),
(204, 162, '462434_207281306038950_159625967471151_272230_935329762_o_36.jpg', 0, '2025-04-20 12:27:09', '2025-04-20 12:27:09'),
(205, 163, '462434_207281306038950_159625967471151_272230_935329762_o_37.jpg', 0, '2025-04-20 12:32:42', '2025-04-20 12:32:42'),
(206, 164, '462434_207281306038950_159625967471151_272230_935329762_o_38.jpg', 0, '2025-04-20 12:33:39', '2025-04-20 12:33:39'),
(207, 164, '462434_207281306038950_159625967471151_272230_935329762_o_39.jpg', 0, '2025-04-20 12:34:11', '2025-04-20 12:34:11'),
(208, 165, '462434_207281306038950_159625967471151_272230_935329762_o_40.jpg', 0, '2025-04-20 12:34:43', '2025-04-20 12:34:43'),
(209, 165, '462434_207281306038950_159625967471151_272230_935329762_o_41.jpg', 0, '2025-04-20 12:34:46', '2025-04-20 12:34:46'),
(210, 165, '462434_207281306038950_159625967471151_272230_935329762_o_42.jpg', 0, '2025-04-20 12:34:54', '2025-04-20 12:34:54'),
(211, 165, 'captura_de_pantalla_de_2012_06_24_01_28_53_15.png', 0, '2025-04-20 12:34:54', '2025-04-20 12:34:54'),
(212, 165, '462434_207281306038950_159625967471151_272230_935329762_o_43.jpg', 0, '2025-04-20 12:35:04', '2025-04-20 12:35:04'),
(213, 165, 'captura_de_pantalla_de_2012_06_24_01_28_53_16.png', 0, '2025-04-20 12:35:04', '2025-04-20 12:35:04'),
(214, 165, 'captura_de_pantalla_de_2025_04_19_11_34_07_5.png', 0, '2025-04-20 12:35:04', '2025-04-20 12:35:04'),
(215, 165, 'captura_de_pantalla_de_2025_04_19_12_26_14_4.png', 0, '2025-04-20 12:35:05', '2025-04-20 12:35:05'),
(216, 165, 'captura_de_pantalla_de_2025_04_19_12_26_18_4.png', 0, '2025-04-20 12:35:05', '2025-04-20 12:35:05'),
(217, 165, 'captura_de_pantalla_de_2025_04_19_12_26_21_4.png', 0, '2025-04-20 12:35:05', '2025-04-20 12:35:05'),
(218, 165, 'captura_de_pantalla_de_2025_04_19_12_26_13_4.png', 0, '2025-04-20 12:35:05', '2025-04-20 12:35:05'),
(219, 165, 'captura_de_pantalla_de_2025_04_19_12_32_22_0.png', 0, '2025-04-20 12:35:06', '2025-04-20 12:35:06'),
(220, 165, 'captura_de_pantalla_de_2025_04_19_12_26_20_4.png', 0, '2025-04-20 12:35:06', '2025-04-20 12:35:06'),
(221, 165, 'captura_de_pantalla_de_2025_04_19_12_26_10_4.png', 0, '2025-04-20 12:35:06', '2025-04-20 12:35:06'),
(222, 165, 'captura_de_pantalla_de_2025_04_19_12_26_16_4.png', 0, '2025-04-20 12:35:06', '2025-04-20 12:35:06'),
(223, 165, 'captura_de_pantalla_de_2025_04_19_11_34_07_6.png', 0, '2025-04-20 12:35:19', '2025-04-20 12:35:19'),
(224, 165, 'captura_de_pantalla_de_2025_04_19_12_26_13_5.png', 0, '2025-04-20 12:35:19', '2025-04-20 12:35:19'),
(225, 165, 'captura_de_pantalla_de_2025_04_19_12_26_10_5.png', 0, '2025-04-20 12:35:20', '2025-04-20 12:35:20'),
(226, 165, 'captura_de_pantalla_de_2012_06_24_01_28_53_17.png', 0, '2025-04-20 12:35:20', '2025-04-20 12:35:20'),
(227, 165, '462434_207281306038950_159625967471151_272230_935329762_o_44.jpg', 0, '2025-04-20 12:35:20', '2025-04-20 12:35:20'),
(228, 165, 'captura_de_pantalla_de_2025_04_19_12_26_14_5.png', 0, '2025-04-20 12:35:21', '2025-04-20 12:35:21'),
(229, 165, 'captura_de_pantalla_de_2025_04_19_12_26_21_5.png', 0, '2025-04-20 12:35:21', '2025-04-20 12:35:21'),
(230, 165, 'captura_de_pantalla_de_2025_04_19_12_26_18_5.png', 0, '2025-04-20 12:35:21', '2025-04-20 12:35:21'),
(231, 165, 'captura_de_pantalla_de_2025_04_19_12_26_16_5.png', 0, '2025-04-20 12:35:21', '2025-04-20 12:35:21'),
(232, 165, 'captura_de_pantalla_de_2025_04_19_12_26_20_5.png', 0, '2025-04-20 12:35:21', '2025-04-20 12:35:21'),
(233, 165, 'captura_de_pantalla_de_2025_04_19_12_32_22_1.png', 0, '2025-04-20 12:35:22', '2025-04-20 12:35:22'),
(234, 166, 'captura_de_pantalla_de_2012_06_24_01_28_53_18.png', 0, '2025-04-20 12:35:35', '2025-04-20 12:35:35'),
(235, 167, 'captura_de_pantalla_de_2025_04_19_12_26_13_6.png', 0, '2025-04-20 12:35:35', '2025-04-20 12:35:35'),
(236, 168, 'captura_de_pantalla_de_2025_04_19_11_34_07_7.png', 0, '2025-04-20 12:35:35', '2025-04-20 12:35:35'),
(237, 169, 'captura_de_pantalla_de_2025_04_19_12_26_14_6.png', 0, '2025-04-20 12:35:36', '2025-04-20 12:35:36'),
(238, 170, '462434_207281306038950_159625967471151_272230_935329762_o_45.jpg', 0, '2025-04-20 12:35:36', '2025-04-20 12:35:36'),
(239, 171, 'captura_de_pantalla_de_2025_04_19_12_26_21_6.png', 0, '2025-04-20 12:35:36', '2025-04-20 12:35:36'),
(240, 172, 'captura_de_pantalla_de_2025_04_19_12_26_10_6.png', 0, '2025-04-20 12:35:36', '2025-04-20 12:35:36'),
(241, 173, 'captura_de_pantalla_de_2025_04_19_12_32_22_2.png', 0, '2025-04-20 12:35:37', '2025-04-20 12:35:37'),
(242, 174, 'captura_de_pantalla_de_2025_04_19_12_26_16_6.png', 0, '2025-04-20 12:35:37', '2025-04-20 12:35:37'),
(243, 175, 'captura_de_pantalla_de_2025_04_19_12_26_18_6.png', 0, '2025-04-20 12:35:37', '2025-04-20 12:35:37'),
(244, 176, 'captura_de_pantalla_de_2025_04_19_12_26_20_6.png', 0, '2025-04-20 12:35:37', '2025-04-20 12:35:37'),
(245, 176, '462434_207281306038950_159625967471151_272230_935329762_o_46.jpg', 0, '2025-04-20 12:36:01', '2025-04-20 12:36:01'),
(246, 176, '462434_207281306038950_159625967471151_272230_935329762_o_47.jpg', 0, '2025-04-20 12:36:12', '2025-04-20 12:36:12'),
(247, 176, '462434_207281306038950_159625967471151_272230_935329762_o_48.jpg', 0, '2025-04-20 12:37:54', '2025-04-20 12:37:54'),
(248, 177, '462434_207281306038950_159625967471151_272230_935329762_o_49.jpg', 0, '2012-06-29 11:53:59', '2012-06-29 11:53:59'),
(249, 178, 'captura_de_pantalla_de_2025_04_19_12_26_10_7.png', 0, '2012-06-29 11:53:59', '2012-06-29 11:53:59'),
(250, 179, 'captura_de_pantalla_de_2012_06_24_01_28_53_19.png', 0, '2012-06-29 11:53:59', '2012-06-29 11:53:59'),
(251, 180, 'captura_de_pantalla_de_2025_04_19_11_34_07_8.png', 0, '2012-06-29 11:53:59', '2012-06-29 11:53:59'),
(252, 181, 'captura_de_pantalla_de_2025_04_19_12_26_18_7.png', 0, '2012-06-29 11:54:00', '2012-06-29 11:54:00'),
(253, 182, 'captura_de_pantalla_de_2025_04_19_12_26_16_7.png', 0, '2012-06-29 11:54:00', '2012-06-29 11:54:00'),
(254, 183, 'captura_de_pantalla_de_2025_04_19_12_26_14_7.png', 0, '2012-06-29 11:54:00', '2012-06-29 11:54:00'),
(255, 184, 'captura_de_pantalla_de_2025_04_19_12_26_20_7.png', 0, '2012-06-29 11:54:00', '2012-06-29 11:54:00'),
(256, 185, 'captura_de_pantalla_de_2025_04_19_12_26_21_7.png', 0, '2012-06-29 11:54:00', '2012-06-29 11:54:00'),
(257, 186, 'captura_de_pantalla_de_2025_04_19_12_32_22_3.png', 0, '2012-06-29 11:54:00', '2012-06-29 11:54:00'),
(258, 187, 'captura_de_pantalla_de_2025_04_19_12_26_13_7.png', 0, '2012-06-29 11:54:01', '2012-06-29 11:54:01'),
(259, 187, '462434_207281306038950_159625967471151_272230_935329762_o_50.jpg', 0, '2012-06-29 11:54:07', '2012-06-29 11:54:07'),
(260, 187, 'captura_de_pantalla_de_2012_06_24_01_28_53_20.png', 0, '2012-06-29 11:54:07', '2012-06-29 11:54:07'),
(261, 188, '462434_207281306038950_159625967471151_272230_935329762_o_51.jpg', 0, '2012-06-29 20:08:29', '2012-06-29 20:08:29'),
(262, 188, 'captura_de_pantalla_de_2025_04_19_12_26_18_8.png', 0, '2012-06-29 20:08:32', '2012-06-29 20:08:32'),
(263, NULL, '462434_207281306038950_159625967471151_272230_935329762_o0.jpg', 1, '2012-07-15 22:06:43', '2012-07-15 22:06:43'),
(264, NULL, 'Capturadepantallade2025-04-191226130.png', 1, '2012-07-15 22:06:43', '2012-07-15 22:06:43'),
(265, NULL, 'Capturadepantallade2012-07-130032430.png', 1, '2012-07-15 22:06:44', '2012-07-15 22:06:44'),
(266, NULL, '462434_207281306038950_159625967471151_272230_935329762_o1.jpg', 1, '2012-07-15 22:08:59', '2012-07-15 22:08:59'),
(267, NULL, NULL, 1, '2012-07-15 22:10:02', '2012-07-15 22:10:02'),
(268, NULL, NULL, 1, '2012-07-15 22:16:28', '2012-07-15 22:16:28'),
(269, NULL, '462434_207281306038950_159625967471151_272230_935329762_o2.jpg', 1, '2012-07-15 22:17:19', '2012-07-15 22:17:19'),
(270, NULL, '462434_207281306038950_159625967471151_272230_935329762_o3.jpg', 1, '2012-07-15 22:17:35', '2012-07-15 22:17:35'),
(271, NULL, '462434_207281306038950_159625967471151_272230_935329762_o4.jpg', 1, '2012-07-15 22:19:02', '2012-07-15 22:19:02'),
(272, NULL, 'Capturadepantallade2025-04-191226140.png', 1, '2012-07-15 22:20:57', '2012-07-15 22:20:57'),
(273, NULL, '462434_207281306038950_159625967471151_272230_935329762_o5.jpg', 1, '2012-07-15 22:21:16', '2012-07-15 22:21:16'),
(274, NULL, 'Capturadepantallade2025-04-191226141.png', 1, '2012-07-15 22:21:16', '2012-07-15 22:21:16'),
(275, NULL, 'Capturadepantallade2025-04-191226180.png', 1, '2012-07-15 22:21:16', '2012-07-15 22:21:16'),
(276, NULL, '462434_207281306038950_159625967471151_272230_935329762_o6.jpg', 1, '2012-07-15 22:23:43', '2012-07-15 22:23:43'),
(277, NULL, 'Capturadepantallade2012-07-130033110.png', 1, '2012-07-15 22:23:43', '2012-07-15 22:23:43'),
(278, NULL, 'Capturadepantallade2025-04-191226181.png', 1, '2012-07-15 22:23:43', '2012-07-15 22:23:43'),
(279, NULL, '462434_207281306038950_159625967471151_272230_935329762_o7.jpg', 0, '2012-07-15 22:29:37', '2012-07-15 22:29:37'),
(280, NULL, '462434_207281306038950_159625967471151_272230_935329762_o8.jpg', 0, '2012-07-16 11:48:12', '2012-07-16 11:48:12'),
(281, NULL, 'Capturadepantallade2012-07-130032431.png', 0, '2012-07-16 11:48:12', '2012-07-16 11:48:12'),
(282, NULL, 'Capturadepantallade2025-04-191226100.png', 0, '2012-07-16 11:48:13', '2012-07-16 11:48:13'),
(283, NULL, 'Capturadepantallade2025-04-191226160.png', 0, '2012-07-16 11:51:40', '2012-07-16 11:51:40'),
(284, NULL, '462434_207281306038950_159625967471151_272230_935329762_o9.jpg', 0, '2012-07-16 11:51:40', '2012-07-16 11:51:40'),
(285, NULL, '462434_207281306038950_159625967471151_272230_935329762_o10.jpg', 0, '2012-07-16 11:52:39', '2012-07-16 11:52:39'),
(286, NULL, '462434_207281306038950_159625967471151_272230_935329762_o11.jpg', 0, '2012-07-16 11:53:54', '2012-07-16 11:53:54'),
(287, NULL, '462434_207281306038950_159625967471151_272230_935329762_o12.jpg', 0, '2012-07-16 12:21:29', '2012-07-16 12:21:29'),
(288, NULL, '462434_207281306038950_159625967471151_272230_935329762_o13.jpg', 0, '2012-07-16 12:23:58', '2012-07-16 12:23:58'),
(289, NULL, '462434_207281306038950_159625967471151_272230_935329762_o14.jpg', 0, '2012-07-16 12:24:12', '2012-07-16 12:24:12'),
(290, NULL, 'Capturadepantallade2012-07-130033111.png', 0, '2012-07-16 12:24:12', '2012-07-16 12:24:12'),
(291, NULL, 'Capturadepantallade2025-04-191226101.png', 0, '2012-07-16 12:24:13', '2012-07-16 12:24:13'),
(292, NULL, 'Capturadepantallade2025-04-191226131.png', 0, '2012-07-16 12:24:13', '2012-07-16 12:24:13'),
(293, NULL, 'Capturadepantallade2025-04-191226142.png', 0, '2012-07-16 12:24:13', '2012-07-16 12:24:13'),
(294, NULL, 'Capturadepantallade2012-07-130032432.png', 0, '2012-07-16 12:24:13', '2012-07-16 12:24:13'),
(295, NULL, 'Capturadepantallade2012-06-240128530.png', 0, '2012-07-16 12:24:13', '2012-07-16 12:24:13'),
(296, NULL, 'Capturadepantallade2025-04-191134070.png', 0, '2012-07-16 12:24:14', '2012-07-16 12:24:14'),
(297, NULL, 'Capturadepantallade2025-04-191226182.png', 0, '2012-07-16 12:24:14', '2012-07-16 12:24:14'),
(298, NULL, 'Capturadepantallade2025-04-191226210.png', 0, '2012-07-16 12:24:14', '2012-07-16 12:24:14'),
(299, NULL, 'Capturadepantallade2025-04-191226161.png', 0, '2012-07-16 12:24:14', '2012-07-16 12:24:14'),
(300, NULL, 'Capturadepantallade2025-04-191232220.png', 0, '2012-07-16 12:24:14', '2012-07-16 12:24:14'),
(301, NULL, 'Capturadepantallade2025-04-191226200.png', 0, '2012-07-16 12:24:14', '2012-07-16 12:24:14'),
(302, NULL, '462434_207281306038950_159625967471151_272230_935329762_o15.jpg', 0, '2012-07-16 12:26:00', '2012-07-16 12:26:00'),
(303, NULL, 'Capturadepantallade2025-04-191226162.png', 0, '2012-07-16 12:26:15', '2012-07-16 12:26:15'),
(304, NULL, 'Capturadepantallade2025-04-191226211.png', 0, '2012-07-16 12:26:43', '2012-07-16 12:26:43'),
(305, NULL, 'Capturadepantallade2025-04-191226212.png', 0, '2012-07-16 12:26:49', '2012-07-16 12:26:49'),
(306, NULL, 'Capturadepantallade2025-04-191226143.png', 0, '2012-07-16 12:26:50', '2012-07-16 12:26:50'),
(307, NULL, '462434_207281306038950_159625967471151_272230_935329762_o16.jpg', 0, '2012-07-16 12:27:53', '2012-07-16 12:27:53'),
(308, NULL, 'Capturadepantallade2025-04-191226183.png', 0, '2012-07-16 12:28:11', '2012-07-16 12:28:11'),
(309, NULL, 'Capturadepantallade2025-04-191226184.png', 0, '2012-07-16 12:28:21', '2012-07-16 12:28:21'),
(310, NULL, 'Capturadepantallade2025-04-191226102.png', 0, '2012-07-16 12:28:22', '2012-07-16 12:28:22'),
(311, NULL, 'Capturadepantallade2025-04-191226201.png', 0, '2012-07-16 13:01:02', '2012-07-16 13:01:02'),
(312, NULL, 'Capturadepantallade2012-07-130032433.png', 0, '2012-07-16 13:01:16', '2012-07-16 13:01:16'),
(313, NULL, 'Capturadepantallade2025-04-191226202.png', 0, '2012-07-16 13:01:17', '2012-07-16 13:01:17'),
(314, NULL, 'Capturadepantallade2025-04-191226144.png', 0, '2012-07-16 13:01:17', '2012-07-16 13:01:17'),
(315, NULL, '462434_207281306038950_159625967471151_272230_935329762_o17.jpg', 0, '2012-07-16 13:02:11', '2012-07-16 13:02:11'),
(316, NULL, '462434_207281306038950_159625967471151_272230_935329762_o18.jpg', 0, '2012-07-18 21:19:35', '2012-07-18 21:19:35'),
(317, NULL, 'Capturadepantallade2012-07-170826390.png', 0, '2012-07-18 21:20:24', '2012-07-18 21:20:24'),
(318, NULL, 'Capturadepantallade2012-07-130033112.png', 0, '2012-07-18 21:20:40', '2012-07-18 21:20:40'),
(319, NULL, 'Capturadepantallade2012-07-170826391.png', 0, '2012-07-18 21:20:40', '2012-07-18 21:20:40'),
(320, NULL, 'Capturadepantallade2025-04-191226103.png', 0, '2012-07-18 21:20:40', '2012-07-18 21:20:40'),
(321, NULL, 'Capturadepantallade2012-07-130032434.png', 0, '2012-07-18 21:27:39', '2012-07-18 21:27:39'),
(322, NULL, 'Capturadepantallade2012-07-170826360.png', 0, '2012-07-18 21:27:39', '2012-07-18 21:27:39'),
(323, NULL, 'Capturadepantallade2025-04-191226104.png', 0, '2012-07-18 21:27:39', '2012-07-18 21:27:39'),
(324, NULL, 'Capturadepantallade2012-07-170826361.png', 0, '2012-07-19 22:32:23', '2012-07-19 22:32:23'),
(325, NULL, 'Capturadepantallade2012-07-130033113.png', 0, '2012-07-19 22:32:24', '2012-07-19 22:32:24'),
(326, NULL, '462434_207281306038950_159625967471151_272230_935329762_o19.jpg', 0, '2012-07-19 22:32:24', '2012-07-19 22:32:24'),
(327, NULL, '462434_207281306038950_159625967471151_272230_935329762_o20.jpg', 0, '2012-07-22 16:59:03', '2012-07-22 16:59:03'),
(328, NULL, 'Capturadepantallade2025-04-191134071.png', 0, '2012-07-22 16:59:03', '2012-07-22 16:59:03'),
(329, NULL, '462434_207281306038950_159625967471151_272230_935329762_o21.jpg', 0, '2012-07-22 17:00:01', '2012-07-22 17:00:01'),
(330, NULL, 'Capturadepantallade2025-04-191226132.png', 0, '2012-07-22 17:00:02', '2012-07-22 17:00:02'),
(331, NULL, '462434_207281306038950_159625967471151_272230_935329762_o22.jpg', 0, '2012-07-22 19:27:33', '2012-07-22 19:27:33'),
(332, NULL, '462434_207281306038950_159625967471151_272230_935329762_o23.jpg', 0, '2012-07-22 20:31:11', '2012-07-22 20:31:11'),
(333, NULL, 'Capturadepantallade2012-07-170826392.png', 0, '2012-07-22 20:31:12', '2012-07-22 20:31:12'),
(334, NULL, 'Capturadepantallade2012-07-130032435.png', 0, '2012-07-22 20:31:12', '2012-07-22 20:31:12'),
(335, NULL, 'Capturadepantallade2025-04-191226133.png', 0, '2012-07-22 20:31:12', '2012-07-22 20:31:12'),
(336, NULL, 'Capturadepantallade2012-07-170826362.png', 0, '2012-07-22 20:33:18', '2012-07-22 20:33:18'),
(337, NULL, '462434_207281306038950_159625967471151_272230_935329762_o24.jpg', 0, '2012-07-22 20:33:18', '2012-07-22 20:33:18'),
(338, NULL, 'Capturadepantallade2025-04-191226134.png', 0, '2012-07-22 20:33:19', '2012-07-22 20:33:19'),
(339, NULL, 'Capturadepantallade2012-07-130032436.png', 0, '2012-07-22 20:33:19', '2012-07-22 20:33:19'),
(340, NULL, 'Capturadepantallade2012-07-170826363.png', 0, '2012-07-22 20:44:16', '2012-07-22 20:44:16'),
(341, NULL, 'Capturadepantallade2025-04-191226135.png', 0, '2012-07-22 20:44:17', '2012-07-22 20:44:17'),
(342, NULL, 'Capturadepantallade2025-04-191226185.png', 0, '2012-07-22 20:44:17', '2012-07-22 20:44:17'),
(343, NULL, 'Capturadepantallade2012-07-170826020.png', 0, '2012-07-22 20:44:41', '2012-07-22 20:44:41'),
(344, NULL, 'Capturadepantallade2025-04-191226136.png', 0, '2012-07-22 20:44:41', '2012-07-22 20:44:41'),
(345, NULL, 'Capturadepantallade2025-04-191226186.png', 0, '2012-07-22 20:44:41', '2012-07-22 20:44:41'),
(346, NULL, 'Capturadepantallade2025-04-191134072.png', 0, '2012-07-22 20:44:41', '2012-07-22 20:44:41'),
(347, NULL, 'Capturadepantallade2012-07-221837040.png', 0, '2012-07-22 20:46:32', '2012-07-22 20:46:32'),
(348, NULL, '462434_207281306038950_159625967471151_272230_935329762_o25.jpg', 0, '2012-07-22 20:46:33', '2012-07-22 20:46:33'),
(349, NULL, 'Capturadepantallade2025-04-191226105.png', 0, '2012-07-22 20:46:33', '2012-07-22 20:46:33'),
(350, NULL, 'Capturadepantallade2012-07-130032437.png', 0, '2012-07-22 20:52:13', '2012-07-22 20:52:13'),
(351, NULL, 'Capturadepantallade2025-04-191226137.png', 0, '2012-07-22 20:52:13', '2012-07-22 20:52:13'),
(352, NULL, 'Capturadepantallade2012-07-170826393.png', 0, '2012-07-22 20:52:13', '2012-07-22 20:52:13'),
(353, NULL, 'Capturadepantallade2025-04-191226187.png', 0, '2012-07-22 20:52:13', '2012-07-22 20:52:13'),
(354, NULL, 'Capturadepantallade2012-07-130032438.png', 0, '2012-07-22 20:54:05', '2012-07-22 20:54:05'),
(355, NULL, 'Capturadepantallade2025-04-191134073.png', 0, '2012-07-22 20:54:05', '2012-07-22 20:54:05'),
(356, NULL, 'Capturadepantallade2012-07-170826364.png', 0, '2012-07-22 20:54:05', '2012-07-22 20:54:05'),
(357, NULL, '462434_207281306038950_159625967471151_272230_935329762_o26.jpg', 0, '2012-07-22 20:54:05', '2012-07-22 20:54:05'),
(358, NULL, 'Capturadepantallade2012-07-130033114.png', 0, '2012-07-22 20:54:40', '2012-07-22 20:54:40'),
(359, NULL, 'Capturadepantallade2012-06-240128531.png', 0, '2012-07-22 20:54:40', '2012-07-22 20:54:40'),
(360, NULL, 'Capturadepantallade2025-04-191134074.png', 0, '2012-07-22 20:54:40', '2012-07-22 20:54:40'),
(361, NULL, 'Capturadepantallade2012-07-170826394.png', 0, '2012-07-22 20:54:41', '2012-07-22 20:54:41'),
(362, NULL, '462434_207281306038950_159625967471151_272230_935329762_o27.jpg', 0, '2012-07-22 20:56:48', '2012-07-22 20:56:48'),
(363, NULL, 'Capturadepantallade2025-04-191226145.png', 0, '2012-07-22 20:56:48', '2012-07-22 20:56:48'),
(364, NULL, 'Capturadepantallade2012-07-170826365.png', 0, '2012-07-22 20:56:48', '2012-07-22 20:56:48'),
(365, NULL, 'Capturadepantallade2025-04-191226138.png', 0, '2012-07-22 20:56:48', '2012-07-22 20:56:48'),
(366, NULL, 'Capturadepantallade2025-04-191134075.png', 1, '2012-07-22 20:56:49', '2012-07-22 20:56:49'),
(367, NULL, 'Capturadepantallade2025-04-191226106.png', 0, '2012-07-22 20:56:55', '2012-07-22 20:56:55'),
(368, NULL, 'Capturadepantallade2012-07-221837041.png', 0, '2012-07-22 20:56:55', '2012-07-22 20:56:55'),
(369, NULL, 'Capturadepantallade2012-07-170826395.png', 0, '2012-07-22 20:56:56', '2012-07-22 20:56:56'),
(370, NULL, '462434_207281306038950_159625967471151_272230_935329762_o28.jpg', 0, '2012-07-22 20:57:09', '2012-07-22 20:57:09'),
(371, NULL, 'Capturadepantallade2012-07-170826021.png', 0, '2012-07-22 20:57:10', '2012-07-22 20:57:10'),
(372, NULL, 'Capturadepantallade2012-07-221837042.png', 0, '2012-07-22 20:57:10', '2012-07-22 20:57:10'),
(373, NULL, 'Capturadepantallade2025-04-191226107.png', 0, '2012-07-22 20:57:10', '2012-07-22 20:57:10'),
(374, NULL, 'Capturadepantallade2012-06-240128532.png', 0, '2012-07-22 20:57:37', '2012-07-22 20:57:37'),
(375, NULL, 'Capturadepantallade2012-07-130032439.png', 0, '2012-07-22 20:57:38', '2012-07-22 20:57:38'),
(376, NULL, 'Capturadepantallade2012-07-170826022.png', 0, '2012-07-22 20:57:38', '2012-07-22 20:57:38'),
(377, NULL, '462434_207281306038950_159625967471151_272230_935329762_o29.jpg', 0, '2012-07-22 20:57:38', '2012-07-22 20:57:38'),
(378, NULL, 'Capturadepantallade2012-07-221837043.png', 1, '2012-07-22 20:57:38', '2012-07-22 20:57:38'),
(379, NULL, 'Capturadepantallade2012-07-130033115.png', 1, '2012-07-22 20:57:38', '2012-07-22 20:57:38'),
(380, NULL, 'Capturadepantallade2012-07-170826396.png', 1, '2012-07-22 20:57:39', '2012-07-22 20:57:39'),
(381, NULL, 'Capturadepantallade2025-04-191134076.png', 1, '2012-07-22 20:57:39', '2012-07-22 20:57:39'),
(382, NULL, 'Capturadepantallade2025-04-191226146.png', 1, '2012-07-22 20:57:39', '2012-07-22 20:57:39'),
(383, NULL, 'Capturadepantallade2025-04-191226108.png', 1, '2012-07-22 20:57:39', '2012-07-22 20:57:39'),
(384, NULL, 'Capturadepantallade2025-04-191226163.png', 1, '2012-07-22 20:57:39', '2012-07-22 20:57:39'),
(385, NULL, 'Capturadepantallade2025-04-191226203.png', 1, '2012-07-22 20:57:39', '2012-07-22 20:57:39'),
(386, NULL, 'Capturadepantallade2025-04-191226139.png', 1, '2012-07-22 20:57:39', '2012-07-22 20:57:39'),
(387, NULL, 'Capturadepantallade2025-04-191232221.png', 1, '2012-07-22 20:57:40', '2012-07-22 20:57:40'),
(388, NULL, 'Capturadepantallade2025-04-191226188.png', 1, '2012-07-22 20:57:40', '2012-07-22 20:57:40'),
(389, NULL, 'Capturadepantallade2012-07-170826366.png', 1, '2012-07-22 20:57:41', '2012-07-22 20:57:41'),
(390, NULL, 'Capturadepantallade2025-04-191226213.png', 1, '2012-07-22 20:57:41', '2012-07-22 20:57:41'),
(391, NULL, '462434_207281306038950_159625967471151_272230_935329762_o30.jpg', 0, '2012-07-22 20:57:57', '2012-07-22 20:57:57'),
(392, NULL, 'Capturadepantallade2025-04-1912261310.png', 0, '2012-07-22 20:57:57', '2012-07-22 20:57:57'),
(393, NULL, 'Capturadepantallade2025-04-191134077.png', 0, '2012-07-22 20:57:57', '2012-07-22 20:57:57'),
(394, NULL, 'Capturadepantallade2012-07-1300324310.png', 0, '2012-07-22 21:07:02', '2012-07-22 21:07:02'),
(395, NULL, 'Capturadepantallade2012-06-240128533.png', 0, '2012-07-22 21:07:02', '2012-07-22 21:07:02'),
(396, NULL, 'Capturadepantallade2012-07-170826367.png', 0, '2012-07-22 21:07:02', '2012-07-22 21:07:02'),
(397, NULL, '462434_207281306038950_159625967471151_272230_935329762_o31.jpg', 0, '2012-07-22 21:07:03', '2012-07-22 21:07:03'),
(398, NULL, 'Capturadepantallade2012-07-130033116.png', 0, '2012-07-22 21:07:03', '2012-07-22 21:07:03'),
(399, NULL, 'Capturadepantallade2012-07-170826023.png', 0, '2012-07-22 21:07:03', '2012-07-22 21:07:03'),
(400, NULL, 'Capturadepantallade2025-04-1912261311.png', 0, '2012-07-22 21:07:03', '2012-07-22 21:07:03'),
(401, NULL, 'Capturadepantallade2025-04-191226109.png', 0, '2012-07-22 21:07:03', '2012-07-22 21:07:03'),
(402, NULL, 'Capturadepantallade2025-04-191226147.png', 0, '2012-07-22 21:07:03', '2012-07-22 21:07:03'),
(403, NULL, 'Capturadepantallade2025-04-191134078.png', 0, '2012-07-22 21:07:04', '2012-07-22 21:07:04'),
(404, NULL, 'Capturadepantallade2012-07-221837044.png', 0, '2012-07-22 21:07:04', '2012-07-22 21:07:04'),
(405, NULL, 'Capturadepantallade2025-04-191226204.png', 0, '2012-07-22 21:07:04', '2012-07-22 21:07:04'),
(406, NULL, 'Capturadepantallade2012-07-170826397.png', 0, '2012-07-22 21:07:04', '2012-07-22 21:07:04'),
(407, NULL, 'Capturadepantallade2025-04-191226214.png', 0, '2012-07-22 21:07:04', '2012-07-22 21:07:04'),
(408, NULL, 'Capturadepantallade2025-04-191226189.png', 0, '2012-07-22 21:07:04', '2012-07-22 21:07:04'),
(409, NULL, 'Capturadepantallade2025-04-191232222.png', 0, '2012-07-22 21:07:04', '2012-07-22 21:07:04'),
(410, NULL, 'Capturadepantallade2025-04-191226164.png', 0, '2012-07-22 21:07:05', '2012-07-22 21:07:05'),
(411, NULL, 'Capturadepantallade2012-07-1300324311.png', 0, '2012-07-22 21:07:46', '2012-07-22 21:07:46'),
(412, NULL, '462434_207281306038950_159625967471151_272230_935329762_o32.jpg', 0, '2012-07-22 21:07:46', '2012-07-22 21:07:46'),
(413, NULL, 'Capturadepantallade2012-07-170826024.png', 0, '2012-07-22 21:07:46', '2012-07-22 21:07:46'),
(414, NULL, 'Capturadepantallade2012-07-170826398.png', 0, '2012-07-22 21:07:46', '2012-07-22 21:07:46'),
(415, NULL, 'Capturadepantallade2012-06-240128534.png', 0, '2012-07-22 21:07:47', '2012-07-22 21:07:47'),
(416, NULL, 'Capturadepantallade2012-07-221837045.png', 0, '2012-07-22 21:07:47', '2012-07-22 21:07:47'),
(417, NULL, 'Capturadepantallade2025-04-191134079.png', 0, '2012-07-22 21:07:47', '2012-07-22 21:07:47'),
(418, NULL, 'Capturadepantallade2025-04-1912261010.png', 0, '2012-07-22 21:07:47', '2012-07-22 21:07:47'),
(419, NULL, 'Capturadepantallade2012-07-170826368.png', 0, '2012-07-22 21:07:47', '2012-07-22 21:07:47'),
(420, NULL, 'Capturadepantallade2012-07-130033117.png', 0, '2012-07-22 21:07:48', '2012-07-22 21:07:48'),
(421, NULL, 'Capturadepantallade2025-04-1912261312.png', 0, '2012-07-22 21:07:48', '2012-07-22 21:07:48'),
(422, NULL, 'Capturadepantallade2025-04-191226148.png', 0, '2012-07-22 21:07:48', '2012-07-22 21:07:48'),
(423, NULL, 'Capturadepantallade2025-04-191226205.png', 0, '2012-07-22 21:07:48', '2012-07-22 21:07:48'),
(424, NULL, 'Capturadepantallade2025-04-1912261810.png', 0, '2012-07-22 21:07:48', '2012-07-22 21:07:48'),
(425, NULL, 'Capturadepantallade2025-04-191226165.png', 0, '2012-07-22 21:07:48', '2012-07-22 21:07:48'),
(426, NULL, 'Capturadepantallade2025-04-191226215.png', 0, '2012-07-22 21:07:48', '2012-07-22 21:07:48'),
(427, NULL, 'Capturadepantallade2025-04-191232223.png', 0, '2012-07-22 21:07:49', '2012-07-22 21:07:49'),
(428, NULL, 'Capturadepantallade2012-07-1300324312.png', 0, '2012-07-22 21:45:33', '2012-07-22 21:45:33'),
(429, NULL, '462434_207281306038950_159625967471151_272230_935329762_o33.jpg', 0, '2012-07-22 21:45:33', '2012-07-22 21:45:33'),
(430, NULL, 'Capturadepantallade2025-04-1911340710.png', 0, '2012-07-22 21:45:33', '2012-07-22 21:45:33'),
(431, NULL, 'Capturadepantallade2012-07-170826025.png', 0, '2012-07-22 21:45:33', '2012-07-22 21:45:33'),
(432, NULL, '462434_207281306038950_159625967471151_272230_935329762_o34.jpg', 0, '2012-07-22 21:52:19', '2012-07-22 21:52:19'),
(433, NULL, 'Capturadepantallade2025-04-191226149.png', 0, '2012-07-24 00:08:33', '2012-07-24 00:08:33'),
(434, NULL, 'Capturadepantallade2012-07-221837046.png', 0, '2012-07-24 00:08:33', '2012-07-24 00:08:33'),
(435, NULL, 'Capturadepantallade2012-07-1300324313.png', 0, '2012-07-24 00:08:33', '2012-07-24 00:08:33'),
(436, NULL, '462434_207281306038950_159625967471151_272230_935329762_o35.jpg', 0, '2012-07-24 00:12:06', '2012-07-24 00:12:06'),
(437, NULL, 'Capturadepantallade2025-04-191226206.png', 0, '2012-07-24 00:12:07', '2012-07-24 00:12:07'),
(438, NULL, 'Capturadepantallade2025-04-1911340711.png', 0, '2012-07-24 00:12:07', '2012-07-24 00:12:07'),
(439, NULL, 'Capturadepantallade2025-04-1912261410.png', 0, '2012-07-24 00:12:07', '2012-07-24 00:12:07'),
(440, NULL, 'Capturadepantallade2012-07-170826369.png', 0, '2012-07-24 00:12:07', '2012-07-24 00:12:07'),
(441, NULL, 'Capturadepantallade2012-06-240128535.png', 0, '2012-07-24 09:44:23', '2012-07-24 09:44:23'),
(442, NULL, '462434_207281306038950_159625967471151_272230_935329762_o36.jpg', 0, '2012-07-24 09:44:24', '2012-07-24 09:44:24'),
(443, NULL, 'Capturadepantallade2012-07-1300324314.png', 0, '2012-07-24 09:44:24', '2012-07-24 09:44:24'),
(444, NULL, '462434_207281306038950_159625967471151_272230_935329762_o37.jpg', 0, '2012-07-24 09:44:43', '2012-07-24 09:44:43'),
(445, NULL, '462434_207281306038950_159625967471151_272230_935329762_o38.jpg', 0, '2012-07-24 13:04:39', '2012-07-24 13:04:39'),
(446, NULL, '462434_207281306038950_159625967471151_272230_935329762_o39.jpg', 0, '2012-07-24 13:15:48', '2012-07-24 13:15:48'),
(447, NULL, 'Capturadepantallade2025-04-1912261011.png', 0, '2012-07-24 13:15:48', '2012-07-24 13:15:48'),
(448, NULL, '462434_207281306038950_159625967471151_272230_935329762_o40.jpg', 0, '2012-07-24 13:16:16', '2012-07-24 13:16:16'),
(449, NULL, '462434_207281306038950_159625967471151_272230_935329762_o41.jpg', 0, '2012-07-24 13:34:08', '2012-07-24 13:34:08'),
(450, NULL, '462434_207281306038950_159625967471151_272230_935329762_o42.jpg', 0, '2012-07-24 13:34:32', '2012-07-24 13:34:32'),
(451, NULL, '462434_207281306038950_159625967471151_272230_935329762_o43.jpg', 0, '2012-07-24 13:36:14', '2012-07-24 13:36:14'),
(452, NULL, '462434_207281306038950_159625967471151_272230_935329762_o44.jpg', 0, '2012-07-24 13:36:42', '2012-07-24 13:36:42'),
(453, NULL, '462434_207281306038950_159625967471151_272230_935329762_o45.jpg', 0, '2012-07-24 13:42:06', '2012-07-24 13:42:06'),
(454, NULL, '462434_207281306038950_159625967471151_272230_935329762_o46.jpg', 0, '2012-07-24 13:42:34', '2012-07-24 13:42:34'),
(455, NULL, '462434_207281306038950_159625967471151_272230_935329762_o47.jpg', 0, '2012-07-24 13:43:39', '2012-07-24 13:43:39'),
(456, NULL, '462434_207281306038950_159625967471151_272230_935329762_o48.jpg', 0, '2012-07-24 13:44:10', '2012-07-24 13:44:10'),
(457, NULL, '462434_207281306038950_159625967471151_272230_935329762_o49.jpg', 0, '2012-07-24 14:17:15', '2012-07-24 14:17:15'),
(458, NULL, '462434_207281306038950_159625967471151_272230_935329762_o50.jpg', 0, '2012-07-24 15:15:27', '2012-07-24 15:15:27'),
(459, NULL, '462434_207281306038950_159625967471151_272230_935329762_o51.jpg', 0, '2012-07-24 15:23:34', '2012-07-24 15:23:34'),
(460, NULL, '462434_207281306038950_159625967471151_272230_935329762_o52.jpg', 0, '2012-07-24 15:24:47', '2012-07-24 15:24:47'),
(461, NULL, '462434_207281306038950_159625967471151_272230_935329762_o53.jpg', 0, '2012-07-24 15:36:19', '2012-07-24 15:36:19'),
(462, NULL, 'Capturadepantallade2025-04-1912261811.png', 0, '2012-07-24 15:37:40', '2012-07-24 15:37:40'),
(463, NULL, '462434_207281306038950_159625967471151_272230_935329762_o54.jpg', 0, '2012-07-24 15:49:45', '2012-07-24 15:49:45'),
(464, NULL, '462434_207281306038950_159625967471151_272230_935329762_o55.jpg', 0, '2012-07-24 16:02:12', '2012-07-24 16:02:12'),
(465, NULL, 'Capturadepantallade2025-04-1912261313.png', 1, '2012-07-24 16:18:45', '2012-07-24 16:18:45'),
(466, NULL, '462434_207281306038950_159625967471151_272230_935329762_o56.jpg', 0, '2012-07-24 21:36:00', '2012-07-24 21:36:00'),
(467, NULL, 'Capturadepantallade2025-04-1912261812.png', 0, '2012-07-24 21:36:00', '2012-07-24 21:36:00'),
(468, NULL, 'Capturadepantallade2012-07-241448240.png', 0, '2012-07-24 21:36:00', '2012-07-24 21:36:00'),
(469, NULL, '462434_207281306038950_159625967471151_272230_935329762_o57.jpg', 1, '2012-07-24 21:36:40', '2012-07-24 21:36:40'),
(470, NULL, 'Capturadepantallade2012-07-170826026.png', 0, '2012-07-24 21:37:43', '2012-07-24 21:37:43'),
(471, NULL, 'Capturadepantallade2012-07-170826399.png', 0, '2012-07-24 21:37:43', '2012-07-24 21:37:43'),
(472, NULL, 'Capturadepantallade2012-07-241448241.png', 0, '2012-07-24 21:37:43', '2012-07-24 21:37:43'),
(473, NULL, 'Capturadepantallade2012-07-1708263610.png', 0, '2012-07-28 00:41:23', '2012-07-28 00:41:23'),
(474, NULL, '462434_207281306038950_159625967471151_272230_935329762_o58.jpg', 0, '2012-07-29 12:27:02', '2012-07-29 12:27:02'),
(475, NULL, 'Capturadepantallade2012-07-1708263611.png', 0, '2012-07-29 12:27:02', '2012-07-29 12:27:02'),
(476, NULL, 'Capturadepantallade2012-07-1300324315.png', 0, '2012-07-29 12:27:02', '2012-07-29 12:27:02'),
(477, NULL, 'Capturadepantallade2012-07-130033118.png', 0, '2012-07-29 12:27:02', '2012-07-29 12:27:02'),
(478, NULL, '462434_207281306038950_159625967471151_272230_935329762_o59.jpg', 0, '2012-07-29 12:27:21', '2012-07-29 12:27:21'),
(479, NULL, 'Capturadepantallade2012-07-241448242.png', 0, '2012-07-29 12:27:21', '2012-07-29 12:27:21'),
(480, NULL, 'Capturadepantallade2012-07-1708263612.png', 0, '2012-07-29 12:27:21', '2012-07-29 12:27:21'),
(481, NULL, 'Capturadepantallade2012-07-130033119.png', 0, '2012-07-29 12:31:07', '2012-07-29 12:31:07'),
(482, NULL, 'Capturadepantallade2025-04-1912261012.png', 0, '2012-07-29 12:31:07', '2012-07-29 12:31:07'),
(483, NULL, 'Capturadepantallade2012-07-1708263613.png', 0, '2012-07-29 12:31:08', '2012-07-29 12:31:08'),
(484, NULL, 'Capturadepantallade2012-07-170826027.png', 0, '2012-07-29 12:35:58', '2012-07-29 12:35:58'),
(485, NULL, 'Capturadepantallade2012-07-1708263910.png', 0, '2012-07-29 12:35:58', '2012-07-29 12:35:58'),
(486, NULL, '462434_207281306038950_159625967471151_272230_935329762_o60.jpg', 0, '2012-07-29 12:35:58', '2012-07-29 12:35:58'),
(487, NULL, 'Capturadepantallade2025-04-191226207.png', 0, '2012-07-29 12:36:23', '2012-07-29 12:36:23'),
(488, NULL, '462434_207281306038950_159625967471151_272230_935329762_o61.jpg', 0, '2012-07-29 12:36:47', '2012-07-29 12:36:47'),
(489, NULL, 'Capturadepantallade2025-04-1912261813.png', 0, '2012-07-29 12:38:16', '2012-07-29 12:38:16'),
(490, NULL, '462434_207281306038950_159625967471151_272230_935329762_o62.jpg', 0, '2012-07-29 12:39:51', '2012-07-29 12:39:51'),
(491, NULL, '462434_207281306038950_159625967471151_272230_935329762_o63.jpg', 0, '2012-07-29 12:41:08', '2012-07-29 12:41:08'),
(492, NULL, 'Capturadepantallade2012-07-221837047.png', 0, '2012-07-29 12:43:01', '2012-07-29 12:43:01'),
(493, NULL, 'Capturadepantallade2025-04-1912261013.png', 0, '2012-07-29 12:43:02', '2012-07-29 12:43:02'),
(494, NULL, 'Capturadepantallade2012-07-170826028.png', 0, '2012-07-29 12:43:02', '2012-07-29 12:43:02'),
(495, NULL, '462434_207281306038950_159625967471151_272230_935329762_o64.jpg', 0, '2012-07-29 12:43:02', '2012-07-29 12:43:02'),
(496, NULL, 'Capturadepantallade2012-07-1300331110.png', 0, '2012-07-29 12:43:13', '2012-07-29 12:43:13'),
(497, NULL, 'Capturadepantallade2012-07-1708263911.png', 0, '2012-07-29 12:43:13', '2012-07-29 12:43:13'),
(498, NULL, 'Capturadepantallade2012-07-241448243.png', 0, '2012-07-29 12:43:13', '2012-07-29 12:43:13'),
(499, NULL, '462434_207281306038950_159625967471151_272230_935329762_o65.jpg', 0, '2012-07-29 12:43:13', '2012-07-29 12:43:13'),
(500, NULL, 'Capturadepantallade2025-04-1912261014.png', 0, '2012-07-29 12:43:13', '2012-07-29 12:43:13'),
(501, NULL, '462434_207281306038950_159625967471151_272230_935329762_o66.jpg', 0, '2012-07-29 12:58:57', '2012-07-29 12:58:57'),
(502, NULL, '462434_207281306038950_159625967471151_272230_935329762_o67.jpg', 0, '2012-07-29 13:33:25', '2012-07-29 13:33:25'),
(503, NULL, 'Capturadepantallade2012-07-1300331111.png', 0, '2012-07-29 13:36:56', '2012-07-29 13:36:56'),
(504, NULL, '462434_207281306038950_159625967471151_272230_935329762_o68.jpg', 0, '2012-07-29 13:36:56', '2012-07-29 13:36:56'),
(505, NULL, 'Capturadepantallade2012-07-1300324316.png', 0, '2012-07-29 13:36:56', '2012-07-29 13:36:56'),
(506, NULL, 'Capturadepantallade2025-04-1911340712.png', 0, '2012-07-29 13:36:56', '2012-07-29 13:36:56'),
(507, NULL, 'Capturadepantallade2012-07-1300331112.png', 0, '2012-07-29 13:37:04', '2012-07-29 13:37:04'),
(508, NULL, 'Capturadepantallade2012-07-170826029.png', 0, '2012-07-29 13:37:04', '2012-07-29 13:37:04'),
(509, NULL, 'Capturadepantallade2025-04-1912261015.png', 0, '2012-07-29 13:37:05', '2012-07-29 13:37:05'),
(510, NULL, 'Capturadepantallade2012-07-241448244.png', 0, '2012-07-29 13:37:05', '2012-07-29 13:37:05'),
(511, NULL, '462434_207281306038950_159625967471151_272230_935329762_o69.jpg', 0, '2012-07-29 13:37:05', '2012-07-29 13:37:05'),
(512, NULL, '462434_207281306038950_159625967471151_272230_935329762_o70.jpg', 0, '2012-07-29 13:41:51', '2012-07-29 13:41:51'),
(513, NULL, 'Capturadepantallade2012-07-1300324317.png', 0, '2012-07-29 13:41:51', '2012-07-29 13:41:51'),
(514, NULL, 'Capturadepantallade2012-07-1708263912.png', 0, '2012-07-29 13:41:51', '2012-07-29 13:41:51'),
(515, NULL, 'Capturadepantallade2012-07-1708260210.png', 0, '2012-07-29 13:41:51', '2012-07-29 13:41:51'),
(516, NULL, '462434_207281306038950_159625967471151_272230_935329762_o71.jpg', 0, '2012-07-29 13:43:32', '2012-07-29 13:43:32'),
(517, NULL, 'Capturadepantallade2012-07-1300324318.png', 0, '2012-07-29 13:43:33', '2012-07-29 13:43:33'),
(518, NULL, 'Capturadepantallade2012-07-1708263913.png', 0, '2012-07-29 13:43:33', '2012-07-29 13:43:33'),
(519, NULL, 'Capturadepantallade2012-07-1300331113.png', 0, '2012-07-29 13:43:33', '2012-07-29 13:43:33'),
(520, NULL, '462434_207281306038950_159625967471151_272230_935329762_o72.jpg', 0, '2012-07-29 13:43:39', '2012-07-29 13:43:39'),
(521, NULL, 'Capturadepantallade2012-07-241448245.png', 0, '2012-07-29 13:43:40', '2012-07-29 13:43:40'),
(522, NULL, 'Capturadepantallade2012-07-1708263914.png', 0, '2012-07-29 13:43:40', '2012-07-29 13:43:40'),
(523, NULL, 'Capturadepantallade2025-04-1912261314.png', 0, '2012-07-29 13:43:40', '2012-07-29 13:43:40'),
(524, NULL, 'Capturadepantallade2012-07-1708260211.png', 0, '2012-07-29 13:43:40', '2012-07-29 13:43:40'),
(525, NULL, '462434_207281306038950_159625967471151_272230_935329762_o73.jpg', 0, '2012-07-29 13:43:52', '2012-07-29 13:43:52'),
(526, NULL, 'Capturadepantallade2012-07-1300324319.png', 0, '2012-07-29 13:43:53', '2012-07-29 13:43:53'),
(527, NULL, 'Capturadepantallade2012-07-1708263614.png', 0, '2012-07-29 13:43:53', '2012-07-29 13:43:53'),
(528, NULL, 'Capturadepantallade2012-07-1300331114.png', 0, '2012-07-29 13:43:53', '2012-07-29 13:43:53'),
(529, NULL, 'Capturadepantallade2012-07-1708263915.png', 0, '2012-07-29 13:43:53', '2012-07-29 13:43:53'),
(530, NULL, 'Capturadepantallade2012-07-221837048.png', 0, '2012-07-29 13:43:53', '2012-07-29 13:43:53'),
(531, NULL, 'Capturadepantallade2025-04-1911340713.png', 0, '2012-07-29 13:43:53', '2012-07-29 13:43:53'),
(532, NULL, 'Capturadepantallade2012-07-1708260212.png', 0, '2012-07-29 13:43:54', '2012-07-29 13:43:54'),
(533, NULL, 'Capturadepantallade2025-04-1912261016.png', 0, '2012-07-29 13:43:54', '2012-07-29 13:43:54'),
(534, NULL, 'Capturadepantallade2012-07-241448246.png', 0, '2012-07-29 13:43:54', '2012-07-29 13:43:54'),
(535, NULL, 'Capturadepantallade2025-04-1912261315.png', 0, '2012-07-29 13:43:54', '2012-07-29 13:43:54'),
(536, NULL, 'Capturadepantallade2012-06-240128536.png', 0, '2012-07-29 13:43:54', '2012-07-29 13:43:54'),
(537, NULL, 'Capturadepantallade2025-04-191226166.png', 0, '2012-07-29 13:43:54', '2012-07-29 13:43:54'),
(538, NULL, 'Capturadepantallade2025-04-1912261814.png', 0, '2012-07-29 13:43:55', '2012-07-29 13:43:55'),
(539, NULL, 'Capturadepantallade2025-04-1912261411.png', 0, '2012-07-29 13:43:55', '2012-07-29 13:43:55'),
(540, NULL, 'Capturadepantallade2025-04-191226216.png', 0, '2012-07-29 13:43:55', '2012-07-29 13:43:55'),
(541, NULL, 'Capturadepantallade2025-04-191226208.png', 0, '2012-07-29 13:43:55', '2012-07-29 13:43:55'),
(542, NULL, 'Capturadepantallade2025-04-191232224.png', 0, '2012-07-29 13:43:55', '2012-07-29 13:43:55'),
(543, NULL, 'Capturadepantallade2025-04-1912261017.png', 0, '2012-07-29 13:49:20', '2012-07-29 13:49:20'),
(544, NULL, 'Capturadepantallade2012-07-1300331115.png', 0, '2012-07-29 13:49:20', '2012-07-29 13:49:20');
INSERT INTO `images` (`id`, `product_id`, `name`, `deleted`, `created`, `modified`) VALUES
(545, NULL, '462434_207281306038950_159625967471151_272230_935329762_o74.jpg', 0, '2012-07-29 13:49:20', '2012-07-29 13:49:20'),
(546, NULL, 'Capturadepantallade2012-07-1708263615.png', 0, '2012-07-29 13:49:20', '2012-07-29 13:49:20'),
(547, NULL, 'Capturadepantallade2012-07-1708263616.png', 0, '2012-07-29 13:49:27', '2012-07-29 13:49:27'),
(548, NULL, 'Capturadepantallade2025-04-1912261018.png', 0, '2012-07-29 13:49:28', '2012-07-29 13:49:28'),
(549, NULL, '462434_207281306038950_159625967471151_272230_935329762_o75.jpg', 0, '2012-07-29 13:49:28', '2012-07-29 13:49:28'),
(550, NULL, 'Capturadepantallade2012-07-1300331116.png', 0, '2012-07-29 13:49:28', '2012-07-29 13:49:28'),
(551, NULL, 'Capturadepantallade2012-07-221837049.png', 0, '2012-07-29 13:49:28', '2012-07-29 13:49:28'),
(552, NULL, 'Capturadepantallade2012-07-1300331117.png', 0, '2012-07-29 13:52:39', '2012-07-29 13:52:39'),
(553, NULL, 'Capturadepantallade2012-07-1708263916.png', 0, '2012-07-29 13:52:39', '2012-07-29 13:52:39'),
(554, NULL, 'Capturadepantallade2025-04-1912261019.png', 0, '2012-07-29 13:52:40', '2012-07-29 13:52:40'),
(555, NULL, '462434_207281306038950_159625967471151_272230_935329762_o76.jpg', 0, '2012-07-29 13:52:49', '2012-07-29 13:52:49'),
(556, NULL, 'Capturadepantallade2025-04-1911340714.png', 0, '2012-07-29 13:52:49', '2012-07-29 13:52:49'),
(557, NULL, 'Capturadepantallade2012-07-1300331118.png', 0, '2012-07-29 13:52:49', '2012-07-29 13:52:49'),
(558, NULL, 'Capturadepantallade2012-07-1708260213.png', 0, '2012-07-29 13:52:49', '2012-07-29 13:52:49'),
(559, NULL, 'Capturadepantallade2012-06-240128537.png', 0, '2012-07-29 13:52:49', '2012-07-29 13:52:49'),
(560, NULL, 'Capturadepantallade2025-04-1912261020.png', 0, '2012-07-29 13:52:50', '2012-07-29 13:52:50'),
(561, NULL, 'Capturadepantallade2012-07-1708263617.png', 0, '2012-07-29 13:52:50', '2012-07-29 13:52:50'),
(562, NULL, 'Capturadepantallade2025-04-191226217.png', 0, '2012-07-29 13:52:50', '2012-07-29 13:52:50'),
(563, NULL, '462434_207281306038950_159625967471151_272230_935329762_o77.jpg', 0, '2012-07-29 14:06:25', '2012-07-29 14:06:25'),
(564, NULL, 'Capturadepantallade2025-04-1911340715.png', 0, '2012-07-29 14:06:25', '2012-07-29 14:06:25'),
(565, NULL, 'Capturadepantallade2012-07-1708263917.png', 0, '2012-07-29 14:06:25', '2012-07-29 14:06:25'),
(566, NULL, 'Capturadepantallade2012-07-1708260214.png', 0, '2012-07-29 14:06:25', '2012-07-29 14:06:25'),
(567, NULL, '462434_207281306038950_159625967471151_272230_935329762_o78.jpg', 0, '2012-07-29 14:06:37', '2012-07-29 14:06:37'),
(568, NULL, 'Capturadepantallade2025-04-1912261021.png', 0, '2012-07-29 14:06:37', '2012-07-29 14:06:37'),
(569, NULL, 'Capturadepantallade2012-07-1300331119.png', 0, '2012-07-29 14:06:37', '2012-07-29 14:06:37'),
(570, NULL, 'Capturadepantallade2012-07-1708263918.png', 0, '2012-07-29 14:06:38', '2012-07-29 14:06:38'),
(571, NULL, 'Capturadepantallade2012-07-1708263618.png', 0, '2012-07-29 14:10:08', '2012-07-29 14:10:08'),
(572, NULL, 'Capturadepantallade2025-04-1911340716.png', 0, '2012-07-29 14:10:08', '2012-07-29 14:10:08'),
(573, NULL, '462434_207281306038950_159625967471151_272230_935329762_o79.jpg', 0, '2012-07-29 14:10:09', '2012-07-29 14:10:09'),
(574, NULL, 'Capturadepantallade2012-07-1708263919.png', 0, '2012-07-29 14:10:09', '2012-07-29 14:10:09'),
(575, NULL, 'Capturadepantallade2025-04-1912261316.png', 0, '2012-07-29 14:10:09', '2012-07-29 14:10:09'),
(576, NULL, 'Capturadepantallade2012-07-1300324320.png', 0, '2012-07-29 18:05:12', '2012-07-29 18:05:12'),
(577, NULL, 'Capturadepantallade2025-04-1911340717.png', 0, '2012-07-29 18:05:12', '2012-07-29 18:05:12'),
(578, NULL, 'Capturadepantallade2012-07-1708263619.png', 0, '2012-07-29 18:05:13', '2012-07-29 18:05:13'),
(579, NULL, '462434_207281306038950_159625967471151_272230_935329762_o80.jpg', 0, '2012-07-29 18:05:13', '2012-07-29 18:05:13'),
(580, NULL, '462434_207281306038950_159625967471151_272230_935329762_o81.jpg', 0, '2012-07-29 18:06:42', '2012-07-29 18:06:42'),
(581, NULL, 'Capturadepantallade2025-04-1911340718.png', 0, '2012-07-29 18:06:42', '2012-07-29 18:06:42'),
(582, NULL, 'Capturadepantallade2025-04-191226167.png', 0, '2012-07-29 18:06:42', '2012-07-29 18:06:42'),
(583, NULL, 'Capturadepantallade2012-07-1708263920.png', 0, '2012-07-29 18:06:43', '2012-07-29 18:06:43'),
(584, NULL, '462434_207281306038950_159625967471151_272230_935329762_o82.jpg', 0, '2012-07-29 18:14:21', '2012-07-29 18:14:21'),
(585, NULL, '462434_207281306038950_159625967471151_272230_935329762_o83.jpg', 0, '2012-07-29 18:32:51', '2012-07-29 18:32:51'),
(586, NULL, 'Capturadepantallade2012-07-1300324321.png', 0, '2012-07-29 18:32:52', '2012-07-29 18:32:52'),
(587, NULL, 'Capturadepantallade2012-07-1708263921.png', 0, '2012-07-29 18:32:52', '2012-07-29 18:32:52'),
(588, NULL, 'Capturadepantallade2012-07-1708263620.png', 0, '2012-07-29 18:32:52', '2012-07-29 18:32:52'),
(589, NULL, 'Capturadepantallade2012-07-241448247.png', 0, '2012-07-29 18:32:52', '2012-07-29 18:32:52'),
(590, NULL, 'Capturadepantallade2012-07-1708260215.png', 0, '2012-07-29 18:33:03', '2012-07-29 18:33:03'),
(591, NULL, 'Capturadepantallade2012-07-2218370410.png', 0, '2012-07-29 18:33:04', '2012-07-29 18:33:04'),
(592, NULL, 'Capturadepantallade2025-04-1911340719.png', 0, '2012-07-29 18:33:04', '2012-07-29 18:33:04'),
(593, NULL, 'Capturadepantallade2012-07-1300331120.png', 0, '2012-07-29 18:33:04', '2012-07-29 18:33:04'),
(594, NULL, '462434_207281306038950_159625967471151_272230_935329762_o84.jpg', 0, '2012-07-29 18:33:04', '2012-07-29 18:33:04'),
(595, NULL, 'Capturadepantallade2012-07-1708260216.png', 0, '2012-07-29 18:33:47', '2012-07-29 18:33:47'),
(596, NULL, 'Capturadepantallade2025-04-1911340720.png', 0, '2012-07-29 18:33:47', '2012-07-29 18:33:47'),
(597, NULL, 'Capturadepantallade2012-07-1708260217.png', 0, '2012-07-29 18:34:26', '2012-07-29 18:34:26'),
(598, NULL, 'Capturadepantallade2012-07-2218370411.png', 0, '2012-07-29 18:34:47', '2012-07-29 18:34:47'),
(599, NULL, 'Capturadepantallade2025-04-1912261022.png', 0, '2012-07-29 18:34:47', '2012-07-29 18:34:47'),
(600, NULL, 'Capturadepantallade2012-07-1708263621.png', 0, '2012-07-29 18:34:47', '2012-07-29 18:34:47'),
(601, NULL, 'Capturadepantallade2012-07-1708263622.png', 0, '2012-07-29 18:34:59', '2012-07-29 18:34:59'),
(602, NULL, 'Capturadepantallade2012-07-241448248.png', 0, '2012-07-29 18:34:59', '2012-07-29 18:34:59'),
(603, NULL, 'Capturadepantallade2012-07-2218370412.png', 0, '2012-07-29 18:34:59', '2012-07-29 18:34:59'),
(604, NULL, 'Capturadepantallade2012-07-1708263922.png', 0, '2012-07-29 18:35:00', '2012-07-29 18:35:00'),
(605, NULL, '462434_207281306038950_159625967471151_272230_935329762_o85.jpg', 0, '2012-07-29 18:35:14', '2012-07-29 18:35:14'),
(606, NULL, 'Capturadepantallade2012-07-1708263623.png', 0, '2012-07-29 18:35:14', '2012-07-29 18:35:14'),
(607, NULL, 'Capturadepantallade2012-06-240128538.png', 0, '2012-07-29 18:35:14', '2012-07-29 18:35:14'),
(608, NULL, 'Capturadepantallade2012-07-1708260218.png', 0, '2012-07-29 18:35:15', '2012-07-29 18:35:15'),
(609, NULL, 'Capturadepantallade2012-07-1708263923.png', 0, '2012-07-29 18:35:15', '2012-07-29 18:35:15'),
(610, NULL, 'Capturadepantallade2012-07-1300324322.png', 0, '2012-07-29 18:35:15', '2012-07-29 18:35:15'),
(611, NULL, 'Capturadepantallade2012-07-1300331121.png', 0, '2012-07-29 18:35:15', '2012-07-29 18:35:15'),
(612, NULL, 'Capturadepantallade2012-07-241448249.png', 0, '2012-07-29 18:35:15', '2012-07-29 18:35:15'),
(613, NULL, 'Capturadepantallade2025-04-1912261023.png', 0, '2012-07-29 18:35:16', '2012-07-29 18:35:16'),
(614, NULL, 'Capturadepantallade2012-07-2218370413.png', 0, '2012-07-29 18:35:16', '2012-07-29 18:35:16'),
(615, NULL, 'Capturadepantallade2025-04-1912261815.png', 0, '2012-07-29 18:35:16', '2012-07-29 18:35:16'),
(616, NULL, 'Capturadepantallade2025-04-191226209.png', 0, '2012-07-29 18:35:16', '2012-07-29 18:35:16'),
(617, NULL, 'Capturadepantallade2025-04-1911340721.png', 0, '2012-07-29 18:35:16', '2012-07-29 18:35:16'),
(618, NULL, 'Capturadepantallade2025-04-1912261317.png', 0, '2012-07-29 18:35:16', '2012-07-29 18:35:16'),
(619, NULL, 'Capturadepantallade2025-04-1912261412.png', 0, '2012-07-29 18:35:17', '2012-07-29 18:35:17'),
(620, NULL, 'Capturadepantallade2025-04-191226218.png', 0, '2012-07-29 18:35:17', '2012-07-29 18:35:17'),
(621, NULL, 'Capturadepantallade2025-04-191232225.png', 0, '2012-07-29 18:35:17', '2012-07-29 18:35:17'),
(622, NULL, 'Capturadepantallade2025-04-191226168.png', 0, '2012-07-29 18:35:17', '2012-07-29 18:35:17'),
(623, NULL, '462434_207281306038950_159625967471151_272230_935329762_o86.jpg', 0, '2012-07-29 18:36:06', '2012-07-29 18:36:06'),
(624, NULL, 'Capturadepantallade2012-07-1300331122.png', 0, '2012-07-29 18:36:06', '2012-07-29 18:36:06'),
(625, NULL, 'Capturadepantallade2012-06-240128539.png', 0, '2012-07-29 18:36:07', '2012-07-29 18:36:07'),
(626, NULL, 'Capturadepantallade2012-07-1708263924.png', 0, '2012-07-29 18:36:07', '2012-07-29 18:36:07'),
(627, NULL, 'Capturadepantallade2012-07-1300324323.png', 0, '2012-07-29 18:36:07', '2012-07-29 18:36:07'),
(628, NULL, 'Capturadepantallade2012-07-1708260219.png', 0, '2012-07-29 18:36:07', '2012-07-29 18:36:07'),
(629, NULL, 'Capturadepantallade2025-04-1911340722.png', 0, '2012-07-29 18:36:07', '2012-07-29 18:36:07'),
(630, NULL, 'Capturadepantallade2025-04-1912261318.png', 0, '2012-07-29 18:36:07', '2012-07-29 18:36:07'),
(631, NULL, 'Capturadepantallade2025-04-191226169.png', 0, '2012-07-29 18:36:08', '2012-07-29 18:36:08'),
(632, NULL, 'Capturadepantallade2025-04-1912262010.png', 0, '2012-07-29 18:36:08', '2012-07-29 18:36:08'),
(633, NULL, 'Capturadepantallade2025-04-191226219.png', 0, '2012-07-29 18:36:08', '2012-07-29 18:36:08'),
(634, NULL, 'Capturadepantallade2025-04-1912261816.png', 0, '2012-07-29 18:36:08', '2012-07-29 18:36:08'),
(635, NULL, 'Capturadepantallade2025-04-1912261413.png', 0, '2012-07-29 18:36:08', '2012-07-29 18:36:08'),
(636, NULL, 'Capturadepantallade2025-04-191232226.png', 0, '2012-07-29 18:36:08', '2012-07-29 18:36:08'),
(637, NULL, 'Capturadepantallade2012-07-2414482410.png', 0, '2012-07-29 18:36:09', '2012-07-29 18:36:09'),
(638, NULL, 'Capturadepantallade2012-07-1708260220.png', 0, '2012-07-29 18:36:31', '2012-07-29 18:36:31'),
(639, NULL, 'Capturadepantallade2012-07-2218370414.png', 0, '2012-07-29 18:36:31', '2012-07-29 18:36:31'),
(640, NULL, 'Capturadepantallade2025-04-1912261024.png', 0, '2012-07-29 18:36:31', '2012-07-29 18:36:31'),
(641, NULL, 'Capturadepantallade2012-07-1708263624.png', 0, '2012-07-29 18:36:41', '2012-07-29 18:36:41'),
(642, NULL, 'Capturadepantallade2012-07-1708263925.png', 0, '2012-07-29 18:36:42', '2012-07-29 18:36:42'),
(643, NULL, 'Capturadepantallade2012-07-1708260221.png', 0, '2012-07-29 18:36:42', '2012-07-29 18:36:42'),
(644, NULL, 'Capturadepantallade2012-07-2414482411.png', 0, '2012-07-29 18:36:42', '2012-07-29 18:36:42'),
(645, NULL, 'Capturadepantallade2012-07-1708260222.png', 0, '2012-07-29 18:37:00', '2012-07-29 18:37:00'),
(646, NULL, 'Capturadepantallade2012-07-1708263926.png', 0, '2012-07-29 18:37:00', '2012-07-29 18:37:00'),
(647, NULL, 'Capturadepantallade2012-07-2414482412.png', 0, '2012-07-29 18:37:00', '2012-07-29 18:37:00'),
(648, NULL, 'Capturadepantallade2025-04-1912261025.png', 0, '2012-07-29 18:37:00', '2012-07-29 18:37:00'),
(649, NULL, 'Capturadepantallade2012-07-1300324324.png', 0, '2012-07-29 18:37:09', '2012-07-29 18:37:09'),
(650, NULL, '462434_207281306038950_159625967471151_272230_935329762_o87.jpg', 0, '2012-07-29 18:37:09', '2012-07-29 18:37:09'),
(651, NULL, 'Capturadepantallade2012-07-2218370415.png', 0, '2012-07-29 18:37:09', '2012-07-29 18:37:09'),
(652, NULL, 'Capturadepantallade2012-07-1708263625.png', 0, '2012-07-29 18:37:09', '2012-07-29 18:37:09'),
(653, NULL, 'Capturadepantallade2025-04-1912261414.png', 0, '2012-07-29 18:37:09', '2012-07-29 18:37:09'),
(654, NULL, 'Capturadepantallade2012-07-1708260223.png', 0, '2012-07-29 18:37:09', '2012-07-29 18:37:09'),
(655, NULL, 'Capturadepantallade2025-04-1911340723.png', 0, '2012-07-29 18:37:10', '2012-07-29 18:37:10'),
(656, NULL, '462434_207281306038950_159625967471151_272230_935329762_o88.jpg', 0, '2012-07-29 18:37:29', '2012-07-29 18:37:29'),
(657, NULL, 'Capturadepantallade2012-07-1708260224.png', 0, '2012-07-29 18:37:29', '2012-07-29 18:37:29'),
(658, NULL, 'Capturadepantallade2012-07-2218370416.png', 0, '2012-07-29 18:37:29', '2012-07-29 18:37:29'),
(659, NULL, 'Capturadepantallade2025-04-1911340724.png', 0, '2012-07-29 18:37:29', '2012-07-29 18:37:29'),
(660, NULL, '462434_207281306038950_159625967471151_272230_935329762_o89.jpg', 0, '2012-07-29 18:37:48', '2012-07-29 18:37:48'),
(661, NULL, 'Capturadepantallade2012-07-1708263927.png', 0, '2012-07-29 18:40:48', '2012-07-29 18:40:48'),
(662, NULL, 'Capturadepantallade2012-07-1708260225.png', 0, '2012-07-29 18:40:48', '2012-07-29 18:40:48'),
(663, NULL, 'Capturadepantallade2012-07-1300324325.png', 0, '2012-07-29 18:42:51', '2012-07-29 18:42:51'),
(664, NULL, 'Capturadepantallade2012-07-1708260226.png', 0, '2012-07-29 18:42:52', '2012-07-29 18:42:52'),
(665, NULL, 'Capturadepantallade2012-07-1708263928.png', 0, '2012-07-29 18:42:52', '2012-07-29 18:42:52'),
(666, NULL, 'Capturadepantallade2025-04-1911340725.png', 0, '2012-07-29 18:42:52', '2012-07-29 18:42:52'),
(667, NULL, 'Capturadepantallade2012-07-1300324326.png', 0, '2012-07-29 18:42:59', '2012-07-29 18:42:59'),
(668, NULL, 'Capturadepantallade2012-07-1708263929.png', 0, '2012-07-29 18:42:59', '2012-07-29 18:42:59'),
(669, NULL, 'Capturadepantallade2025-04-1912261319.png', 0, '2012-07-29 18:42:59', '2012-07-29 18:42:59'),
(670, NULL, 'Capturadepantallade2012-07-2414482413.png', 0, '2012-07-29 18:43:00', '2012-07-29 18:43:00'),
(671, NULL, 'Capturadepantallade2012-07-2218370417.png', 0, '2012-07-29 18:45:56', '2012-07-29 18:45:56'),
(672, NULL, 'Capturadepantallade2012-07-1300331123.png', 0, '2012-07-29 18:45:56', '2012-07-29 18:45:56'),
(673, NULL, 'Capturadepantallade2012-07-1708263626.png', 0, '2012-07-29 18:45:56', '2012-07-29 18:45:56'),
(674, NULL, 'Capturadepantallade2012-07-2218370418.png', 0, '2012-07-29 19:26:29', '2012-07-29 19:26:29'),
(675, NULL, 'Capturadepantallade2012-07-1300324327.png', 0, '2012-07-29 19:26:29', '2012-07-29 19:26:29'),
(676, NULL, 'Capturadepantallade2025-04-1912261320.png', 0, '2012-07-29 19:26:29', '2012-07-29 19:26:29'),
(677, NULL, '462434_207281306038950_159625967471151_272230_935329762_o90.jpg', 1, '2012-07-29 19:28:05', '2012-07-29 19:28:05'),
(678, NULL, 'Capturadepantallade2012-07-1708263930.png', 1, '2012-07-29 19:29:12', '2012-07-29 19:29:12'),
(679, NULL, 'Capturadepantallade2012-07-1300331124.png', 0, '2012-07-29 20:08:18', '2012-07-29 20:08:18'),
(680, NULL, '462434_207281306038950_159625967471151_272230_935329762_o91.jpg', 0, '2012-07-29 20:08:18', '2012-07-29 20:08:18'),
(681, NULL, 'Capturadepantallade2025-04-1912261321.png', 0, '2012-07-29 20:08:18', '2012-07-29 20:08:18'),
(682, NULL, 'Capturadepantallade2025-04-191232227.png', 0, '2012-07-29 20:08:18', '2012-07-29 20:08:18'),
(683, NULL, '462434_207281306038950_159625967471151_272230_935329762_o92.jpg', 0, '2012-07-29 20:09:12', '2012-07-29 20:09:12'),
(684, NULL, 'Capturadepantallade2012-07-1708263931.png', 0, '2012-07-29 20:09:12', '2012-07-29 20:09:12'),
(685, NULL, 'Capturadepantallade2012-07-1300324328.png', 0, '2012-07-29 20:09:12', '2012-07-29 20:09:12'),
(686, NULL, 'Capturadepantallade2012-07-1708260227.png', 0, '2012-07-29 20:09:12', '2012-07-29 20:09:12'),
(687, NULL, 'Capturadepantallade2012-07-1300331125.png', 0, '2012-07-29 20:12:13', '2012-07-29 20:12:13'),
(688, NULL, 'Capturadepantallade2025-04-1912261026.png', 0, '2012-07-29 20:12:13', '2012-07-29 20:12:13'),
(689, NULL, 'Capturadepantallade2012-07-2218370419.png', 0, '2012-07-29 20:12:14', '2012-07-29 20:12:14'),
(690, NULL, 'Capturadepantallade2012-07-1300331126.png', 0, '2012-07-29 20:13:55', '2012-07-29 20:13:55'),
(691, NULL, '462434_207281306038950_159625967471151_272230_935329762_o93.jpg', 0, '2012-07-29 20:13:55', '2012-07-29 20:13:55'),
(692, NULL, 'Capturadepantallade2012-07-2218370420.png', 0, '2012-07-29 20:13:55', '2012-07-29 20:13:55'),
(693, NULL, 'Capturadepantallade2012-07-1708263627.png', 0, '2012-07-29 20:14:30', '2012-07-29 20:14:30'),
(694, NULL, 'Capturadepantallade2025-04-1911340726.png', 0, '2012-07-29 20:14:30', '2012-07-29 20:14:30'),
(695, NULL, 'Capturadepantallade2012-07-2218370421.png', 0, '2012-07-29 20:14:30', '2012-07-29 20:14:30'),
(696, NULL, 'Capturadepantallade2012-07-1708263628.png', 0, '2012-07-29 20:18:20', '2012-07-29 20:18:20'),
(697, NULL, 'Capturadepantallade2012-07-2218370422.png', 0, '2012-07-29 20:18:20', '2012-07-29 20:18:20'),
(698, NULL, '462434_207281306038950_159625967471151_272230_935329762_o94.jpg', 0, '2012-07-29 20:20:56', '2012-07-29 20:20:56'),
(699, NULL, '462434_207281306038950_159625967471151_272230_935329762_o95.jpg', 0, '2012-07-29 20:23:58', '2012-07-29 20:23:58'),
(700, NULL, 'Capturadepantallade2025-04-1912261415.png', 0, '2012-07-29 20:24:52', '2012-07-29 20:24:52'),
(701, NULL, '462434_207281306038950_159625967471151_272230_935329762_o96.jpg', 0, '2012-07-29 20:25:33', '2012-07-29 20:25:33'),
(702, NULL, 'Capturadepantallade2012-07-1300324329.png', 0, '2012-07-29 20:26:35', '2012-07-29 20:26:35'),
(703, NULL, 'Capturadepantallade2012-07-2218370423.png', 0, '2012-07-29 20:26:35', '2012-07-29 20:26:35'),
(704, NULL, 'Capturadepantallade2012-07-1708263932.png', 1, '2012-07-29 20:27:25', '2012-07-29 20:27:25'),
(705, NULL, 'Capturadepantallade2025-04-1911340727.png', 1, '2012-07-29 20:27:25', '2012-07-29 20:27:25'),
(706, NULL, 'Capturadepantallade2025-04-1912261416.png', 1, '2012-07-29 20:27:25', '2012-07-29 20:27:25'),
(707, NULL, 'Capturadepantallade2025-04-1912261610.png', 1, '2012-07-29 20:27:25', '2012-07-29 20:27:25'),
(708, NULL, '462434_207281306038950_159625967471151_272230_935329762_o97.jpg', 1, '2012-07-29 20:29:02', '2012-07-29 20:29:02'),
(709, NULL, '462434_207281306038950_159625967471151_272230_935329762_o98.jpg', 1, '2012-07-29 20:30:03', '2012-07-29 20:30:03'),
(710, NULL, '462434_207281306038950_159625967471151_272230_935329762_o99.jpg', 0, '2012-07-29 20:31:44', '2012-07-29 20:31:44'),
(711, NULL, 'Capturadepantallade2012-07-1708260228.png', 1, '2012-07-29 20:31:45', '2012-07-29 20:31:45'),
(712, NULL, 'Capturadepantallade2012-07-2218370424.png', 1, '2012-07-29 20:31:45', '2012-07-29 20:31:45'),
(713, NULL, 'Capturadepantallade2012-07-1708263933.png', 1, '2012-07-29 20:39:20', '2012-07-29 20:39:20'),
(714, NULL, 'Capturadepantallade2012-07-1300324330.png', 1, '2012-07-29 20:39:21', '2012-07-29 20:39:21'),
(715, NULL, '462434_207281306038950_159625967471151_272230_935329762_o100.jpg', 1, '2012-07-29 20:39:21', '2012-07-29 20:39:21'),
(716, NULL, 'Capturadepantallade2012-07-1708260229.png', 1, '2012-07-29 20:39:21', '2012-07-29 20:39:21'),
(717, NULL, 'Capturadepantallade2012-07-1300331127.png', 0, '2012-07-29 20:40:06', '2012-07-29 20:40:06'),
(718, NULL, 'Capturadepantallade2012-07-2218370425.png', 1, '2012-07-29 20:40:06', '2012-07-29 20:40:06'),
(719, NULL, '462434_207281306038950_159625967471151_272230_935329762_o101.jpg', 0, '2012-07-29 20:40:07', '2012-07-29 20:40:07'),
(720, NULL, 'Capturadepantallade2025-04-1912261027.png', 1, '2012-07-29 20:40:07', '2012-07-29 20:40:07'),
(721, NULL, 'Capturadepantallade2012-07-1708263934.png', 0, '2012-07-29 20:40:07', '2012-07-29 20:40:07'),
(722, NULL, 'Capturadepantallade2012-07-1300324331.png', 1, '2012-07-29 20:40:07', '2012-07-29 20:40:07'),
(723, NULL, '462434_207281306038950_159625967471151_272230_935329762_o102.jpg', 1, '2012-07-30 10:46:34', '2012-07-30 10:46:34'),
(724, 195, '462434_207281306038950_159625967471151_272230_935329762_o103.jpg', 1, '2012-07-30 10:46:50', '2012-07-30 10:46:50'),
(725, 195, '462434_207281306038950_159625967471151_272230_935329762_o104.jpg', 1, '2012-07-30 10:47:12', '2012-07-30 10:47:12'),
(726, 195, 'Capturadepantallade2012-07-1300331128.png', 1, '2012-07-30 10:47:12', '2012-07-30 10:47:12'),
(727, 195, 'Capturadepantallade2012-07-1708263629.png', 1, '2012-07-30 10:47:12', '2012-07-30 10:47:12'),
(728, 195, 'Capturadepantallade2025-04-1911340728.png', 1, '2012-07-30 10:47:12', '2012-07-30 10:47:12'),
(729, 195, 'Capturadepantallade2012-07-2414482414.png', 1, '2012-07-30 10:47:12', '2012-07-30 10:47:12'),
(730, 195, 'Capturadepantallade2012-07-1708263935.png', 1, '2012-07-30 10:47:13', '2012-07-30 10:47:13'),
(731, 195, 'Capturadepantallade2025-04-1912261417.png', 1, '2012-07-30 10:47:13', '2012-07-30 10:47:13'),
(732, 195, '462434_207281306038950_159625967471151_272230_935329762_o105.jpg', 1, '2012-07-30 11:17:26', '2012-07-30 11:17:26'),
(733, 197, '462434_207281306038950_159625967471151_272230_935329762_o106.jpg', 1, '2012-07-30 22:00:35', '2012-07-30 22:00:35'),
(734, 197, 'Capturadepantallade2012-07-1300331129.png', 1, '2012-07-30 22:00:45', '2012-07-30 22:00:45'),
(735, 197, 'Capturadepantallade2012-07-1708263936.png', 1, '2012-07-30 22:00:55', '2012-07-30 22:00:55'),
(736, 197, 'Capturadepantallade2025-04-1912261028.png', 1, '2012-07-30 22:01:05', '2012-07-30 22:01:05'),
(737, 197, 'Capturadepantallade2012-07-2414482415.png', 1, '2012-07-30 22:01:15', '2012-07-30 22:01:15'),
(738, 198, '462434_207281306038950_159625967471151_272230_935329762_o107.jpg', 0, '2012-08-01 19:39:55', '2012-08-01 19:39:55'),
(739, 198, 'Capturadepantallade2012-07-1300331130.png', 0, '2012-08-01 19:39:55', '2012-08-01 19:39:55'),
(740, 198, 'Capturadepantallade2012-07-1300324332.png', 0, '2012-08-01 19:39:55', '2012-08-01 19:39:55'),
(741, 198, 'Capturadepantallade2012-07-1300324333.png', 1, '2012-08-01 19:40:53', '2012-08-01 19:40:53'),
(742, 198, 'Capturadepantallade2012-07-1708260230.png', 1, '2012-08-01 19:40:53', '2012-08-01 19:40:53'),
(743, 198, '462434_207281306038950_159625967471151_272230_935329762_o108.jpg', 1, '2012-08-01 19:40:53', '2012-08-01 19:40:53'),
(744, 198, 'Capturadepantallade2025-04-1911340729.png', 1, '2012-08-01 19:40:53', '2012-08-01 19:40:53'),
(745, 199, 'Capturadepantallade2025-04-1911340730.png', 1, '2012-08-01 19:45:39', '2012-08-01 19:45:39'),
(746, 199, 'Capturadepantallade2012-07-1708263630.png', 1, '2012-08-01 19:45:40', '2012-08-01 19:45:40'),
(747, 199, 'Capturadepantallade2012-07-1300324334.png', 1, '2012-08-01 19:45:40', '2012-08-01 19:45:40'),
(748, 199, '462434_207281306038950_159625967471151_272230_935329762_o109.jpg', 1, '2012-08-01 19:45:40', '2012-08-01 19:45:40'),
(749, 200, '462434_207281306038950_159625967471151_272230_935329762_o110.jpg', 1, '2012-08-01 19:46:31', '2012-08-01 19:46:31'),
(750, 201, '462434_207281306038950_159625967471151_272230_935329762_o111.jpg', 1, '2012-08-01 19:47:37', '2012-08-01 19:47:37'),
(751, 202, '462434_207281306038950_159625967471151_272230_935329762_o112.jpg', 1, '2012-08-01 19:50:19', '2012-08-01 19:50:19'),
(752, 203, '462434_207281306038950_159625967471151_272230_935329762_o113.jpg', 1, '2012-08-01 19:51:26', '2012-08-01 19:51:26'),
(753, 204, '462434_207281306038950_159625967471151_272230_935329762_o114.jpg', 0, '2012-08-01 20:16:13', '2012-08-01 20:16:13'),
(754, 204, 'Capturadepantallade2012-07-1300331131.png', 0, '2012-08-01 20:16:14', '2012-08-01 20:16:14'),
(755, 204, 'Capturadepantallade2012-07-1300324335.png', 0, '2012-08-01 20:16:14', '2012-08-01 20:16:14'),
(756, 204, 'Capturadepantallade2012-07-1708263937.png', 0, '2012-08-01 20:16:14', '2012-08-01 20:16:14'),
(757, 204, 'Capturadepantallade2012-07-1708263631.png', 0, '2012-08-01 20:16:14', '2012-08-01 20:16:14'),
(758, 204, 'Capturadepantallade2012-07-1708260231.png', 0, '2012-08-01 20:16:14', '2012-08-01 20:16:14'),
(759, 204, 'Capturadepantallade2012-06-2401285310.png', 0, '2012-08-01 20:16:15', '2012-08-01 20:16:15'),
(760, 204, 'Capturadepantallade2012-07-2218370426.png', 0, '2012-08-01 20:16:15', '2012-08-01 20:16:15'),
(761, 204, 'Capturadepantallade2012-07-2414482416.png', 0, '2012-08-01 20:16:15', '2012-08-01 20:16:15'),
(762, 204, 'Capturadepantallade2025-04-1911340731.png', 0, '2012-08-01 20:16:15', '2012-08-01 20:16:15'),
(763, 204, 'Capturadepantallade2025-04-1912261029.png', 0, '2012-08-01 20:16:15', '2012-08-01 20:16:15'),
(764, 204, 'Capturadepantallade2025-04-1912261322.png', 0, '2012-08-01 20:16:15', '2012-08-01 20:16:15'),
(765, 204, 'Capturadepantallade2025-04-1912261817.png', 0, '2012-08-01 20:16:16', '2012-08-01 20:16:16'),
(766, 204, 'Capturadepantallade2025-04-1912261611.png', 0, '2012-08-01 20:16:16', '2012-08-01 20:16:16'),
(767, 204, 'Capturadepantallade2025-04-1912261418.png', 0, '2012-08-01 20:16:16', '2012-08-01 20:16:16'),
(768, 204, 'Capturadepantallade2025-04-1912262011.png', 0, '2012-08-01 20:16:16', '2012-08-01 20:16:16'),
(769, 204, 'Capturadepantallade2025-04-191232228.png', 0, '2012-08-01 20:16:16', '2012-08-01 20:16:16'),
(770, 204, 'Capturadepantallade2025-04-1912262110.png', 0, '2012-08-01 20:16:16', '2012-08-01 20:16:16'),
(771, 204, 'Capturadepantallade2025-04-1912261030.png', 0, '2012-08-01 20:25:09', '2012-08-01 20:25:09'),
(772, 208, '462434_207281306038950_159625967471151_272230_935329762_o115.jpg', 0, '2012-08-04 18:27:26', '2012-08-04 18:27:26'),
(773, 208, 'Capturadepantallade2012-07-1300331132.png', 0, '2012-08-04 18:27:26', '2012-08-04 18:27:26'),
(774, 208, 'Capturadepantallade2012-07-1300324336.png', 0, '2012-08-04 18:27:26', '2012-08-04 18:27:26'),
(775, 208, 'Capturadepantallade2012-06-2401285311.png', 0, '2012-08-04 18:27:26', '2012-08-04 18:27:26'),
(776, 208, 'Capturadepantallade2012-07-1708263632.png', 0, '2012-08-04 18:27:26', '2012-08-04 18:27:26'),
(777, 209, '', 1, '2012-08-05 14:49:43', '2012-08-05 14:49:43'),
(778, 210, '', 1, '2012-08-05 14:53:00', '2012-08-05 14:53:00'),
(779, 211, '', 1, '2012-08-05 14:53:55', '2012-08-05 14:53:55'),
(780, 211, '', 1, '2012-08-05 14:53:55', '2012-08-05 14:53:55'),
(781, 211, '', 1, '2012-08-05 14:53:55', '2012-08-05 14:53:55'),
(782, 211, 'products462434_207281306038950_159625967471151_272230_935329762_o0.jpg', 1, '2012-08-05 14:55:51', '2012-08-05 14:55:51'),
(783, 211, 'Capturadepantallade2025-04-191226180.png', 0, '2012-08-05 14:57:11', '2012-08-05 14:57:11'),
(784, 212, 'Capturadepantallade2012-07-170826360.png', 0, '2012-08-05 14:57:50', '2012-08-05 14:57:50'),
(785, 212, 'Capturadepantallade2012-07-130033110.png', 0, '2012-08-05 14:57:50', '2012-08-05 14:57:50'),
(786, 212, 'Capturadepantallade2025-04-191226100.png', 0, '2012-08-05 14:57:50', '2012-08-05 14:57:50'),
(787, 212, 'Capturadepantallade2012-07-221837040.png', 0, '2012-08-05 14:57:51', '2012-08-05 14:57:51'),
(788, 213, '462434_207281306038950_159625967471151_272230_935329762_o0.jpg', 0, '2012-08-05 15:02:25', '2012-08-05 15:02:25'),
(789, 214, 'Capturadepantallade2012-08-031724180.png', 1, '2012-08-05 15:09:09', '2012-08-05 15:09:09'),
(790, 214, 'Capturadepantallade2012-07-170826361.png', 0, '2012-08-06 09:35:09', '2012-08-06 09:35:09'),
(791, 214, 'Capturadepantallade2012-07-221837041.png', 0, '2012-08-06 09:35:09', '2012-08-06 09:35:09'),
(792, 214, 'Capturadepantallade2012-07-130033111.png', 0, '2012-08-06 09:35:09', '2012-08-06 09:35:09'),
(793, 214, '462434_207281306038950_159625967471151_272230_935329762_o1.jpg', 0, '2012-08-06 09:35:10', '2012-08-06 09:35:10'),
(794, 214, 'Capturadepantallade2012-08-031724181.png', 0, '2012-08-06 09:35:10', '2012-08-06 09:35:10'),
(795, 214, 'Capturadepantallade2012-07-130033112.png', 0, '2012-08-06 09:39:17', '2012-08-06 09:39:17'),
(796, 214, 'Capturadepantallade2012-08-031724182.png', 0, '2012-08-06 09:39:17', '2012-08-06 09:39:17'),
(797, 214, 'Capturadepantallade2012-06-240128530.png', 0, '2012-08-06 09:39:18', '2012-08-06 09:39:18'),
(798, 214, 'Capturadepantallade2012-07-170826390.png', 0, '2012-08-06 09:39:18', '2012-08-06 09:39:18'),
(799, 214, '462434_207281306038950_159625967471151_272230_935329762_o2.jpg', 0, '2012-08-06 12:25:53', '2012-08-06 12:25:53'),
(800, 216, '462434_207281306038950_159625967471151_272230_935329762_o3.jpg', 0, '2012-08-06 22:54:36', '2012-08-06 22:54:36'),
(801, 217, '462434_207281306038950_159625967471151_272230_935329762_o4.jpg', 0, '2012-08-06 23:04:18', '2012-08-06 23:04:18'),
(802, 218, '462434_207281306038950_159625967471151_272230_935329762_o5.jpg', 1, '2012-08-06 23:10:04', '2012-08-06 23:10:04'),
(803, 221, 'Capturadepantallade2012-07-170826362.png', 1, '2012-08-07 00:21:18', '2012-08-07 00:21:18'),
(804, 221, 'Capturadepantallade2012-08-031724183.png', 1, '2012-08-07 00:21:18', '2012-08-07 00:21:18'),
(805, 221, 'Capturadepantallade2025-04-191226140.png', 1, '2012-08-07 00:21:18', '2012-08-07 00:21:18'),
(806, 221, 'Capturadepantallade2012-07-170826391.png', 1, '2012-08-07 00:21:46', '2012-08-07 00:21:46'),
(807, 221, 'Capturadepantallade2012-07-241448240.png', 1, '2012-08-07 00:21:46', '2012-08-07 00:21:46'),
(808, 221, 'Capturadepantallade2012-07-170826363.png', 1, '2012-08-07 00:21:46', '2012-08-07 00:21:46'),
(809, 221, 'Capturadepantallade2012-06-240128531.png', 1, '2012-08-07 00:21:46', '2012-08-07 00:21:46'),
(810, 221, 'Capturadepantallade2012-07-170826020.png', 0, '2012-08-07 00:22:08', '2012-08-07 00:22:08'),
(811, 221, 'Capturadepantallade2012-07-241448241.png', 0, '2012-08-07 00:22:09', '2012-08-07 00:22:09'),
(812, 221, 'Capturadepantallade2012-06-240128532.png', 0, '2012-08-07 00:22:09', '2012-08-07 00:22:09'),
(813, 219, '462434_207281306038950_159625967471151_272230_935329762_o6.jpg', 0, '2012-08-07 09:12:25', '2012-08-07 09:12:25'),
(814, 218, '462434_207281306038950_159625967471151_272230_935329762_o7.jpg', 0, '2012-08-07 20:59:40', '2012-08-07 20:59:40'),
(815, 226, '462434_207281306038950_159625967471151_272230_935329762_o8.jpg', 0, '2012-08-09 14:08:47', '2012-08-09 14:08:47'),
(816, 227, '462434_207281306038950_159625967471151_272230_935329762_o9.jpg', 0, '2012-08-09 14:15:50', '2012-08-09 14:15:50'),
(817, 228, '462434_207281306038950_159625967471151_272230_935329762_o10.jpg', 0, '2012-08-09 14:30:48', '2012-08-09 14:30:48'),
(818, 226, 'Capturadepantallade2012-07-130032430.png', 0, '2012-08-09 23:47:29', '2012-08-09 23:47:29'),
(819, 226, 'Capturadepantallade2012-07-130033113.png', 0, '2012-08-09 23:47:29', '2012-08-09 23:47:29'),
(820, 226, 'Capturadepantallade2012-07-170826364.png', 0, '2012-08-09 23:47:41', '2012-08-09 23:47:41'),
(821, 226, 'Capturadepantallade2012-07-130032431.png', 0, '2012-08-09 23:47:41', '2012-08-09 23:47:41'),
(822, 226, 'Capturadepantallade2012-07-221837042.png', 0, '2012-08-09 23:47:41', '2012-08-09 23:47:41'),
(823, 226, '462434_207281306038950_159625967471151_272230_935329762_o11.jpg', 0, '2012-08-09 23:47:59', '2012-08-09 23:47:59'),
(824, 226, '462434_207281306038950_159625967471151_272230_935329762_o12.jpg', 0, '2012-08-09 23:55:02', '2012-08-09 23:55:02'),
(825, 226, 'Capturadepantallade2012-07-221837043.png', 0, '2012-08-09 23:55:09', '2012-08-09 23:55:09'),
(826, 226, 'Capturadepantallade2012-07-170826392.png', 0, '2012-08-09 23:55:09', '2012-08-09 23:55:09'),
(827, 226, '462434_207281306038950_159625967471151_272230_935329762_o13.jpg', 0, '2012-08-09 23:58:50', '2012-08-09 23:58:50'),
(828, 226, 'Capturadepantallade2012-07-170826365.png', 0, '2012-08-09 23:58:50', '2012-08-09 23:58:50'),
(829, 226, 'Capturadepantallade2012-07-130032432.png', 0, '2012-08-09 23:58:50', '2012-08-09 23:58:50'),
(830, 226, 'Capturadepantallade2012-07-170826393.png', 0, '2012-08-09 23:58:55', '2012-08-09 23:58:55'),
(831, 226, '462434_207281306038950_159625967471151_272230_935329762_o14.jpg', 0, '2012-08-09 23:58:55', '2012-08-09 23:58:55'),
(832, 226, 'Capturadepantallade2025-04-191226141.png', 0, '2012-08-09 23:58:55', '2012-08-09 23:58:55'),
(833, 226, 'Capturadepantallade2012-07-221837044.png', 0, '2012-08-09 23:58:55', '2012-08-09 23:58:55'),
(834, 226, 'Capturadepantallade2025-04-191226130.png', 0, '2012-08-09 23:58:56', '2012-08-09 23:58:56'),
(835, 226, 'Capturadepantallade2025-04-191134070.png', 0, '2012-08-09 23:58:56', '2012-08-09 23:58:56'),
(836, 226, 'Capturadepantallade2025-04-191226200.png', 0, '2012-08-09 23:58:56', '2012-08-09 23:58:56'),
(837, 226, 'Capturadepantallade2012-08-062045580.png', 0, '2012-08-09 23:58:56', '2012-08-09 23:58:56'),
(838, 22, '462434_207281306038950_159625967471151_272230_935329762_o15.jpg', 1, '2012-08-10 13:42:21', '2012-08-10 13:42:21'),
(839, 22, 'Capturadepantallade2012-07-170826021.png', 1, '2012-08-10 13:45:51', '2012-08-10 13:45:51'),
(840, 225, '462434_207281306038950_159625967471151_272230_935329762_o16.jpg', 0, '2012-08-11 23:00:09', '2012-08-11 23:00:09'),
(841, 231, '', 1, '2012-09-11 16:25:48', '2012-09-11 16:25:48'),
(842, 231, '', 1, '2012-09-11 16:25:48', '2012-09-11 16:25:48'),
(843, 231, '', 1, '2012-09-11 16:25:48', '2012-09-11 16:25:48'),
(844, 231, '', 1, '2012-09-11 16:25:48', '2012-09-11 16:25:48'),
(845, 231, '', 1, '2012-09-11 16:25:48', '2012-09-11 16:25:48'),
(846, 231, '', 1, '2012-09-11 16:25:49', '2012-09-11 16:25:49'),
(847, 231, '', 1, '2012-09-11 16:25:49', '2012-09-11 16:25:49'),
(848, 231, '', 1, '2012-09-11 16:25:49', '2012-09-11 16:25:49'),
(849, 231, 'DSC_06760.jpg', 0, '2012-09-11 16:25:49', '2012-09-11 16:25:49'),
(850, 231, 'DSC_07000.jpg', 0, '2012-09-11 16:25:49', '2012-09-11 16:25:49'),
(851, 231, 'DSC_06690.jpg', 0, '2012-09-11 16:25:50', '2012-09-11 16:25:50'),
(852, 231, 'DSC_07080.jpg', 0, '2012-09-11 16:25:50', '2012-09-11 16:25:50'),
(853, 231, 'DSC_07240.jpg', 0, '2012-09-11 16:25:50', '2012-09-11 16:25:50'),
(854, 231, 'DSC_07250.jpg', 0, '2012-09-11 16:25:51', '2012-09-11 16:25:51'),
(855, 231, 'DSC_07310.jpg', 0, '2012-09-11 16:25:51', '2012-09-11 16:25:51'),
(856, 231, 'DSC_06840.jpg', 0, '2012-09-11 16:25:52', '2012-09-11 16:25:52'),
(857, 231, '', 1, '2012-09-11 16:25:52', '2012-09-11 16:25:52'),
(858, 231, 'DSC_06800.jpg', 0, '2012-09-11 16:25:52', '2012-09-11 16:25:52'),
(859, 231, 'DSC_07320.jpg', 0, '2012-09-11 16:25:52', '2012-09-11 16:25:52'),
(860, 231, 'DSC_09960.jpg', 0, '2012-09-11 16:25:53', '2012-09-11 16:25:53'),
(861, 231, 'DSC_07340.jpg', 0, '2012-09-11 16:25:53', '2012-09-11 16:25:53'),
(862, 231, 'DSC_09980.jpg', 0, '2012-09-11 16:25:54', '2012-09-11 16:25:54'),
(863, 231, 'DSC_10060.jpg', 0, '2012-09-11 16:25:54', '2012-09-11 16:25:54'),
(864, 231, 'DSC_10270.jpg', 0, '2012-09-11 16:25:54', '2012-09-11 16:25:54'),
(865, 231, 'DSC_10630.jpg', 0, '2012-09-11 16:25:55', '2012-09-11 16:25:55'),
(866, 231, 'DSC_10020.jpg', 0, '2012-09-11 16:25:55', '2012-09-11 16:25:55'),
(867, 231, 'DSC_10650.jpg', 0, '2012-09-11 16:25:55', '2012-09-11 16:25:55'),
(868, 231, '', 1, '2012-09-11 16:25:56', '2012-09-11 16:25:56'),
(869, 231, '', 1, '2012-09-11 16:25:56', '2012-09-11 16:25:56'),
(870, 231, '', 1, '2012-09-11 16:25:56', '2012-09-11 16:25:56'),
(871, 231, '', 1, '2012-09-11 16:25:56', '2012-09-11 16:25:56'),
(872, 231, '', 1, '2012-09-11 16:25:56', '2012-09-11 16:25:56'),
(873, 231, '', 1, '2012-09-11 16:25:56', '2012-09-11 16:25:56'),
(874, 231, '', 1, '2012-09-11 16:25:56', '2012-09-11 16:25:56'),
(875, 231, '', 1, '2012-09-11 16:25:56', '2012-09-11 16:25:56'),
(876, 231, '', 1, '2012-09-11 16:25:56', '2012-09-11 16:25:56'),
(877, 231, '', 1, '2012-09-11 16:25:56', '2012-09-11 16:25:56'),
(878, 231, '', 1, '2012-09-11 16:25:56', '2012-09-11 16:25:56'),
(879, 231, '', 1, '2012-09-11 16:25:57', '2012-09-11 16:25:57'),
(880, 231, 'PISCINACLUB0.jpg', 0, '2012-09-11 16:25:57', '2012-09-11 16:25:57'),
(881, 231, '', 1, '2012-09-11 16:25:57', '2012-09-11 16:25:57'),
(882, 231, '', 1, '2012-09-11 16:25:57', '2012-09-11 16:25:57'),
(883, 231, '', 1, '2012-09-11 16:26:47', '2012-09-11 16:26:47'),
(884, 231, '', 1, '2012-09-11 16:26:48', '2012-09-11 16:26:48'),
(885, 232, '', 1, '2012-09-11 16:27:17', '2012-09-11 16:27:17'),
(886, 233, '', 1, '2012-09-11 18:04:28', '2012-09-11 18:04:28'),
(887, 233, 'DSC033780.jpg', 1, '2012-09-11 18:05:27', '2012-09-11 18:05:27'),
(888, 234, 'DSC_06761.jpg', 0, '2012-09-11 18:05:50', '2012-09-11 18:05:50'),
(889, 234, 'DSC_06801.jpg', 0, '2012-09-11 18:05:51', '2012-09-11 18:05:51'),
(890, 234, 'DSC_07001.jpg', 0, '2012-09-11 18:05:51', '2012-09-11 18:05:51'),
(891, 234, 'DSC_07241.jpg', 0, '2012-09-11 18:05:51', '2012-09-11 18:05:51'),
(892, 234, 'DSC_06841.jpg', 0, '2012-09-11 18:05:52', '2012-09-11 18:05:52'),
(893, 234, 'DSC_07251.jpg', 0, '2012-09-11 18:05:52', '2012-09-11 18:05:52'),
(894, 234, 'DSC_07341.jpg', 0, '2012-09-11 18:05:53', '2012-09-11 18:05:53'),
(895, 234, 'DSC_07321.jpg', 1, '2012-09-11 18:05:53', '2012-09-11 18:05:53'),
(896, 234, 'DSC_09961.jpg', 0, '2012-09-11 18:05:53', '2012-09-11 18:05:53'),
(897, 234, 'DSC_07081.jpg', 0, '2012-09-11 18:05:54', '2012-09-11 18:05:54'),
(898, 234, 'DSC_07311.jpg', 0, '2012-09-11 18:05:54', '2012-09-11 18:05:54'),
(899, 235, 'DSC_06762.jpg', 0, '2012-09-11 23:26:28', '2012-09-11 23:26:28'),
(900, 235, 'DSC033781.jpg', 0, '2012-09-11 23:26:29', '2012-09-11 23:26:29'),
(901, 235, 'DSC_06691.jpg', 0, '2012-09-11 23:26:29', '2012-09-11 23:26:29'),
(902, 236, 'Capturadepantallade2012-07-221837045.png', 0, '2012-09-15 12:12:51', '2012-09-15 12:12:51'),
(903, 236, 'Capturadepantallade2012-07-170826022.png', 0, '2012-09-15 12:12:52', '2012-09-15 12:12:52'),
(904, 236, '462434_207281306038950_159625967471151_272230_935329762_o17.jpg', 0, '2012-09-15 12:12:52', '2012-09-15 12:12:52'),
(905, 237, 'DSC033782.jpg', 0, '2012-09-15 17:23:17', '2012-09-15 17:23:17'),
(906, 237, 'DSC_06763.jpg', 0, '2012-09-15 17:23:17', '2012-09-15 17:23:17'),
(907, 237, 'DSC033810.jpg', 0, '2012-09-15 17:23:18', '2012-09-15 17:23:18'),
(908, 237, 'DSC_07082.jpg', 0, '2012-09-15 17:23:18', '2012-09-15 17:23:18'),
(909, 237, 'DSC033840.jpg', 0, '2012-09-15 17:23:18', '2012-09-15 17:23:18'),
(910, 237, 'DSC_06692.jpg', 0, '2012-09-15 17:23:19', '2012-09-15 17:23:19'),
(911, 237, 'DSC_07210.jpg', 0, '2012-09-15 17:23:19', '2012-09-15 17:23:19'),
(912, 237, 'DSC_07002.jpg', 0, '2012-09-15 17:23:19', '2012-09-15 17:23:19'),
(913, 237, 'DSC_07312.jpg', 0, '2012-09-15 17:23:20', '2012-09-15 17:23:20'),
(914, 237, 'DSC_06802.jpg', 0, '2012-09-15 17:23:20', '2012-09-15 17:23:20'),
(915, 237, 'DSC_07342.jpg', 0, '2012-09-15 17:23:21', '2012-09-15 17:23:21'),
(916, 237, 'DSC_07242.jpg', 0, '2012-09-15 17:23:21', '2012-09-15 17:23:21'),
(917, 237, 'DSC_10271.jpg', 0, '2012-09-15 17:23:21', '2012-09-15 17:23:21'),
(918, 237, 'DSC_09981.jpg', 0, '2012-09-15 17:23:22', '2012-09-15 17:23:22'),
(919, 237, 'DSC_07322.jpg', 0, '2012-09-15 17:23:22', '2012-09-15 17:23:22'),
(920, 237, 'DSC_09962.jpg', 0, '2012-09-15 17:23:23', '2012-09-15 17:23:23'),
(921, 237, 'DSC_10610.jpg', 0, '2012-09-15 17:23:23', '2012-09-15 17:23:23'),
(922, 237, 'DSC_10631.jpg', 0, '2012-09-15 17:23:23', '2012-09-15 17:23:23'),
(923, 237, 'IMG_12730.jpg', 0, '2012-09-15 17:23:24', '2012-09-15 17:23:24'),
(924, 237, 'IMG_12670.jpg', 0, '2012-09-15 17:23:24', '2012-09-15 17:23:24'),
(925, 237, 'IMG_12800.jpg', 0, '2012-09-15 17:23:24', '2012-09-15 17:23:24'),
(926, 237, 'DSC_10061.jpg', 0, '2012-09-15 17:23:25', '2012-09-15 17:23:25'),
(927, 237, 'DSC_10940.jpg', 0, '2012-09-15 17:23:25', '2012-09-15 17:23:25'),
(928, 237, 'IMG_12820.jpg', 0, '2012-09-15 17:23:25', '2012-09-15 17:23:25'),
(929, 237, 'IMG_12710.jpg', 0, '2012-09-15 17:23:26', '2012-09-15 17:23:26'),
(930, 237, 'IMG_12750.jpg', 0, '2012-09-15 17:23:26', '2012-09-15 17:23:26'),
(931, 237, 'PISCINA_CLUB0.jpg', 0, '2012-09-15 17:23:26', '2012-09-15 17:23:26'),
(932, 21, 'Capturadepantallade2012-06-240128533.png', 0, '2012-09-18 21:36:51', '2012-09-18 21:36:51'),
(933, 21, '462434_207281306038950_159625967471151_272230_935329762_o18.jpg', 0, '2012-09-18 21:36:51', '2012-09-18 21:36:51'),
(934, 21, 'Capturadepantallade2012-07-170826023.png', 0, '2012-09-18 21:36:51', '2012-09-18 21:36:51'),
(935, 21, 'Capturadepantallade2012-07-130033114.png', 0, '2012-09-18 21:36:52', '2012-09-18 21:36:52'),
(936, 21, 'Capturadepantallade2012-07-130032433.png', 0, '2012-09-18 21:36:52', '2012-09-18 21:36:52'),
(937, 21, 'Capturadepantallade2012-07-170826366.png', 0, '2012-09-18 21:36:52', '2012-09-18 21:36:52'),
(938, 241, '462434_207281306038950_159625967471151_272230_935329762_o19.jpg', 0, '2012-09-19 08:49:16', '2012-09-19 08:49:16'),
(939, 241, 'Capturadepantallade2012-06-240128534.png', 0, '2012-09-19 08:49:16', '2012-09-19 08:49:16'),
(940, 241, 'Capturadepantallade2012-07-130033115.png', 1, '2012-09-19 08:49:16', '2012-09-19 08:49:16'),
(941, 241, 'Capturadepantallade2012-07-170826394.png', 0, '2012-09-19 08:49:16', '2012-09-19 08:49:16'),
(942, 241, 'Capturadepantallade2012-07-130032434.png', 0, '2012-09-19 08:49:16', '2012-09-19 08:49:16'),
(943, 241, 'Capturadepantallade2012-07-170826024.png', 0, '2012-09-19 08:49:16', '2012-09-19 08:49:16'),
(944, 241, 'Capturadepantallade2012-08-031724184.png', 0, '2012-09-19 08:49:17', '2012-09-19 08:49:17'),
(945, 241, 'Capturadepantallade2012-08-062045581.png', 0, '2012-09-19 08:49:17', '2012-09-19 08:49:17'),
(946, 241, 'Capturadepantallade2012-07-241448242.png', 0, '2012-09-19 08:49:17', '2012-09-19 08:49:17'),
(947, 241, 'Capturadepantallade2012-07-170826367.png', 0, '2012-09-19 08:49:17', '2012-09-19 08:49:17'),
(948, 241, 'Capturadepantallade2012-08-150847590.png', 0, '2012-09-19 08:49:17', '2012-09-19 08:49:17'),
(949, 241, 'Capturadepantallade2012-07-221837046.png', 0, '2012-09-19 08:49:18', '2012-09-19 08:49:18'),
(950, 241, 'Capturadepantallade2012-08-150809510.png', 0, '2012-09-19 08:49:18', '2012-09-19 08:49:18'),
(951, 242, '462434_207281306038950_159625967471151_272230_935329762_o20.jpg', 0, '2012-10-01 15:14:56', '2012-10-01 15:14:56'),
(952, 242, 'Capturadepantallade2012-07-130033116.png', 0, '2012-10-01 15:14:56', '2012-10-01 15:14:56'),
(953, 242, 'Capturadepantallade2012-06-240128535.png', 0, '2012-10-01 15:14:56', '2012-10-01 15:14:56'),
(954, 242, 'Capturadepantallade2012-07-170826025.png', 0, '2012-10-01 15:14:56', '2012-10-01 15:14:56'),
(955, 242, 'Capturadepantallade2012-07-170826395.png', 0, '2012-10-01 15:14:56', '2012-10-01 15:14:56'),
(956, 242, 'Capturadepantallade2012-08-150809511.png', 0, '2012-10-01 15:14:57', '2012-10-01 15:14:57'),
(957, 242, 'Capturadepantallade2012-08-150850060.png', 0, '2012-10-01 15:14:57', '2012-10-01 15:14:57'),
(958, 242, 'Capturadepantallade2012-08-031724185.png', 0, '2012-10-01 15:14:57', '2012-10-01 15:14:57'),
(959, 242, 'Capturadepantallade2012-09-161523250.png', 0, '2012-10-01 15:14:57', '2012-10-01 15:14:57'),
(960, 242, '462434_207281306038950_159625967471151_272230_935329762_o21.jpg', 0, '2012-10-01 15:15:11', '2012-10-01 15:15:11'),
(961, 242, 'Capturadepantallade2012-06-240128536.png', 0, '2012-10-01 15:15:11', '2012-10-01 15:15:11'),
(962, 242, 'Capturadepantallade2012-07-130033117.png', 0, '2012-10-01 15:15:11', '2012-10-01 15:15:11'),
(963, 242, 'Capturadepantallade2012-07-130032435.png', 0, '2012-10-01 15:15:11', '2012-10-01 15:15:11'),
(964, 242, 'Capturadepantallade2012-07-170826368.png', 0, '2012-10-01 15:15:11', '2012-10-01 15:15:11'),
(965, 242, 'Capturadepantallade2012-07-170826026.png', 0, '2012-10-01 15:15:11', '2012-10-01 15:15:11'),
(966, 243, '462434_207281306038950_159625967471151_272230_935329762_o22.jpg', 0, '2012-10-02 09:21:22', '2012-10-02 09:21:22'),
(967, 243, 'Capturadepantallade2025-04-191226101.png', 0, '2012-10-02 09:21:22', '2012-10-02 09:21:22'),
(968, 243, 'Capturadepantallade2012-08-150847591.png', 0, '2012-10-02 09:21:22', '2012-10-02 09:21:22'),
(969, 243, 'Capturadepantallade2012-07-221837047.png', 0, '2012-10-02 09:21:23', '2012-10-02 09:21:23'),
(970, 243, 'Capturadepantallade2012-07-130033118.png', 0, '2012-10-02 09:21:23', '2012-10-02 09:21:23'),
(971, 243, 'Capturadepantallade2012-06-240128537.png', 0, '2012-10-02 09:21:23', '2012-10-02 09:21:23'),
(972, 243, 'Capturadepantallade2012-06-240128538.png', 0, '2012-10-02 09:21:50', '2012-10-02 09:21:50'),
(973, 243, '462434_207281306038950_159625967471151_272230_935329762_o23.jpg', 0, '2012-10-02 09:21:50', '2012-10-02 09:21:50'),
(974, 243, 'Capturadepantallade2012-07-170826027.png', 0, '2012-10-02 09:21:51', '2012-10-02 09:21:51'),
(975, 243, 'Capturadepantallade2012-07-130032436.png', 0, '2012-10-02 09:21:51', '2012-10-02 09:21:51'),
(976, 243, 'Capturadepantallade2012-07-130033119.png', 0, '2012-10-02 09:21:51', '2012-10-02 09:21:51'),
(977, 243, 'Capturadepantallade2012-07-170826369.png', 0, '2012-10-02 09:21:51', '2012-10-02 09:21:51'),
(978, 248, '462434_207281306038950_159625967471151_272230_935329762_o24.jpg', 0, '2012-10-18 07:13:58', '2012-10-18 07:13:58'),
(979, 249, '462434_207281306038950_159625967471151_272230_935329762_o25.jpg', 0, '2012-10-18 08:13:09', '2012-10-18 08:13:09'),
(980, 250, '462434_207281306038950_159625967471151_272230_935329762_o26.jpg', 0, '2012-10-18 08:22:39', '2012-10-18 08:22:39'),
(981, 251, '462434_207281306038950_159625967471151_272230_935329762_o27.jpg', 0, '2012-10-18 08:24:18', '2012-10-18 08:24:18'),
(982, 252, '462434_207281306038950_159625967471151_272230_935329762_o28.jpg', 0, '2012-10-18 08:25:58', '2012-10-18 08:25:58'),
(983, 253, '462434_207281306038950_159625967471151_272230_935329762_o0.jpg', 0, '2012-10-18 10:07:36', '2012-10-18 10:07:36'),
(984, 254, '462434_207281306038950_159625967471151_272230_935329762_o24.jpg', 0, '2012-11-24 18:03:25', '2012-11-24 18:03:25'),
(985, 254, 'Capturadepantallade2012-07-1708263610.png', 0, '2012-11-24 18:03:26', '2012-11-24 18:03:26'),
(986, 254, 'Capturadepantallade2012-07-221837048.png', 0, '2012-11-24 18:03:26', '2012-11-24 18:03:26'),
(987, 254, 'Capturadepantallade2012-08-031724186.png', 0, '2012-11-24 18:03:26', '2012-11-24 18:03:26'),
(988, 254, 'Capturadepantallade2012-07-1300331110.png', 0, '2012-11-24 18:03:26', '2012-11-24 18:03:26'),
(989, 256, 'Capturadepantallade2012-06-240128539.png', 0, '2012-12-09 23:31:51', '2012-12-09 23:31:51'),
(990, 256, 'Capturadepantallade2012-07-1300331111.png', 0, '2012-12-09 23:31:51', '2012-12-09 23:31:51'),
(991, 256, '462434_207281306038950_159625967471151_272230_935329762_o25.jpg', 0, '2012-12-09 23:31:51', '2012-12-09 23:31:51'),
(992, 256, 'Capturadepantallade2012-07-221837049.png', 0, '2012-12-09 23:31:51', '2012-12-09 23:31:51'),
(993, 256, 'Capturadepantallade2012-07-1708263611.png', 0, '2012-12-09 23:31:51', '2012-12-09 23:31:51'),
(994, 256, '462434_207281306038950_159625967471151_272230_935329762_o26.jpg', 0, '2012-12-09 23:32:09', '2012-12-09 23:32:09'),
(995, 256, 'Capturadepantallade2012-06-2401285310.png', 0, '2012-12-09 23:32:09', '2012-12-09 23:32:09'),
(996, 256, 'Capturadepantallade2012-07-1708263612.png', 0, '2012-12-09 23:32:10', '2012-12-09 23:32:10'),
(997, 256, 'Capturadepantallade2012-07-170826028.png', 0, '2012-12-09 23:32:10', '2012-12-09 23:32:10'),
(998, 256, 'Capturadepantallade2012-07-170826396.png', 0, '2012-12-09 23:32:10', '2012-12-09 23:32:10'),
(999, 256, 'Capturadepantallade2012-07-2218370410.png', 0, '2012-12-09 23:32:10', '2012-12-09 23:32:10'),
(1000, 256, 'Capturadepantallade2012-07-1300331112.png', 0, '2012-12-09 23:32:10', '2012-12-09 23:32:10'),
(1001, 256, 'Capturadepantallade2012-07-241448243.png', 0, '2012-12-09 23:32:10', '2012-12-09 23:32:10'),
(1002, 256, 'Capturadepantallade2012-08-062045582.png', 0, '2012-12-09 23:32:11', '2012-12-09 23:32:11'),
(1003, 256, 'Capturadepantallade2012-08-150809512.png', 0, '2012-12-09 23:32:11', '2012-12-09 23:32:11'),
(1004, 256, 'Capturadepantallade2012-08-150847592.png', 0, '2012-12-09 23:32:11', '2012-12-09 23:32:11'),
(1005, 256, 'Capturadepantallade2012-07-130032437.png', 0, '2012-12-09 23:32:11', '2012-12-09 23:32:11'),
(1006, 258, '462434_207281306038950_159625967471151_272230_935329762_o27.jpg', 0, '2013-01-03 11:06:19', '2013-01-03 11:06:19'),
(1007, 258, 'Capturadepantallade2012-06-2401285311.png', 0, '2013-01-03 11:06:31', '2013-01-03 11:06:31'),
(1008, 258, 'Capturadepantallade2012-07-170826029.png', 0, '2013-01-03 11:06:31', '2013-01-03 11:06:31'),
(1009, 258, 'Capturadepantallade2012-07-1300331113.png', 0, '2013-01-03 11:06:31', '2013-01-03 11:06:31'),
(1010, 258, 'Capturadepantallade2012-08-062045583.png', 0, '2013-01-03 11:06:31', '2013-01-03 11:06:31'),
(1011, 258, 'Capturadepantallade2012-07-170826397.png', 0, '2013-01-03 11:06:32', '2013-01-03 11:06:32'),
(1012, 258, 'Capturadepantallade2012-07-241448244.png', 0, '2013-01-03 11:06:32', '2013-01-03 11:06:32'),
(1013, 259, 'Capturadepantallade2013-01-061920550.png', 0, '2013-01-08 21:54:25', '2013-01-08 21:54:25'),
(1014, 259, 'Capturadepantallade2013-01-061920470.png', 0, '2013-01-08 21:54:25', '2013-01-08 21:54:25'),
(1015, 259, 'Capturadepantallade2013-01-061920340.png', 0, '2013-01-08 21:54:25', '2013-01-08 21:54:25'),
(1016, 259, 'Capturadepantallade2012-07-1708260210.png', 0, '2013-01-08 21:57:41', '2013-01-08 21:57:41'),
(1017, 259, 'Capturadepantallade2012-07-170826398.png', 0, '2013-01-08 21:57:41', '2013-01-08 21:57:41'),
(1018, 259, 'Capturadepantallade2012-07-1708263613.png', 0, '2013-01-08 21:57:41', '2013-01-08 21:57:41'),
(1019, 260, 'DSC033841.jpg', 1, '2013-02-10 19:43:58', '2013-02-10 19:43:58'),
(1020, 260, '', 1, '2013-02-10 19:43:58', '2013-02-10 19:43:58'),
(1021, 260, 'DSC_07003.jpg', 1, '2013-02-10 19:43:58', '2013-02-10 19:43:58'),
(1022, 260, 'DSC_07243.jpg', 1, '2013-02-10 19:43:59', '2013-02-10 19:43:59'),
(1023, 260, '', 1, '2013-02-10 19:43:59', '2013-02-10 19:43:59'),
(1024, 260, 'IMG_12711.jpg', 1, '2013-02-10 19:43:59', '2013-02-10 19:43:59'),
(1025, 260, 'IMG_12731.jpg', 1, '2013-02-10 19:44:00', '2013-02-10 19:44:00'),
(1026, 261, 'DSC033842.jpg', 1, '2013-02-10 19:44:46', '2013-02-10 19:44:46'),
(1027, 261, 'DSC_07004.jpg', 1, '2013-02-10 19:44:57', '2013-02-10 19:44:57'),
(1028, 261, '', 1, '2013-02-10 19:44:58', '2013-02-10 19:44:58'),
(1029, 261, '', 1, '2013-02-10 19:45:02', '2013-02-10 19:45:02'),
(1030, 262, '', 1, '2013-02-10 19:45:20', '2013-02-10 19:45:20'),
(1031, 264, 'IMG_12712.jpg', 0, '2013-02-10 19:54:38', '2013-02-10 19:54:38'),
(1032, 264, 'DSC_07244.jpg', 0, '2013-02-10 19:54:38', '2013-02-10 19:54:38'),
(1033, 264, 'DSC_10272.jpg', 0, '2013-02-10 19:54:38', '2013-02-10 19:54:38'),
(1034, 264, 'DSC033843.jpg', 0, '2013-02-10 19:54:39', '2013-02-10 19:54:39'),
(1035, 264, 'IMG_12732.jpg', 0, '2013-02-10 19:54:39', '2013-02-10 19:54:39'),
(1036, 264, 'DSC_07005.jpg', 0, '2013-02-10 19:54:40', '2013-02-10 19:54:40'),
(1037, 264, 'DSC_06693.jpg', 0, '2013-02-10 19:54:40', '2013-02-10 19:54:40'),
(1038, 265, '20.jpg', 0, '2013-02-10 21:16:32', '2013-02-10 21:16:32'),
(1039, 265, '30.jpg', 0, '2013-02-10 21:16:32', '2013-02-10 21:16:32'),
(1040, 265, '10.jpg', 0, '2013-02-10 21:16:32', '2013-02-10 21:16:32'),
(1041, 266, '21.jpg', 0, '2013-02-10 23:25:48', '2013-02-10 23:25:48'),
(1042, 266, '50.jpg', 0, '2013-02-10 23:25:49', '2013-02-10 23:25:49'),
(1043, 266, '31.jpg', 0, '2013-02-10 23:25:49', '2013-02-10 23:25:49');
INSERT INTO `images` (`id`, `product_id`, `name`, `deleted`, `created`, `modified`) VALUES
(1044, 266, '60.jpg', 0, '2013-02-10 23:25:50', '2013-02-10 23:25:50'),
(1045, 266, '40.jpg', 0, '2013-02-10 23:25:51', '2013-02-10 23:25:51'),
(1046, 266, '70.jpg', 0, '2013-02-10 23:25:51', '2013-02-10 23:25:51'),
(1047, 266, '110.jpg', 0, '2013-02-10 23:25:52', '2013-02-10 23:25:52'),
(1048, 266, '100.jpg', 0, '2013-02-10 23:25:52', '2013-02-10 23:25:52'),
(1049, 266, '80.jpg', 0, '2013-02-10 23:25:53', '2013-02-10 23:25:53'),
(1050, 266, '90.jpg', 0, '2013-02-10 23:25:53', '2013-02-10 23:25:53'),
(1051, 266, '11.jpg', 0, '2013-02-10 23:25:54', '2013-02-10 23:25:54'),
(1052, 266, '120.jpg', 0, '2013-02-10 23:25:55', '2013-02-10 23:25:55'),
(1053, 266, '130.jpg', 0, '2013-02-10 23:25:55', '2013-02-10 23:25:55'),
(1054, 255, '04G-P4-2690-KR_LG_60.jpg', 0, '2013-03-05 00:37:45', '2013-03-05 00:37:45'),
(1055, 255, '02G-P4-2689-KR_LG_40.jpg', 0, '2013-03-05 00:37:45', '2013-03-05 00:37:45'),
(1056, 255, '04G-P4-2699-K2_LG_60.jpg', 0, '2013-03-05 00:37:46', '2013-03-05 00:37:46'),
(1057, 263, '04G-P4-2699-K2_LG_70.jpg', 0, '2013-03-05 00:54:17', '2013-03-05 00:54:17'),
(1058, 262, '270-SE-W888-KR_LG_40.jpg', 0, '2013-03-05 00:55:50', '2013-03-05 00:55:50'),
(1059, 262, '270-SE-W888-KR_LG_10.jpg', 0, '2013-03-05 00:55:50', '2013-03-05 00:55:50'),
(1060, 262, '270-SE-W888-KR_LG_70.jpg', 0, '2013-03-05 00:55:51', '2013-03-05 00:55:51'),
(1061, 262, '270-SE-W888-KR_LG_50.jpg', 0, '2013-03-05 00:55:51', '2013-03-05 00:55:51');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `manufacturers`
--

CREATE TABLE IF NOT EXISTS `manufacturers` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `manufacturers`
--

INSERT INTO `manufacturers` (`id`, `name`, `created`, `modified`) VALUES
(1, 'evga', '2012-01-08 10:06:37', '2012-01-08 10:06:40'),
(2, 'ferrari', '2012-01-08 10:07:40', '2012-01-08 10:07:42');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) unsigned DEFAULT NULL,
  `product_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `open` int(1) unsigned NOT NULL,
  `body` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` int(1) unsigned NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=13 ;

--
-- Volcado de datos para la tabla `messages`
--

INSERT INTO `messages` (`id`, `parent_id`, `product_id`, `user_id`, `open`, `body`, `deleted`, `created`, `modified`) VALUES
(1, NULL, 21, 5, 0, 'Que tal amigo', 0, '2012-08-30 22:49:44', '2012-08-30 22:49:44'),
(2, NULL, 21, 5, 0, 'hola', 0, '2012-08-30 22:59:12', '2012-08-30 22:59:12'),
(3, NULL, 221, 4, 0, 'asassa', 0, '2012-09-15 20:29:25', '2012-09-15 20:29:25'),
(4, NULL, 21, 4, 0, 'dfdfdf', 0, '2012-09-19 09:14:55', '2012-09-19 09:14:55'),
(5, NULL, 21, 4, 0, 'asass', 0, '2012-09-20 19:15:53', '2012-09-20 19:15:53'),
(6, NULL, 21, 4, 0, 'sasasas', 0, '2012-09-20 19:19:44', '2012-09-20 19:19:44'),
(7, NULL, 21, 4, 0, 'asasas', 0, '2012-09-20 19:20:18', '2012-09-20 19:20:18'),
(8, NULL, 21, 4, 0, 'sasas', 0, '2012-09-20 19:22:58', '2012-09-20 19:22:58'),
(9, NULL, 21, 4, 0, 'asasas', 0, '2012-09-20 21:42:54', '2012-09-20 21:42:54'),
(10, NULL, 21, 4, 0, 'asasssas', 0, '2012-09-20 21:43:01', '2012-09-20 21:43:01'),
(11, NULL, 21, 4, 0, 'hola romel', 0, '2012-09-20 21:53:09', '2012-09-20 21:53:09'),
(12, NULL, 21, 4, 0, 'asssas', 0, '2012-09-20 22:04:39', '2012-09-20 22:04:39');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `parts`
--

CREATE TABLE IF NOT EXISTS `parts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `manufacturer_id` int(11) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `part` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(1) unsigned NOT NULL DEFAULT '0',
  `deleted` int(1) unsigned NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='partNumber' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `payments`
--

CREATE TABLE IF NOT EXISTS `payments` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `bank_account_id` int(11) unsigned NOT NULL,
  `purchase_id` int(11) unsigned NOT NULL,
  `billing_id` int(11) unsigned NOT NULL,
  `transaction_type` int(1) unsigned DEFAULT NULL,
  `control_number` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `amount` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `additional_information` text COLLATE utf8_unicode_ci,
  `file_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Volcado de datos para la tabla `payments`
--

INSERT INTO `payments` (`id`, `user_id`, `bank_account_id`, `purchase_id`, `billing_id`, `transaction_type`, `control_number`, `amount`, `additional_information`, `file_name`, `created`, `modified`) VALUES
(1, 4, 3, 9, 1, 2, '3396669633', '5000', NULL, '', '2012-02-21 11:47:18', '2012-02-21 12:25:03'),
(3, 4, 0, 7, 3, 1, '0000000', '111', '20001000', '', '2012-02-21 13:39:51', '2012-08-11 22:00:10'),
(4, 4, 0, 5, 4, 2, '5555555', '5000', '', '', '2012-02-21 13:43:58', '2012-02-21 13:44:13'),
(5, 4, 1, 10, 5, 1, '9996', '0', '', '', '2012-08-11 12:19:57', '2012-08-11 14:46:51'),
(6, 4, 1, 17, 6, 1, '3213', '21', '321', '', '2013-03-05 00:04:35', '2013-03-05 00:04:35'),
(7, 4, 1, 16, 7, 2, '32', '132', '13', '', '2013-03-05 00:05:36', '2013-03-05 00:05:36'),
(8, 4, 0, 2, 8, 2, '32132132132132', '100', 'info', '', '2013-03-05 00:57:32', '2013-03-05 00:57:32'),
(9, 4, 0, 4, 9, 2, '32151', '32', '132', '', '2013-03-07 16:21:58', '2013-03-07 16:21:58');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `policies`
--

CREATE TABLE IF NOT EXISTS `policies` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(11) unsigned NOT NULL,
  `policy` text COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `problems`
--

CREATE TABLE IF NOT EXISTS `problems` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `company_id` int(11) unsigned DEFAULT NULL,
  `purchase_id` int(11) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `status` int(1) unsigned NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `problems`
--

INSERT INTO `problems` (`id`, `user_id`, `company_id`, `purchase_id`, `title`, `description`, `status`, `created`, `modified`) VALUES
(1, 4, 2, 7, 'la propagación de las ondas electromagnéticas, así como de formas de producirlas y detectarlas. ', '123132', 0, '2012-02-26 19:43:39', '2012-02-26 19:43:39');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `problem_extensions`
--

CREATE TABLE IF NOT EXISTS `problem_extensions` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `problem_id` int(11) unsigned NOT NULL,
  `extension` text COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `problem_extensions`
--

INSERT INTO `problem_extensions` (`id`, `problem_id`, `extension`, `created`, `modified`) VALUES
(1, 1, 'Condiciones\r\nLos interesados en asistir al evento pueden hacerlo en calidad de:\r\na) Participante.\r\nb) Ponente con reporte de Investigación o comunicación breve.\r\nc) Presentador de un cartel.\r\nd)·Facilitador de un taller o curso corto.\r\ne)·Coordinador o ponente en grupo de discusión.', '2012-02-27 14:33:23', '2012-02-27 14:33:23');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `problem_files`
--

CREATE TABLE IF NOT EXISTS `problem_files` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `problem_id` int(11) unsigned NOT NULL,
  `file` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `problem_products`
--

CREATE TABLE IF NOT EXISTS `problem_products` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `problem_id` int(11) unsigned NOT NULL,
  `purchased_product_id` int(11) unsigned NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `problem_products`
--

INSERT INTO `problem_products` (`id`, `problem_id`, `purchased_product_id`, `created`, `modified`) VALUES
(1, 1, 13, '2012-02-26 19:43:39', '2012-02-26 19:43:39'),
(2, 1, 14, '2012-02-26 19:43:39', '2012-02-26 19:43:39');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `problem_replies`
--

CREATE TABLE IF NOT EXISTS `problem_replies` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `problem_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `role` int(1) unsigned NOT NULL COMMENT '1 cliente - 2 vendedor',
  `response` text COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `problem_replies`
--

INSERT INTO `problem_replies` (`id`, `problem_id`, `user_id`, `role`, `response`, `created`, `modified`) VALUES
(1, 1, 5, 2, 'su solicitud esta siendo analizada por nuestro departamento de garantías ', '2012-02-27 15:05:39', '2012-02-27 15:05:41');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(11) unsigned NOT NULL,
  `store_id` int(11) unsigned NOT NULL,
  `user_id` int(20) unsigned NOT NULL,
  `department_id` int(11) unsigned NOT NULL,
  `category_id` int(11) unsigned NOT NULL,
  `manufacturer_id` int(11) unsigned DEFAULT NULL COMMENT 'segunda etapa',
  `part_id` int(11) unsigned DEFAULT NULL COMMENT 'segunda etapa',
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `body` text COLLATE utf8_unicode_ci,
  `price` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `quantity` int(3) unsigned DEFAULT NULL,
  `condition` int(1) unsigned NOT NULL DEFAULT '1' COMMENT '1 = nuevo, 0 = usado',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'esta publicado o no, 1 es publicado  ',
  `deleted` int(1) unsigned NOT NULL DEFAULT '0' COMMENT '1 es eliminado',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='nodes' AUTO_INCREMENT=267 ;

--
-- Volcado de datos para la tabla `products`
--

INSERT INTO `products` (`id`, `company_id`, `store_id`, `user_id`, `department_id`, `category_id`, `manufacturer_id`, `part_id`, `title`, `body`, `price`, `quantity`, `condition`, `status`, `deleted`, `created`, `modified`) VALUES
(1, 1, 8, 4, 0, 12, 0, 0, 'corsair 800d', '', '100', 99, 1, 1, 1, '2011-12-28 18:42:31', '2012-10-18 09:21:10'),
(2, 1, 8, 4, 0, 12, 0, 0, 'targeta madre', '', '100', 96, 1, 1, 1, '2011-12-28 18:43:07', '2012-10-18 09:22:33'),
(3, 1, 8, 4, 0, 12, 0, 0, 'targeta madre', 'asasas', '200', 99, 1, 1, 1, '2011-12-28 18:43:47', '2012-10-18 09:23:49'),
(4, 1, 8, 4, 0, 12, 0, 0, 'targeta madre', '', '300', 96, 1, 1, 1, '2011-12-28 18:44:25', '2012-10-18 09:23:54'),
(5, 1, 8, 4, 0, 12, 0, 0, 'bmx pro', '', '100', 6, 1, 1, 1, '2011-12-28 18:45:06', '2012-08-09 23:41:51'),
(6, 1, 8, 4, 0, 12, 0, 0, 'bmx pro', '', '100', 96, 1, 1, 1, '2011-12-28 18:45:26', '2012-10-18 09:23:58'),
(7, 1, 8, 4, 0, 12, 0, 0, 'bmx', '', '300', 3, 1, 1, 1, '2011-12-28 18:46:05', '2012-11-25 17:03:07'),
(8, 1, 8, 4, 0, 12, 0, 0, 'bmx pro', '', '100', 6, 1, 1, 1, '2011-12-28 18:46:29', '2012-10-18 09:24:02'),
(9, 1, 8, 4, 0, 12, 0, 0, 'wtp bmx', '', '300', 100, 1, 1, 1, '2011-12-28 18:46:51', '2012-10-18 09:24:05'),
(10, 1, 8, 4, 0, 12, 0, 0, 'evga', '', '100', 100, 1, 1, 1, '2011-12-28 18:49:23', '2012-08-09 23:41:46'),
(11, 2, 13, 3, 0, 0, 0, 1, 'ferrary', '', '1000', 3, 1, 1, 0, '2011-12-30 16:31:11', '2013-03-05 00:33:06'),
(12, 2, 13, 3, 0, 0, 0, 0, 'land rover', '', '1000', 10, 1, 1, 0, '2011-12-30 16:31:32', '2013-03-05 00:58:04'),
(13, 2, 13, 3, 0, 0, 0, 0, 'silverado', '', '1000', 108, 1, 1, 1, '2011-12-30 16:31:49', '2013-03-07 16:21:26'),
(14, 2, 13, 3, 0, 0, 0, 0, 'ducati', '', '1000', 10, 1, 1, 1, '2011-12-30 16:32:05', '2012-02-12 09:07:23'),
(15, 2, 13, 3, 0, 0, 0, 1, 'ferrari', '', '1000', 2, 1, 1, 0, '2011-12-30 16:32:25', '2013-03-05 00:58:04'),
(16, 2, 13, 3, 0, 0, 0, 1, 'ferrari', '', '1000', 115, 1, 1, 0, '2011-12-30 16:32:45', '2013-03-07 16:21:26'),
(17, 2, 13, 3, 0, 0, 0, 1, 'ferrari', '', '1000', 119, 1, 1, 0, '2011-12-30 16:33:02', '2012-11-25 17:03:07'),
(18, 2, 13, 3, 0, 0, 0, 0, 'lambor', '', '1000', 119, 1, 1, 0, '2011-12-30 16:33:28', '2013-03-07 16:21:26'),
(19, 2, 13, 3, 0, 0, 0, 0, 'lambor', '', '1000', 118, 1, 1, 1, '2011-12-30 16:33:47', '2012-02-28 10:27:47'),
(20, 2, 13, 3, 0, 0, 0, 0, 'lambor', '', '1000', 121, 1, 1, 0, '2011-12-30 16:35:26', '2013-03-07 16:21:26'),
(21, 1, 2, 4, 1, 1, NULL, NULL, 'EVGA X79 Classified  Intel Socket 2011 Quad Channel DDR3 32GB of DDR3 2133MHz+ 151-SE-E779-KR', 'EVGA X79', '450', 90, 1, 0, 1, '2012-01-21 18:40:50', '2012-10-18 10:06:27'),
(22, 1, 0, 4, 1, 13, NULL, NULL, 'hp', 'hola', '100', 1, 1, 1, 1, '2012-04-19 10:43:01', '2012-10-18 09:24:08'),
(23, 1, 0, 4, 1, 15, NULL, NULL, 'hp', 'as', '2', 1, 1, 1, 1, '2012-04-19 10:45:02', '2012-08-09 23:41:42'),
(24, 1, 0, 4, 1, 15, NULL, NULL, 'hp', 'as', '2', 1, 1, 1, 1, '2012-04-19 10:48:15', '2012-08-09 23:41:39'),
(25, 1, 0, 4, 1, 16, NULL, NULL, 'hp', 'as', '10', 1, 1, 1, 1, '2012-04-19 10:48:29', '2012-08-09 23:41:34'),
(26, 1, 0, 4, 1, 15, NULL, NULL, 'as', 'as', '100', 1, 1, 1, 1, '2012-04-19 10:49:37', '2012-08-09 23:41:29'),
(27, 1, 0, 4, 1, 19, NULL, NULL, 'hp', 'ok', '100', 1, 1, 1, 1, '2012-04-19 11:15:38', '2012-08-09 23:41:26'),
(28, 1, 0, 4, 1, 19, NULL, NULL, 'as', 'oj', '100', 1, 1, 1, 1, '2012-04-19 11:15:59', '2012-08-09 23:41:22'),
(29, 1, 0, 4, 1, 16, NULL, NULL, 'hp', 'as', '100', 1, 1, 1, 1, '2012-04-19 12:40:44', '2012-08-09 23:41:17'),
(30, 1, 0, 4, 1, 17, NULL, NULL, 'HOLA ROMEL', 'OK', '100', 1, 1, 1, 1, '2012-04-19 12:48:40', '2012-08-09 23:41:14'),
(31, 1, 0, 4, 1, 16, NULL, NULL, 'YO CREO QUE TIENE QUE utilizar LOS DOS', 'OK', '100', 1, 1, 1, 1, '2012-04-19 12:49:41', '2012-08-09 23:41:10'),
(32, 1, 0, 4, 1, 15, NULL, NULL, 'titulo ', 'ok', '100', 1, 1, 1, 1, '2012-04-19 13:04:54', '2012-08-09 23:41:06'),
(33, 1, 0, 4, 1, 18, NULL, NULL, 'hp', 'as', '100', 1, 1, 1, 1, '2012-04-19 13:07:25', '2012-08-09 23:40:34'),
(34, 1, 0, 4, 1, 17, NULL, NULL, 'as', 'sa', '10', 1, 1, 1, 1, '2012-04-19 13:07:38', '2012-08-09 23:41:01'),
(35, 1, 0, 4, 1, 18, NULL, NULL, 'sa', 'sa', '1515', 1, 1, 1, 1, '2012-04-19 13:09:22', '2012-08-09 23:40:30'),
(36, 1, 0, 4, 1, 17, NULL, NULL, '', '', '', 1, 1, 1, 1, '2012-04-19 14:22:16', '2012-08-09 23:40:24'),
(37, 1, 0, 4, 1, 17, NULL, NULL, '', '', '', 1, 1, 1, 1, '2012-04-19 17:03:46', '2012-08-09 23:40:20'),
(38, 1, 0, 4, 1, 17, NULL, NULL, '', '', '', 1, 1, 1, 1, '2012-04-19 17:04:27', '2012-08-09 23:40:16'),
(128, 1, 0, 4, 1, 7, NULL, NULL, 'hp', 'ok okok ', '100', 1, 1, 1, 1, '2012-04-22 17:08:10', '2012-08-09 23:40:12'),
(129, 1, 0, 4, 1, 6, NULL, NULL, 'assssas', 'banesco bmx', '1000', 100, 1, 1, 1, '2012-04-23 03:40:49', '2012-08-09 23:40:02'),
(213, 1, 0, 4, 1, 17, NULL, NULL, '', '', '', NULL, 1, 0, 1, '2012-08-05 15:02:22', '2012-10-18 10:07:08'),
(214, 1, 0, 4, 1, 18, NULL, NULL, 'borrador 2', 'hola de nuevo s', '100', 100, 1, 0, 1, '2012-08-05 15:09:05', '2012-10-18 10:07:06'),
(215, 1, 0, 4, 1, 19, NULL, NULL, '', '', '', NULL, 1, 0, 1, '2012-08-05 22:07:41', '2012-10-18 10:07:04'),
(216, 1, 0, 4, 1, 18, NULL, NULL, '', '', '', NULL, 1, 0, 1, '2012-08-06 22:54:34', '2012-10-18 10:07:03'),
(217, 1, 0, 4, 1, 19, NULL, NULL, '', '', '', NULL, 1, 0, 1, '2012-08-06 23:04:16', '2012-10-18 10:07:01'),
(218, 1, 0, 4, 1, 19, NULL, NULL, '', '', '', NULL, 1, 0, 1, '2012-08-06 23:09:58', '2012-10-18 10:06:59'),
(219, 1, 0, 4, 1, 17, NULL, NULL, '', '', '', NULL, 1, 0, 1, '2012-08-06 23:36:00', '2012-08-07 20:59:20'),
(220, 1, 0, 4, 1, 19, NULL, NULL, '', '', '', NULL, 1, 0, 1, '2012-08-06 23:49:19', '2012-10-18 10:06:57'),
(221, 1, 0, 4, 1, 19, NULL, NULL, 'borrador x 2 999 9969', 'hola 2', '100', 100, 1, 1, 1, '2012-08-07 00:21:10', '2012-10-18 09:24:11'),
(222, 1, 0, 4, 1, 18, NULL, NULL, '', '', '', NULL, 1, 0, 1, '2012-08-08 17:53:05', '2012-10-18 10:06:56'),
(223, 1, 0, 4, 1, 16, NULL, NULL, '', '', '', NULL, 1, 0, 1, '2012-08-08 20:10:02', '2012-10-18 10:06:54'),
(224, 1, 0, 4, 1, 17, NULL, NULL, '', '', '', NULL, 1, 0, 1, '2012-08-08 20:20:45', '2012-10-18 10:06:52'),
(225, 1, 0, 4, 1, 18, NULL, NULL, '', '', '', NULL, 1, 0, 1, '2012-08-09 14:02:27', '2012-10-18 10:06:50'),
(226, 1, 0, 4, 1, 17, NULL, NULL, 'hola', 'text', '100', 98, 1, 1, 1, '2012-08-09 14:07:58', '2012-11-25 17:03:07'),
(227, 1, 0, 4, 1, 17, NULL, NULL, 'hola  2', 'texto 2', '10', 100, 1, 1, 1, '2012-08-09 14:15:46', '2012-08-09 23:39:56'),
(228, 1, 0, 4, 1, 16, NULL, NULL, 'hola 23', 'text', '1', 1, 1, 1, 1, '2012-08-09 14:30:45', '2012-08-09 23:39:50'),
(229, 2, 0, 5, 1, 10, NULL, NULL, '', '', '', NULL, 1, 0, 0, '2012-09-09 21:32:01', '2012-09-09 21:32:01'),
(230, 2, 0, 5, 1, 18, NULL, NULL, '', '', '', NULL, 1, 0, 0, '2012-09-10 08:41:03', '2012-09-10 08:41:03'),
(231, 1, 0, 4, 1, 17, NULL, NULL, '', '', '', NULL, 1, 0, 1, '2012-09-11 16:25:34', '2012-10-18 10:06:48'),
(232, 1, 0, 4, 1, 17, NULL, NULL, '', '', '', NULL, 1, 0, 1, '2012-09-11 16:27:15', '2012-10-18 10:06:46'),
(233, 1, 0, 4, 1, 19, NULL, NULL, '', '', '', NULL, 1, 0, 1, '2012-09-11 18:04:25', '2012-10-18 10:06:44'),
(234, 1, 0, 4, 1, 18, NULL, NULL, '', '', '', NULL, 1, 0, 1, '2012-09-11 18:05:36', '2012-10-18 10:06:42'),
(235, 1, 0, 4, 1, 10, NULL, NULL, '', '', '', NULL, 1, 0, 1, '2012-09-11 23:26:20', '2012-10-18 10:06:40'),
(236, 1, 0, 4, 1, 15, NULL, NULL, '', '', '', NULL, 1, 0, 1, '2012-09-15 12:12:27', '2012-10-18 10:06:37'),
(237, 1, 0, 4, 1, 10, NULL, NULL, 'palma real', '', '', NULL, 1, 0, 1, '2012-09-15 17:22:56', '2012-09-15 20:57:07'),
(238, 1, 0, 4, 1, 16, NULL, NULL, '', '', '', NULL, 1, 0, 1, '2012-09-15 20:39:50', '2012-09-15 20:39:54'),
(239, 1, 0, 4, 1, 19, NULL, NULL, '', '', '', NULL, 1, 0, 1, '2012-09-15 20:57:27', '2012-09-15 20:57:34'),
(240, 1, 0, 4, 1, 12, NULL, NULL, '', '', '', NULL, 1, 0, 1, '2012-09-19 08:48:25', '2012-09-19 08:48:29'),
(241, 1, 0, 4, 1, 17, NULL, NULL, 'tittulo', 'fdfdf', '3321', 21, 1, 1, 1, '2012-09-19 08:48:54', '2012-10-18 09:24:15'),
(242, 1, 0, 4, 1, 18, NULL, NULL, 'hola', '', '', NULL, 1, 0, 1, '2012-10-01 15:14:43', '2012-10-18 10:06:35'),
(243, 1, 0, 4, 1, 15, NULL, NULL, '', '', '', NULL, 1, 0, 1, '2012-10-02 09:21:14', '2012-10-18 10:06:33'),
(244, 1, 0, 4, 1, 18, NULL, NULL, '', '', '', NULL, 1, 0, 1, '2012-10-07 00:22:56', '2012-10-18 10:06:31'),
(245, 1, 0, 4, 1, 13, NULL, NULL, '', '', '', NULL, 1, 0, 1, '2012-10-07 23:54:31', '2012-10-18 10:06:29'),
(246, 1, 0, 4, 1, 19, NULL, NULL, '', '', '', NULL, 1, 0, 1, '2012-10-08 02:36:07', '2012-10-18 10:05:35'),
(247, 1, 0, 4, 1, 19, NULL, NULL, '', '', '', NULL, 1, 0, 1, '2012-10-17 14:31:47', '2012-10-18 09:49:11'),
(248, 1, 0, 4, 1, 16, NULL, NULL, 'romel', 'romel', '200', 200, 1, 1, 1, '2012-10-18 07:13:50', '2012-10-18 09:43:16'),
(249, 1, 0, 4, 1, 16, NULL, NULL, 'sa', 'sa', '10', 10, 1, 0, 1, '2012-10-18 08:13:06', '2012-10-18 09:49:03'),
(250, 1, 0, 4, 1, 16, NULL, NULL, 'corsair', 'evga', '100', 110, 1, 1, 1, '2012-10-18 08:22:37', '2012-10-18 09:43:14'),
(251, 1, 0, 4, 1, 18, NULL, NULL, 'evga', '100', '100', 110, 1, 0, 1, '2012-10-18 08:24:16', '2012-10-18 09:49:05'),
(252, 1, 0, 4, 1, 10, NULL, NULL, 'a', 'a', '1', 1, 1, 1, 1, '2012-10-18 08:25:56', '2012-10-18 09:43:10'),
(253, 1, 0, 4, 1, 16, NULL, NULL, 'producto', 'hola', '10', 9, 1, 1, 0, '2012-10-18 10:07:32', '2012-10-18 10:44:06'),
(254, 1, 0, 4, 1, 13, NULL, NULL, '', '', '', NULL, 1, 0, 0, '2012-11-24 18:03:18', '2012-11-24 18:03:18'),
(255, 1, 0, 4, 1, 8, NULL, NULL, 'Graficas economicas', '1) 3215', '321', 100, 1, 1, 0, '2012-11-25 16:49:42', '2013-03-05 00:38:29'),
(256, 1, 0, 4, 1, 15, NULL, NULL, '', '', '', NULL, 1, 0, 0, '2012-12-09 23:31:37', '2012-12-09 23:31:37'),
(257, 1, 0, 4, 1, 18, NULL, NULL, '', '', '', NULL, 1, 0, 0, '2013-01-01 20:30:56', '2013-01-01 20:30:56'),
(258, 1, 0, 4, 1, 17, NULL, NULL, '', '', '', NULL, 1, 0, 0, '2013-01-03 11:06:14', '2013-01-03 11:06:14'),
(259, 1, 0, 4, 1, 10, NULL, NULL, '', '', '', NULL, 1, 0, 0, '2013-01-08 21:54:20', '2013-01-08 21:54:20'),
(260, 1, 0, 4, 1, 10, NULL, NULL, '', '', '', NULL, 1, 0, 0, '2013-02-10 19:43:46', '2013-02-10 19:43:46'),
(261, 1, 0, 4, 1, 16, NULL, NULL, '', '', '', NULL, 1, 0, 0, '2013-02-10 19:44:42', '2013-02-10 19:44:42'),
(262, 1, 0, 4, 1, 17, NULL, NULL, 'evga tarjeta madre', 'tarjeta madre', '321', 32, 1, 1, 0, '2013-02-10 19:45:13', '2013-03-05 00:56:23'),
(263, 1, 0, 4, 1, 17, NULL, NULL, 'Super grafica evga 690gtx', 'sin igual', '10', 10, 1, 1, 0, '2013-02-10 19:51:36', '2013-03-05 00:55:00'),
(264, 1, 0, 4, 1, 16, NULL, NULL, 'casa', '', '', NULL, 1, 0, 0, '2013-02-10 19:54:28', '2013-02-10 19:55:21'),
(265, 1, 0, 4, 1, 13, NULL, NULL, 'destacado', '', '', NULL, 1, 0, 0, '2013-02-10 21:16:22', '2013-02-10 21:17:26'),
(266, 1, 0, 4, 1, 10, NULL, NULL, 'palma', 'excelente sitio para vacacionar', '321', 21, 1, 1, 0, '2013-02-10 23:19:01', '2013-03-05 00:40:16');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `purchased_products`
--

CREATE TABLE IF NOT EXISTS `purchased_products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `purchase_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `store_id` int(11) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `price` varchar(22) COLLATE utf8_unicode_ci NOT NULL,
  `quantity` int(11) unsigned NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Volcado de datos para la tabla `purchased_products`
--

INSERT INTO `purchased_products` (`id`, `purchase_id`, `product_id`, `store_id`, `title`, `body`, `price`, `quantity`, `created`, `modified`) VALUES
(1, 1, 12, 13, 'land rover', '', '1000', 1, '2013-03-05 00:30:03', '2013-03-05 00:30:03'),
(2, 1, 11, 13, 'ferrary', '', '1000', 1, '2013-03-05 00:30:03', '2013-03-05 00:30:03'),
(3, 1, 13, 13, 'silverado', '', '1000', 1, '2013-03-05 00:30:03', '2013-03-05 00:30:03'),
(4, 2, 11, 13, 'ferrary', '', '1000', 1, '2013-03-05 00:33:06', '2013-03-05 00:33:06'),
(5, 3, 15, 13, 'ferrari', '', '1000', 1, '2013-03-05 00:58:03', '2013-03-05 00:58:03'),
(6, 3, 16, 13, 'ferrari', '', '1000', 1, '2013-03-05 00:58:03', '2013-03-05 00:58:03'),
(7, 3, 12, 13, 'land rover', '', '1000', 1, '2013-03-05 00:58:03', '2013-03-05 00:58:03'),
(8, 4, 18, 13, 'lambor', '', '1000', 1, '2013-03-07 16:21:25', '2013-03-07 16:21:25'),
(9, 4, 20, 13, 'lambor', '', '1000', 1, '2013-03-07 16:21:25', '2013-03-07 16:21:25'),
(10, 4, 13, 13, 'silverado', '', '1000', 1, '2013-03-07 16:21:25', '2013-03-07 16:21:25'),
(11, 4, 16, 13, 'ferrari', '', '1000', 1, '2013-03-07 16:21:25', '2013-03-07 16:21:25');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `purchases`
--

CREATE TABLE IF NOT EXISTS `purchases` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `company_id` int(11) unsigned NOT NULL,
  `store_id` int(11) unsigned NOT NULL,
  `address_id` int(11) unsigned DEFAULT NULL,
  `filed` int(1) unsigned NOT NULL DEFAULT '0',
  `deleted` int(1) unsigned NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Volcado de datos para la tabla `purchases`
--

INSERT INTO `purchases` (`id`, `user_id`, `company_id`, `store_id`, `address_id`, `filed`, `deleted`, `created`, `modified`) VALUES
(1, 4, 2, 13, NULL, 0, 1, '2013-03-05 00:30:03', '2013-03-05 00:31:01'),
(2, 4, 2, 13, 5, 0, 0, '2013-03-05 00:33:06', '2013-03-05 00:56:44'),
(3, 4, 2, 13, NULL, 0, 0, '2013-03-05 00:58:03', '2013-03-05 00:58:03'),
(4, 4, 2, 13, 5, 0, 0, '2013-03-07 16:21:25', '2013-03-07 16:21:41');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `questions`
--

CREATE TABLE IF NOT EXISTS `questions` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL COMMENT 'comprador',
  `product_id` int(11) unsigned NOT NULL COMMENT 'vendedor',
  `body` varchar(1100) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=37 ;

--
-- Volcado de datos para la tabla `questions`
--

INSERT INTO `questions` (`id`, `user_id`, `product_id`, `body`, `created`, `modified`) VALUES
(1, 4, 15, 'al mayor a como lo deja', '2012-01-22 18:36:03', '2012-01-22 18:36:03'),
(2, 4, 15, 'hola', '2012-01-22 18:43:40', '2012-01-22 18:43:40'),
(3, 4, 15, 'Día del mes, 2 dígitos con ceros iniciales	01 a 31 D	Una representación textual de un día, tres letras	Mon hasta Sun j	Día del mes sin ceros iniciales	1 a 31 l (''L'' minúscula)	Una representación textual completa del día de la semana Sunday hasta Saturday N	Representación numérica ISO-8601 del día de la semana (añadido en PHP 5.1.0)	1 (para lunes) hasta 7 (para domingo) S	Sufijo ordinal inglés para el día del mes, 2 caracteres	st, nd, rd o th. Funciona bien con j w Representación numérica del día de la semana	0 (para domingo) hasta 6 (para sábado) z	El día del año (comenzando por 0) 0 hasta 365 Semana	---	--- W	Número de la semana del año ISO-8601, las semanas comienzan en lunes (añadido en PHP 4.1.0)	Ejemplo: 42 (la 42ª semana del año) Mes	---	--- F	Una representación textual completa de un mes, como January o March	January hasta December m	Representación numérica de una mes, con ceros iniciales	01 hasta 12 M	Una representación textual corta de un mes, tres letras	Jan has	', '2012-01-22 18:49:07', '2012-01-22 18:49:07'),
(5, 5, 2, 'que tal', '2012-01-25 10:27:52', '2012-01-25 10:27:52'),
(6, 5, 4, 'cuanto es 2 / 2', '2012-01-25 11:29:15', '2012-01-25 11:29:15'),
(7, 5, 21, 'si compro mil a como los deja. ', '2012-01-25 17:14:22', '2012-01-25 17:14:22'),
(8, 5, 4, 'si compro 100 unidades?  ', '2012-01-27 08:48:39', '2012-01-27 08:48:39'),
(9, 5, 4, 'no, 10000 unidades. a como las deja. ', '2012-01-27 09:10:54', '2012-01-27 09:10:54'),
(11, 4, 13, 'hola que tal', '2012-08-17 19:29:38', '2012-08-17 19:29:38'),
(12, 4, 13, 'hola', '2012-08-17 21:03:10', '2012-08-17 21:03:10'),
(13, 4, 13, 'hola 2', '2012-08-17 21:03:35', '2012-08-17 21:03:35'),
(14, 4, 13, 'banesco?', '2012-08-17 21:13:43', '2012-08-17 21:13:43'),
(15, 4, 13, 'holallll ', '2012-08-17 21:14:12', '2012-08-17 21:14:12'),
(16, 4, 13, 'hola', '2012-08-17 21:14:16', '2012-08-17 21:14:16'),
(17, 4, 13, 'mercantil? ', '2012-08-17 21:21:48', '2012-08-17 21:21:48'),
(18, 4, 13, 'mercantil? ', '2012-08-17 21:21:57', '2012-08-17 21:21:57'),
(19, 4, 13, 'mercantil? ', '2012-08-17 21:21:57', '2012-08-17 21:21:57'),
(20, 4, 13, 'mercantil? ', '2012-08-17 21:21:58', '2012-08-17 21:21:58'),
(21, 4, 13, 'mercantil? ', '2012-08-17 21:21:58', '2012-08-17 21:21:58'),
(22, 4, 13, 'evga', '2012-08-17 21:22:20', '2012-08-17 21:22:20'),
(23, 4, 13, 'oh', '2012-08-17 21:22:48', '2012-08-17 21:22:48'),
(24, 4, 13, 'mas barato', '2012-08-17 21:23:03', '2012-08-17 21:23:03'),
(25, 4, 13, 'mas barato', '2012-08-17 21:24:17', '2012-08-17 21:24:17'),
(26, 4, 13, 'que tal\r\n', '2012-08-17 21:26:40', '2012-08-17 21:26:40'),
(27, 4, 13, 'ok', '2012-08-17 21:27:10', '2012-08-17 21:27:10'),
(28, 4, 13, 'que tal', '2012-08-17 21:27:49', '2012-08-17 21:27:49'),
(29, 4, 13, 'ko', '2012-08-17 21:28:18', '2012-08-17 21:28:18'),
(30, 4, 13, 'evga\r\n', '2012-08-17 21:28:24', '2012-08-17 21:28:24'),
(31, 4, 13, 'banesco?', '2012-08-17 21:28:30', '2012-08-17 21:28:30'),
(32, 4, 13, '2 x 1', '2012-08-17 21:28:43', '2012-08-17 21:28:43'),
(33, 4, 13, '3*1', '2012-08-17 21:35:08', '2012-08-17 21:35:08'),
(34, 4, 13, 'mas fino', '2012-08-17 21:37:28', '2012-08-17 21:37:28'),
(35, 4, 13, 'asas', '2012-08-17 21:40:05', '2012-08-17 21:40:05'),
(36, 4, 13, '99', '2012-08-17 23:16:56', '2012-08-17 23:16:56');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rating_of_purchased_products`
--

CREATE TABLE IF NOT EXISTS `rating_of_purchased_products` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rating_of_purchase_id` int(11) unsigned NOT NULL,
  `product_id` int(11) unsigned NOT NULL,
  `well_packaged` int(1) unsigned DEFAULT NULL,
  `as_described` int(1) unsigned DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Volcado de datos para la tabla `rating_of_purchased_products`
--

INSERT INTO `rating_of_purchased_products` (`id`, `rating_of_purchase_id`, `product_id`, `well_packaged`, `as_described`, `created`, `modified`) VALUES
(1, 1, 12, NULL, NULL, '2013-03-05 00:35:31', '2013-03-05 00:35:31'),
(2, 1, 11, NULL, NULL, '2013-03-05 00:35:31', '2013-03-05 00:35:31'),
(3, 1, 13, NULL, NULL, '2013-03-05 00:35:31', '2013-03-05 00:35:31');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rating_of_purchases`
--

CREATE TABLE IF NOT EXISTS `rating_of_purchases` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `purchase_id` int(11) unsigned NOT NULL,
  `rating` int(1) unsigned NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `rating_of_purchases`
--

INSERT INTO `rating_of_purchases` (`id`, `user_id`, `purchase_id`, `rating`, `created`, `modified`) VALUES
(1, 4, 1, 5, '2013-03-05 00:35:31', '2013-03-05 00:35:31');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reviews`
--

CREATE TABLE IF NOT EXISTS `reviews` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `part_id` int(11) unsigned NOT NULL,
  `purchased_product_id` int(11) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `rating` int(1) unsigned DEFAULT NULL,
  `status` int(1) unsigned NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles`
--

CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `parent_id` int(10) DEFAULT NULL,
  `lft` int(10) DEFAULT NULL,
  `rght` int(10) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Volcado de datos para la tabla `roles`
--

INSERT INTO `roles` (`id`, `name`, `parent_id`, `lft`, `rght`, `created`, `modified`) VALUES
(1, 'Director Ejecutivo', NULL, NULL, NULL, NULL, NULL),
(2, 'Vendedor Afiliado', NULL, NULL, NULL, NULL, NULL),
(3, 'Cliente', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `states`
--

CREATE TABLE IF NOT EXISTS `states` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `country_id` int(11) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=26 ;

--
-- Volcado de datos para la tabla `states`
--

INSERT INTO `states` (`id`, `country_id`, `name`, `created`, `modified`) VALUES
(1, 1, 'Distrito Capital	', NULL, NULL),
(2, 1, 'Amazonas	', NULL, NULL),
(3, 1, 'Anzoategui	', NULL, NULL),
(4, 1, 'Apure	', NULL, NULL),
(5, 1, 'Aragua	', NULL, NULL),
(6, 1, 'Barinas	', NULL, NULL),
(7, 1, 'Bolivar	', NULL, NULL),
(8, 1, 'Carabobo	', NULL, NULL),
(9, 1, 'Cojedes	', NULL, NULL),
(10, 1, 'Delta Amacuro	', NULL, NULL),
(11, 1, 'Falcon	', NULL, NULL),
(12, 1, 'Guarico	', NULL, NULL),
(13, 1, 'Lara	', NULL, NULL),
(14, 1, 'Merida	', NULL, NULL),
(15, 1, 'Miranda	', NULL, NULL),
(16, 1, 'Monagas	', NULL, NULL),
(17, 1, 'Nueva Esparta	', NULL, NULL),
(18, 1, 'Portuguesa	', NULL, NULL),
(19, 1, 'Sucre	', NULL, NULL),
(20, 1, 'Tachira	', NULL, NULL),
(21, 1, 'Trujillo	', NULL, NULL),
(22, 1, 'Yaracuy	', NULL, NULL),
(23, 1, 'Zulia	', NULL, NULL),
(24, 1, 'Vargas	', NULL, NULL),
(25, 1, 'Dependencias Federales	', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `stores`
--

CREATE TABLE IF NOT EXISTS `stores` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(11) unsigned NOT NULL,
  `country_id` int(11) unsigned NOT NULL,
  `state_id` int(11) unsigned NOT NULL,
  `city_id` int(11) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address` text COLLATE utf8_unicode_ci NOT NULL,
  `phones` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `map` text COLLATE utf8_unicode_ci,
  `status` int(1) unsigned NOT NULL DEFAULT '1',
  `deleted` int(1) unsigned NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=15 ;

--
-- Volcado de datos para la tabla `stores`
--

INSERT INTO `stores` (`id`, `company_id`, `country_id`, `state_id`, `city_id`, `name`, `address`, `phones`, `email`, `map`, `status`, `deleted`, `created`, `modified`) VALUES
(1, 1, 1, 16, 21, 'MATURIN', 'Av. Libertador entre Residencias TAMA y Universidad Simón Rodríguez, Maturín Edo.Monagas\r\nTelefono: (0291) 651.21.11/029 (0424) 804.70.48 ', '000000000', 'aloa@lacarpeta.com', NULL, 1, 1, '2012-01-30 08:17:30', '2012-02-02 16:54:26'),
(2, 1, 1, 1, 6, 'LA URBINA', 'Calle 8 Manzana B7 al lado de los talleres de la Renault.', '(0212) 243.53.23 - 242.34.26', ' laurbina@lacarpeta.com', 'b', 1, 1, '2012-01-30 08:17:36', '2012-01-30 08:17:38'),
(7, 1, 1, 16, 21, 'romel j gomez herrera', 'urb las trinitarias calle 10 casa 561', '582913150755', 'bmxquiksilver7185@gmail.com s', NULL, 1, 0, '2012-01-31 23:29:56', '2012-04-05 07:30:35'),
(8, 1, 1, 16, 21, 'MATURIN', 'Av. Libertador entre Residencias TAMA y Universidad Simón Rodríguez, Maturín Edo.Monagas\r\nTelefono: (0291) 651.21.11/029 (0424) 804.70.48 ', '(212) 238.17.04 -238.81.80', 'aloa@lacarpeta.com', NULL, 1, 0, '2012-02-02 15:13:39', '2012-04-05 17:15:56'),
(9, 1, 1, 16, 21, 'romel j gomez herrera', 'urb las trinitarias calle 10 casa 561', '321231321', 'aloa@lacarpeta.com', NULL, 1, 0, '2012-02-02 17:28:02', '2012-02-03 21:20:51'),
(10, 1, 1, 16, 21, 'romel j gomez herrera', 'hola', 'wqw', 'wqw', NULL, 1, 1, '2012-02-02 18:08:23', '2012-02-02 18:08:23'),
(11, 1, 1, 16, 21, 'romel j gomez herrera', 'o que tla', '(212) 238.17.04 -238.81.80', 'aloa@lacarpeta.com', NULL, 1, 0, '2012-02-02 18:13:05', '2012-04-04 21:45:08'),
(12, 1, 1, 16, 21, 'romel j gomez herrera', 'hoa', '582913150755', 'bmxquiksilver7185@gmail.com', NULL, 1, 0, '2012-02-03 20:10:09', '2012-02-03 20:10:09'),
(13, 2, 1, 16, 21, 'Luna', 'al lado de la tierra', '00000007', 'luna@luna.com', NULL, 1, 0, '2012-02-10 19:09:35', '2012-02-10 19:09:35'),
(14, 1, 1, 6, 3, 'Plaza mayor', 'Urb las trinitarias calle 10 cas 561', '02913150755 33', 'solokarma@hotmail.com', NULL, 1, 0, '2012-04-04 18:53:23', '2012-04-04 20:01:15');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `store_images`
--

CREATE TABLE IF NOT EXISTS `store_images` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(11) unsigned NOT NULL,
  `store_id` int(11) unsigned NOT NULL,
  `parent_id` int(11) unsigned DEFAULT NULL,
  `size` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `deleted` int(1) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=113 ;

--
-- Volcado de datos para la tabla `store_images`
--

INSERT INTO `store_images` (`id`, `company_id`, `store_id`, `parent_id`, `size`, `name`, `title`, `deleted`, `created`, `modified`) VALUES
(1, 1, 7, NULL, 'full', 'dassault_falcon_7x_sunset-1366x76817.jpg', 'a', 1, '2012-01-31 23:29:56', '2012-01-31 23:29:56'),
(2, 1, 7, 1, '900x600px', 'dassault_falcon_7x_sunset-1366x76815.jpg', 'b', 1, '2012-01-31 23:29:56', '2012-01-31 23:29:56'),
(3, 1, 7, 1, '120x120px', 'dassault_falcon_7x_sunset-1366x76816.jpg', 'a', 1, '2012-01-31 23:29:56', '2012-01-31 23:29:56'),
(4, 1, 8, NULL, 'full', 'ubuntu-oneiric-gnome-shell2.png', 'b', 0, '2012-02-02 16:53:48', '2012-02-02 16:53:48'),
(5, 1, 8, 4, '900x600px', 'ubuntu-oneiric-gnome-shell0.png', 'c', 0, '2012-02-02 16:53:48', '2012-02-02 16:53:48'),
(6, 1, 8, 4, '120x120px', 'ubuntu-oneiric-gnome-shell1.png', 's', 0, '2012-02-02 16:53:48', '2012-02-02 16:53:48'),
(7, 1, 1, NULL, 'full', 'dp_to_dvi_cable_box2.jpg', 'd', 0, '2012-02-02 16:54:26', '2012-02-02 16:54:26'),
(8, 1, 1, 7, '900x600px', 'dp_to_dvi_cable_box0.jpg', 'a', 0, '2012-02-02 16:54:26', '2012-02-02 16:54:26'),
(9, 1, 1, 7, '120x120px', 'dp_to_dvi_cable_box1.jpg', 's', 0, '2012-02-02 16:54:26', '2012-02-02 16:54:26'),
(10, 1, 9, NULL, 'full', 'dassault_falcon_7x_sunset-1366x76820.jpg', 'd', 0, '2012-02-02 17:28:02', '2012-02-02 17:28:02'),
(11, 1, 9, 10, '900x600px', 'dassault_falcon_7x_sunset-1366x76818.jpg', 'a', 0, '2012-02-02 17:28:02', '2012-02-02 17:28:02'),
(12, 1, 9, 10, '120x120px', 'dassault_falcon_7x_sunset-1366x76819.jpg', 's', 0, '2012-02-02 17:28:02', '2012-02-02 17:28:02'),
(13, 1, 11, NULL, 'full', 'dp_to_dvi_cable_box5.jpg', 'd', 0, '2012-02-02 18:13:26', '2012-02-02 18:13:26'),
(14, 1, 11, 13, '900x600px', 'dp_to_dvi_cable_box3.jpg', 'd', 0, '2012-02-02 18:13:27', '2012-02-02 18:13:27'),
(15, 1, 11, 13, '120x120px', 'dp_to_dvi_cable_box4.jpg', 'sa', 0, '2012-02-02 18:13:27', '2012-02-02 18:13:27'),
(16, 1, 7, NULL, 'full', 'dp_to_dvi_cable_box8.jpg', 'a', 1, '2012-02-02 18:41:31', '2012-02-02 18:41:31'),
(17, 1, 7, 16, '900x600px', 'dp_to_dvi_cable_box6.jpg', 'ss', 1, '2012-02-02 18:41:31', '2012-02-02 18:41:31'),
(18, 1, 7, 16, '120x120px', 'dp_to_dvi_cable_box7.jpg', 'a', 1, '2012-02-02 18:41:31', '2012-02-02 18:41:31'),
(19, 1, 7, NULL, 'full', 'dassault_falcon_7x_sunset-1366x76823.jpg', 'a', 1, '2012-02-02 18:41:48', '2012-02-02 18:41:48'),
(20, 1, 7, 19, '900x600px', 'dassault_falcon_7x_sunset-1366x76821.jpg', 'a', 1, '2012-02-02 18:41:48', '2012-02-02 18:41:48'),
(21, 1, 7, 19, '120x120px', 'dassault_falcon_7x_sunset-1366x76822.jpg', 'a', 1, '2012-02-02 18:41:48', '2012-02-02 18:41:48'),
(23, 1, 7, NULL, 'full', 'dassault_falcon_7x_sunset-1366x76826.jpg', 'a', 1, '2012-02-03 12:02:47', '2012-02-03 12:02:47'),
(24, 1, 7, 23, '900x600px', 'dassault_falcon_7x_sunset-1366x76824.jpg', 's', 1, '2012-02-03 12:02:47', '2012-02-03 12:02:47'),
(25, 1, 7, 23, '120x120px', 'dassault_falcon_7x_sunset-1366x76825.jpg', 'd', 1, '2012-02-03 12:02:47', '2012-02-03 12:02:47'),
(26, 1, 7, NULL, 'full', 'ubuntu-oneiric-gnome-shell5.png', 's', 1, '2012-02-03 12:08:52', '2012-02-03 12:08:52'),
(27, 1, 7, 26, '900x600px', 'ubuntu-oneiric-gnome-shell3.png', 's', 1, '2012-02-03 12:08:52', '2012-02-03 12:08:52'),
(28, 1, 7, 26, '120x120px', 'ubuntu-oneiric-gnome-shell4.png', 'sa', 1, '2012-02-03 12:08:52', '2012-02-03 12:08:52'),
(29, 1, 7, NULL, 'full', 'dassault_falcon_7x_sunset-1366x76829.jpg', 'a', 1, '2012-02-03 12:42:23', '2012-02-03 12:42:23'),
(30, 1, 7, 29, '900x600px', 'dassault_falcon_7x_sunset-1366x76827.jpg', 's', 1, '2012-02-03 12:42:23', '2012-02-03 12:42:23'),
(31, 1, 7, 29, '120x120px', 'dassault_falcon_7x_sunset-1366x76828.jpg', 'sa', 1, '2012-02-03 12:42:23', '2012-02-03 12:42:23'),
(32, 1, 8, NULL, 'full', 'dassault_falcon_7x_sunset-1366x76832.jpg', 'ssas', 0, '2012-02-03 19:23:01', '2012-02-03 19:23:01'),
(33, 1, 8, 32, '900x600px', 'dassault_falcon_7x_sunset-1366x76830.jpg', 'sassaaaa', 0, '2012-02-03 19:23:01', '2012-02-03 19:23:01'),
(34, 1, 8, 32, '120x120px', 'dassault_falcon_7x_sunset-1366x76831.jpg', 'sasasssasasas', 0, '2012-02-03 19:23:01', '2012-02-03 19:23:01'),
(35, 1, 8, NULL, 'full', 'dassault_falcon_7x_sunset-1366x76835.jpg', '', 0, '2012-02-03 19:25:42', '2012-02-03 19:25:42'),
(36, 1, 8, 35, '900x600px', 'dassault_falcon_7x_sunset-1366x76833.jpg', '', 0, '2012-02-03 19:25:42', '2012-02-03 19:25:42'),
(37, 1, 8, 35, '120x120px', 'dassault_falcon_7x_sunset-1366x76834.jpg', '', 0, '2012-02-03 19:25:42', '2012-02-03 19:25:42'),
(38, 1, 9, NULL, 'full', 'dassault_falcon_7x_sunset-1366x76838.jpg', '', 0, '2012-02-03 21:11:19', '2012-02-03 21:11:19'),
(39, 1, 9, 38, '900x600px', 'dassault_falcon_7x_sunset-1366x76836.jpg', '', 0, '2012-02-03 21:11:19', '2012-02-03 21:11:19'),
(40, 1, 9, 38, '120x120px', 'dassault_falcon_7x_sunset-1366x76837.jpg', '', 0, '2012-02-03 21:11:19', '2012-02-03 21:11:19'),
(41, 1, 9, NULL, 'full', 'beautiful-redheads-gallery-62.jpg', '', 0, '2012-02-03 21:20:51', '2012-02-03 21:20:51'),
(42, 1, 9, 41, '900x600px', 'beautiful-redheads-gallery-60.jpg', '', 0, '2012-02-03 21:20:51', '2012-02-03 21:20:51'),
(43, 1, 9, 41, '120x120px', 'beautiful-redheads-gallery-61.jpg', '', 0, '2012-02-03 21:20:51', '2012-02-03 21:20:51'),
(44, 1, 9, NULL, 'full', 'tumblr_lkiqkmACSc1qbcq0u2.jpg', '', 0, '2012-02-03 21:20:51', '2012-02-03 21:20:51'),
(45, 1, 9, 44, '900x600px', 'tumblr_lkiqkmACSc1qbcq0u0.jpg', '', 0, '2012-02-03 21:20:51', '2012-02-03 21:20:51'),
(46, 1, 9, 44, '120x120px', 'tumblr_lkiqkmACSc1qbcq0u1.jpg', '', 0, '2012-02-03 21:20:51', '2012-02-03 21:20:51'),
(62, 1, 7, NULL, 'full', 'beautiful-redheads-gallery-614.jpg', '', 0, '2012-02-03 21:38:16', '2012-02-03 21:38:16'),
(63, 1, 7, 62, '900x600px', 'beautiful-redheads-gallery-612.jpg', '', 0, '2012-02-03 21:38:16', '2012-02-03 21:38:16'),
(64, 1, 7, 62, '120x120px', 'beautiful-redheads-gallery-613.jpg', '', 0, '2012-02-03 21:38:16', '2012-02-03 21:38:16'),
(65, 1, 7, NULL, 'full', 'beautiful-redheads-gallery-617.jpg', '', 0, '2012-02-03 21:39:08', '2012-02-03 21:39:08'),
(66, 1, 7, 65, '900x600px', 'beautiful-redheads-gallery-615.jpg', '', 0, '2012-02-03 21:39:08', '2012-02-03 21:39:08'),
(67, 1, 7, 65, '120x120px', 'beautiful-redheads-gallery-616.jpg', '', 0, '2012-02-03 21:39:08', '2012-02-03 21:39:08'),
(74, 1, 7, NULL, 'full', 'beautiful-redheads-gallery-622.jpg', '', 1, '2012-02-03 21:46:23', '2012-02-03 21:46:23'),
(75, 1, 7, 74, '900x600px', 'beautiful-redheads-gallery-620.jpg', '', 1, '2012-02-03 21:46:23', '2012-02-03 21:46:23'),
(76, 1, 7, 74, '120x120px', 'beautiful-redheads-gallery-621.jpg', '', 1, '2012-02-03 21:46:23', '2012-02-03 21:46:23'),
(77, 2, 13, NULL, 'full', 'dassault_falcon_7x_sunset-1366x76841.jpg', '', 0, '2012-02-10 19:09:35', '2012-02-10 19:09:35'),
(78, 2, 13, 77, '900x600px', 'dassault_falcon_7x_sunset-1366x76839.jpg', '', 0, '2012-02-10 19:09:35', '2012-02-10 19:09:35'),
(79, 2, 13, 77, '120x120px', 'dassault_falcon_7x_sunset-1366x76840.jpg', '', 0, '2012-02-10 19:09:35', '2012-02-10 19:09:35'),
(80, 1, 14, NULL, 'full', 'dassault_falcon_7x_sunset-1366x76844.jpg', '', 0, '2012-04-04 19:16:38', '2012-04-04 19:16:38'),
(81, 1, 14, 80, '900x600px', 'dassault_falcon_7x_sunset-1366x76842.jpg', '', 0, '2012-04-04 19:16:38', '2012-04-04 19:16:38'),
(82, 1, 14, 80, '120x120px', 'dassault_falcon_7x_sunset-1366x76843.jpg', '', 0, '2012-04-04 19:16:38', '2012-04-04 19:16:38'),
(83, 1, 14, NULL, 'full', 'dassault_falcon_7x_sunset-1366x76847.jpg', '', 0, '2012-04-04 19:27:47', '2012-04-04 19:27:47'),
(84, 1, 14, 83, '900x600px', 'dassault_falcon_7x_sunset-1366x76845.jpg', '', 0, '2012-04-04 19:27:47', '2012-04-04 19:27:47'),
(85, 1, 14, 83, '120x120px', 'dassault_falcon_7x_sunset-1366x76846.jpg', '', 0, '2012-04-04 19:27:47', '2012-04-04 19:27:47'),
(86, 1, 14, NULL, 'full', 'dassault_falcon_7x_sunset-1366x76850.jpg', '', 0, '2012-04-04 19:55:32', '2012-04-04 19:55:32'),
(87, 1, 14, 86, '900x600px', 'dassault_falcon_7x_sunset-1366x76848.jpg', '', 0, '2012-04-04 19:55:32', '2012-04-04 19:55:32'),
(88, 1, 14, 86, '120x120px', 'dassault_falcon_7x_sunset-1366x76849.jpg', '', 0, '2012-04-04 19:55:32', '2012-04-04 19:55:32'),
(89, 1, 14, NULL, 'full', 'dassault_falcon_7x_sunset-1366x76853.jpg', '', 0, '2012-04-04 20:01:15', '2012-04-04 20:01:15'),
(90, 1, 14, 89, '900x600px', 'dassault_falcon_7x_sunset-1366x76851.jpg', '', 0, '2012-04-04 20:01:15', '2012-04-04 20:01:15'),
(91, 1, 14, 89, '120x120px', 'dassault_falcon_7x_sunset-1366x76852.jpg', '', 0, '2012-04-04 20:01:15', '2012-04-04 20:01:15'),
(92, 1, 11, NULL, 'full', 'dassault_falcon_7x_sunset-1366x76856.jpg', '', 0, '2012-04-04 20:31:19', '2012-04-04 20:31:19'),
(93, 1, 11, 92, '900x600px', 'dassault_falcon_7x_sunset-1366x76854.jpg', '', 0, '2012-04-04 20:31:19', '2012-04-04 20:31:19'),
(94, 1, 11, 92, '120x120px', 'dassault_falcon_7x_sunset-1366x76855.jpg', '', 0, '2012-04-04 20:31:19', '2012-04-04 20:31:19'),
(95, 1, 11, NULL, 'full', 'dassault_falcon_7x_sunset-1366x76859.jpg', '', 0, '2012-04-04 21:45:10', '2012-04-04 21:45:10'),
(96, 1, 11, 95, '900x600px', 'dassault_falcon_7x_sunset-1366x76857.jpg', '', 0, '2012-04-04 21:45:10', '2012-04-04 21:45:10'),
(97, 1, 11, 95, '120x120px', 'dassault_falcon_7x_sunset-1366x76858.jpg', '', 0, '2012-04-04 21:45:10', '2012-04-04 21:45:10'),
(98, 1, 11, NULL, 'full', 'dassault_falcon_7x_sunset-1366x76862.jpg', '', 0, '2012-04-04 21:45:10', '2012-04-04 21:45:10'),
(99, 1, 11, 98, '900x600px', 'dassault_falcon_7x_sunset-1366x76860.jpg', '', 0, '2012-04-04 21:45:10', '2012-04-04 21:45:10'),
(100, 1, 11, 98, '120x120px', 'dassault_falcon_7x_sunset-1366x76861.jpg', '', 0, '2012-04-04 21:45:10', '2012-04-04 21:45:10'),
(101, 1, 11, NULL, 'full', 'dassault_falcon_7x_sunset-1366x76865.jpg', '', 0, '2012-04-04 21:45:10', '2012-04-04 21:45:10'),
(102, 1, 11, 101, '900x600px', 'dassault_falcon_7x_sunset-1366x76863.jpg', '', 0, '2012-04-04 21:45:10', '2012-04-04 21:45:10'),
(103, 1, 11, 101, '120x120px', 'dassault_falcon_7x_sunset-1366x76864.jpg', '', 0, '2012-04-04 21:45:10', '2012-04-04 21:45:10'),
(104, 1, 11, NULL, 'full', 'dassault_falcon_7x_sunset-1366x76868.jpg', '', 0, '2012-04-04 21:45:10', '2012-04-04 21:45:10'),
(105, 1, 11, 104, '900x600px', 'dassault_falcon_7x_sunset-1366x76866.jpg', '', 0, '2012-04-04 21:45:10', '2012-04-04 21:45:10'),
(106, 1, 11, 104, '120x120px', 'dassault_falcon_7x_sunset-1366x76867.jpg', '', 0, '2012-04-04 21:45:10', '2012-04-04 21:45:10'),
(107, 1, 11, NULL, 'full', 'dassault_falcon_7x_sunset-1366x76871.jpg', '', 0, '2012-04-04 21:45:10', '2012-04-04 21:45:10'),
(108, 1, 11, 107, '900x600px', 'dassault_falcon_7x_sunset-1366x76869.jpg', '', 0, '2012-04-04 21:45:10', '2012-04-04 21:45:10'),
(109, 1, 11, 107, '120x120px', 'dassault_falcon_7x_sunset-1366x76870.jpg', '', 0, '2012-04-04 21:45:10', '2012-04-04 21:45:10'),
(110, 1, 11, NULL, 'full', 'dassault_falcon_7x_sunset-1366x76874.jpg', '', 0, '2012-04-04 21:45:10', '2012-04-04 21:45:10'),
(111, 1, 11, 110, '900x600px', 'dassault_falcon_7x_sunset-1366x76872.jpg', '', 0, '2012-04-04 21:45:10', '2012-04-04 21:45:10'),
(112, 1, 11, 110, '120x120px', 'dassault_falcon_7x_sunset-1366x76873.jpg', '', 0, '2012-04-04 21:45:10', '2012-04-04 21:45:10');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) unsigned NOT NULL,
  `role_id` int(1) NOT NULL DEFAULT '3',
  `company_id` int(11) unsigned DEFAULT NULL,
  `store_id` int(11) unsigned DEFAULT NULL,
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `family_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `activation_key` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `deleted` int(1) unsigned NOT NULL DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `parent_id`, `role_id`, `company_id`, `store_id`, `password`, `name`, `family_name`, `alias`, `email`, `phone`, `activation_key`, `status`, `deleted`, `created`, `modified`) VALUES
(3, 0, 2, 2, 0, '194609f99d55e441d7e0ad65c0a39c54bdfa1697', 'maría velazco', 'gomez', '', 'sylo@gmail.com', '', 'activation_key', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, 0, 2, 1, 0, '194609f99d55e441d7e0ad65c0a39c54bdfa1697', 'romel', 'gomez', 'razden', 'romel2@gmail.com', '02913150755', 'activation_key', 1, 0, '0000-00-00 00:00:00', '2012-02-05 10:07:54'),
(5, 0, 3, 2, 0, '194609f99d55e441d7e0ad65c0a39c54bdfa1697', 'ciaela', 'de gomez', '', 'ciaela@gmail.com', '', 'activation_key', 1, 0, '2012-01-09 07:05:48', '2012-01-09 07:05:51');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `wishList`
--

CREATE TABLE IF NOT EXISTS `wishList` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `product_id` int(11) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `parent_id` int(11) unsigned NOT NULL,
  `lft` int(11) unsigned NOT NULL,
  `rght` int(11) unsigned NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
